<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */
$footer.="
        <!-- FOOTER -->
		<footer>
			<div class='wrapper cf'>
				<!-- bottom -->
				
				<div class='footer-bottom'>
					<div class='left'>by <a href='http://mavrosoft.tr.tn' >mavrosoft</a></div>
					<div class='right'>
						<ul id='social-bar' class='cf sb'>
							<li><a href='http://www.facebook.com'  title='Become a fan' class='facebook'>Facebbok</a></li>
							<li><a href='http://www.twitter.com' title='Follow my tweets' class='twitter'></a></li>
							<li><a href='http://plus.google.com' title='Enter my circles' class='plus'></a></li>
						</ul>
					</div>
				</div>	
				<!-- ENDS bottom -->
			
			</div>
		</footer>
		<!-- ENDS FOOTER -->
		
	</body>
	
	
	
</html>";


print $footer;
?>