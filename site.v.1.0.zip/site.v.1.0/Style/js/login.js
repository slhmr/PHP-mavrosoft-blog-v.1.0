function girisyap(){
	$("#login-form").validate({
      rules:
	  {
			password: {
			required: true,
			},
			user_email: {
            required: true,
            },
	   },
       messages:
	   {
            password:{
                      required: "Şifrenizi Giriniz...."
                     },
            user_email: "Kullanıcı Adı yada Mail Adresinizi Giriniz...",
       },
	   submitHandler: submitForm	
       });  
	   function submitForm(){		
		var data = $("#login-form").serialize();
				
		$.ajax({
				
			type : 'POST',
			url  : 'include/login_process.php',
			data : data,
			beforeSend: function(){	
				$("#sonuc").fadeOut();
				$("#btn-login").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; Kontrol Ediliyor');
			},
			success :  function(response){						
				if(response=="Başarılı"){		
					$("#btn-login").html("<img src='Style/img/btn-ajax-loader.gif' /> &nbsp; Giriş Yapılıyor ...");
					setTimeout(' window.location.href = "index.php"; ',2000);
				}
				else{
										
					$("#sonuc").fadeIn(1000, function(){						
						$("#sonuc").html('<div class="error-1"> <span class="glyphicon glyphicon-info-sign"></span> &nbsp; '+response+'</div>');
						setTimeout(' window.location.href = " ?page=sign_in"; ',2000);
					});
				}
			}
		});
		return false;
	}
}