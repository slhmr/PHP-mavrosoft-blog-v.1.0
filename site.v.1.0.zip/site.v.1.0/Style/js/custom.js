
jQuery(document).ready(function($) {
	
	$('.multicolumn').columnize({ 
		columns: 2
	});
	
	$('#mycarousel').jcarousel({
        vertical: false
    });
    
    $('#mycarousel-vertical').jcarousel({
        vertical: true
    });
	 
	 
	var buttons = { previous:$('#home-slider .button-previous') ,
						next:$('#home-slider .button-next') };	
	

	
	$('#home-slider').lofJSidernews( {
		interval 		: 4000,
		direction		: 'opacitys',	
		easing			: 'easeInOutExpo',
		duration		: 1200,
		auto		 	: false,
		maxItemDisplay  : 5,
		navPosition     : 'horizontal', 
		navigatorHeight : 73,
		navigatorWidth  : 188,
		mainWidth		: 940,
		buttons: buttons
	});
	
	$("ul.sf-menu").superfish({ 
        animation: {height:'show'},   
        delay:     800 ,              
        autoArrows:  false,
        speed: 100
    });
	
    $('.project-slider').flexslider({
    	animation: "fade",
    	controlNav: true,
    	directionNav: false,
    	keyboardNav: true
    });
	var $container = $('#filter-container');
	
	$container.imagesLoaded( function(){
		$container.isotope({
			itemSelector : 'figure',
			filter: '*',
			resizable: false,
			animationEngine: 'jquery'
		});
	});
	
		
	$('#filter-buttons a').click(function(){
	
		// select current
		var $optionSet = $(this).parents('#filter-buttons');
	    $optionSet.find('.selected').removeClass('selected');
	    $(this).addClass('selected');
    
		var selector = $(this).attr('data-filter');
		$container.isotope({ filter: selector });
		return false;
	});
	
	$('.poshytip').poshytip({
    	className: 'tip-twitter',
		showTimeout: 1,
		alignTo: 'target',
		alignX: 'center',
		offsetY: 5,
		allowTipHover: false
    });
	
   
    
    $('.form-poshytip').poshytip({
		className: 'tip-twitter',
		showOn: 'focus',
		alignTo: 'target',
		alignX: 'right',
		alignY: 'center',
		offsetX: 5
	});
	
	
	$("#tweets").tweet({
        count: 3,
        username: "ansimuz"
    });
    
	
	$('a[data-rel]').each(function() {
	    $(this).attr('rel', $(this).data('rel'));
	});
	
	$("a[rel^='prettyPhoto']").prettyPhoto();


	$('.accordion-container').hide(); 
	$('.accordion-trigger:first').addClass('active').next().show();
	$('.accordion-trigger').click(function(){
		if( $(this).next().is(':hidden') ) { 
			$('.accordion-trigger').removeClass('active').next().slideUp();
			$(this).toggleClass('active').next().slideDown();
		}
		return false;
	});
	$('.toggle-trigger').click(function() {
		$(this).next().toggle('slow');
		$(this).toggleClass("active");
		return false;
	}).next().hide();
	
	
    $(".tabs").tabs("div.panes > div", {effect: 'fade'});

		
	$("<select id='comboNav' />").appendTo("#combo-holder");
	
	$("<option />", {
		"selected": "selected",
		"value"   : "",
		"text"    : "Navigation"
	}).appendTo("#combo-holder select");
	
	$("#nav a").each(function() {
		var el = $(this);		
		var label = $(this).parent().parent().attr('id');
		var sub = (label == 'nav') ? '' : '- ';
		
		$("<option />", {
		 "value"   : el.attr("href"),
		 "text"    :  sub + el.text()
		}).appendTo("#combo-holder select");
	});

	
	$("#comboNav").change(function() {
	  location = this.options[this.selectedIndex].value;
	});
	$(window).resize(function() {
		
		var w = $(window).width();

		$container.isotope('reLayout');

	}).trigger("resize");
	
		
});
//close	
function yorumgonder(gelenid){
 	$.ajax({
        type: "post",
        url:  "include/ajax.php?gorev=yorum_gonder",
        cache: false,
        data: $('#commentform').serialize(),
        success: function(cevap){
            $("#sonuc")
            .show()
            .html(cevap)
        }
    });
}
document.addEventListener("DOMContentLoaded", function(event) { 

// Uses sharer.js 
//  https://ellisonleao.github.io/sharer.js/#twitter	
   var url = window.location.href;
   var title = document.title;
   var subject = "Read this good article";
   var via = "bootstrapC";
   console.log( url );
    console.log( title );


//facebook
$('#share-fb').attr('data-url', url).attr('data-sharer', 'facebook');
//twitter
$('#share-tw').attr('data-url', url).attr('data-title', title).attr('data-via', via).attr('data-sharer', 'twitter');
//linkedin
$('#share-li').attr('data-url', url).attr('data-sharer', 'linkedin');
// google plus
$('#share-gp').attr('data-url', url).attr('data-title', title).attr('data-sharer', 'googleplus');
  // email
  $('#share-em').attr('data-url', url).attr('data-title', title).attr('data-subject', subject).attr('data-sharer', 'email');

//Prevent basic click behavior
$( ".sharer button" ).click(function() {
  event.preventDefault();
});


});