<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */


print $content;

?>