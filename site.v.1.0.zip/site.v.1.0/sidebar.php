<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */
$a=$_GET['page'];
$t=array();
$t = explode ('/',$a);
$x=$t[0];
$id=$t[1];
if($x=="cat"){
	$sorgu=$dbc->vericek("subcategory","WHERE sub_cat_name='$id'");
	$sayisub=$sorgu->rowCount();
	if($sorgu != null)foreach($sorgu as $satir){
		$sub_id=$satir['sub_id'];
		$sub_name=$satir['sub_name'];
		$sorgukayitsayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_sub='$sub_id'");
		$sayi=$sorgukayitsayisi->rowCount();
		if($sayisub != 0){
			$s_category.="<li class='cat-item'><a href='?page=sub/$sub_id' title='title'>$sub_name<span class='post-counter'> ($sayi)</span></a></li>";	
		}
		else{
			$s_category.="<li class='cat-item'>Kategori Yok</li>";	
		}
	}
}
elseif($x=="sub"){
	$sorgutoppagination = $dbc->vericek("subcategory","WHERE sub_id='$id'");
	if($sorgutoppagination != null) foreach( $sorgutoppagination as $toppagination ) {
		$cat_id=$toppagination['sub_cat_name'];
	}
	$sorgu=$dbc->vericek("subcategory","WHERE sub_cat_name='$cat_id'");
	$sayisub=$sorgu->rowCount();
	if($sorgu != null)foreach($sorgu as $satir){
		$sub_id=$satir['sub_id'];
		$sub_name=$satir['sub_name'];
		$sorgukayitsayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_sub='$sub_id'");
		$sayi=$sorgukayitsayisi->rowCount();
		if($sayisub != 0){
			$s_category.="<li class='cat-item'><a href='?page=sub/$sub_id' title='title'>$sub_name<span class='post-counter'> ($sayi)</span></a></li>";	
		}
		else{
			$s_category.="<li class='cat-item'>Kategori Yok</li>";	
		}
	}
}
elseif($x=="tags"){
	$sorgutoppagination = $dbc->vericek("tags","WHERE tag_id='$id'");
	if($sorgutoppagination != null) foreach( $sorgutoppagination as $toppagination ) {
		$t_id=$toppagination['tag_sub_name'];
		$t_cid=$toppagination['tag_cat_name'];
	}
	$sorgukayit=$dbc->vericek("postarticle","WHERE p_bct='571' and p_tags LIKE '%$id%'");
	$sayi=$sorgukayit->rowCount();
	$sorgukayitsayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_tags LIKE '%$id%' GROUP BY p_sub");
	if($sorgukayitsayisi != null)foreach($sorgukayitsayisi as $satir){
		$p_sub_id=$satir['p_sub'];
		$sorgu=$dbc->vericek("subcategory","WHERE sub_id='$p_sub_id'");
		if($sorgu != null)foreach ($sorgu as $key ) {
			$sub_name=$key['sub_name'];
			$sub_id=$key['sub_id'];
		}
		
		if($sayi != 0){
			$s_category.="<li class='cat-item'><a href='?page=sub/$sub_id' title='title'>$sub_name<span class='post-counter'> ($sayi)</span></a></li>";	
		}
		else{
			$s_category.="<li class='cat-item'>Kategori Yok</li>";	
		}
	}
}
elseif($x=="single"){
	$id=$t[2];
	$sorgu = $dbc->vericek("postarticle","WHERE p_id='$id'");
	if($sorgu != null) foreach( $sorgu as $key ) {
		$cat_id=$key['p_cat'];		
	}
	$sorgu=$dbc->vericek("subcategory","WHERE sub_cat_name='$cat_id'");
	$sayisub=$sorgu->rowCount();
	if($sorgu != null)foreach($sorgu as $satir){
		$sub_id=$satir['sub_id'];
		$sub_name=$satir['sub_name'];
		$sorgukayitsayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_sub='$sub_id'");
		$sayi=$sorgukayitsayisi->rowCount();
		if($sayisub != 0){
			$s_category.="<li class='cat-item'><a href='?page=sub/$sub_id' title='title'>$sub_name<span class='post-counter'> ($sayi)</span></a></li>";	
		}
		else{
			$s_category.="<li class='cat-item'>Kategori Yok</li>";	
		}
	}

}
elseif($x=="arsive"){
	$id=$t[1];
	$sorgukayitsayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_arsive_ay='$id' GROUP BY p_sub");
	if($sorgukayitsayisi != null)foreach($sorgukayitsayisi as $satir){
		$sub_id=$satir['p_sub'];
		$sorgu=$dbc->vericek("subcategory","WHERE sub_id='$sub_id' ORDER BY sub_name DESC");
		if($sorgu != null)foreach($sorgu as $satir){
			$sub_name=$satir['sub_name'];
			$sorgusayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_sub='$sub_id'");
			$sayikayit=$sorgusayisi->rowCount();
			if($sayikayit != 0){
				$s_category.="<li class='cat-item'><a href='?page=sub/$sub_id' title='title'>$sub_name<span class='post-counter'> ($sayikayit)</span></a></li>";
			}
			else{
				$s_category.="<li class='cat-item'>Kategori Yok</li>";	
			} 	
		}
		
	}	
}
elseif($x=="search"){
	$id=$t[1];
	$g=$_POST['aranacakkelime'];
	$sorgukayitsayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_head LIKE '%$g%' or p_content LIKE '%$g%' GROUP BY p_sub");
	if($sorgukayitsayisi != null)foreach($sorgukayitsayisi as $satir){
		$sub_id=$satir['p_sub'];
		$sorgu=$dbc->vericek("subcategory","WHERE sub_id='$sub_id' ORDER BY sub_name DESC");
		if($sorgu != null)foreach($sorgu as $satir){
			$sub_name=$satir['sub_name'];
			$sorgusayisi=$dbc->vericek("postarticle","WHERE p_bct='571' and p_sub='$sub_id'");
			$sayikayit=$sorgusayisi->rowCount();
			if($sayikayit != 0){
				$s_category.="<li class='cat-item'><a href='?page=sub/$sub_id' title='title'>$sub_name<span class='post-counter'> ($sayikayit)</span></a></li>";
			}
			else{
				$s_category.="<li class='cat-item'>Kategori Yok</li>";	
			} 	
		}
		
	}	
}
else{

}
$r_sidebar.="</div> <!-- ENDS posts list -->
	<aside id='sidebar'>
		<ul>
	        <li class='block'>";
   $r_sidebar.="
   			<div class='sidebar_title'><h4 class='widget-title'>Site <i>Kategoriler</i></h4></div>
	        	<ul>
	        		$s_category
				</ul>
			</li>
			<li><div class='clearfix mar_top4'></div>
        		<div id='tabs'>
					<ul class='tabs'>  
						<li class='active'><a href='#tab1'>Popüler </a></li>
						<li><a href='#tab2'>Son Yazılar</a></li>
					</ul>
					<div class='tab_container'>	
						<div id='tab1' class='tab_content'> 
							<ul class='recent_posts_list'>";
	$sorgu=$dbc->vericek("postarticle","WHERE p_bct='571' ORDER BY p_hit DESC, p_id ASC LIMIT 5");
	if($sorgu != null )foreach ($sorgu as $k) {
		$id=$k['p_id'];
		$baslik=$k['p_head'];
		$logo=$k['p_logo'];
		$hit=$k['p_hit'];
		$eklenmetarihi=$k['p_addtime'];
	    $sor = $dbc->vericek("images","WHERE im_id='$logo'");
	    if($sor!= null) foreach( $sor as $sat ) {
	    	$logo=$sat['im_name'];
	    	$gallery_id=$sat['im_gallery'];
	    	$sorgugallery=$dbc->vericek("gallery","WHERE g_id='$gallery_id '");
	    	if($sorgugallery != null) foreach( $sorgugallery as $satirgallery ) {
	    		$g_name=$satirgallery['g_name'];
	    	}
	    }
		if(!empty($eklenmetarihi)){
			$tarih_saat=array();
			$tarih_saat = explode (' ',$eklenmetarihi);
			$tarih=array();
			$tarih = explode ('-',$tarih_saat[0]);
			$yil=$tarih[0];
			$ay=$tarih[1];
			$gun=$tarih[2];
		}
		$ay=ayyaz($ay);
		$r_sidebar.="
								<li>
									<span>
										<a href='?page=single/article/$id'><img width='42px' hight='32px' src='Galeriler/$g_name/$logo' alt='$g_name' /></a>
									</span>
									<a href='?page=single/article/$id'>$baslik</a>
									<i>$ay $gun, $yil</i>
								</li>";
	}
	$r_sidebar.="	
							</ul>
						</div><!-- tab1 sonu -->
						<div id='tab2' class='tab_content'>	 
							<ul class='recent_posts_list'>";
	$sorgu=$dbc->vericek("postarticle","WHERE p_bct='571' ORDER BY p_id DESC LIMIT 5");
	if($sorgu != null )foreach ($sorgu as $k) {
		$id=$k['p_id'];
		$baslik=$k['p_head'];
		$logo=$k['p_logo'];
		$eklenmetarihi=$k['p_addtime'];
	    $sor = $dbc->vericek("images","WHERE im_id='$logo'");
	    if($sor!= null) foreach( $sor as $sat ) {
	    	$logo=$sat['im_name'];
	    	$gallery_id=$sat['im_gallery'];
	    	$sorgugallery=$dbc->vericek("gallery","WHERE g_id='$gallery_id '");
	    	if($sorgugallery != null) foreach( $sorgugallery as $satirgallery ) {
	    		$g_name=$satirgallery['g_name'];
	    	}
	    }
		if(!empty($eklenmetarihi)){
			$tarih_saat=array();
			$tarih_saat = explode (' ',$eklenmetarihi);
			$tarih=array();
			$tarih = explode ('-',$tarih_saat[0]);
			$yil=$tarih[0];
			$ay=$tarih[1];
			$gun=$tarih[2];
		}
		$ay=ayyaz($ay);
    	$r_sidebar.="
								<li>
									<span>
										<a href='?page=single/article/$id'><img width='42px' hight='32px' src='Galeriler/$g_name/$logo' alt='$g_name' /></a>
									</span>
									<a href='?page=single/article/$id'>$baslik</a>
									<i>$ay $gun, $yil</i>
								</li>";
	}
	$r_sidebar.="
							</ul>
                 		</div><!-- tab2 sonu -->	
					</div><!-- tab container sonu -->
				</div> <!-- tabs sonu --><div class='clearfix mar_top4'></div>
			</li>
	         <li class='block'>
	         	<div class='sidebar_title'><h4 class='widget-title'>Site <i>Arşiv</i></h4></div>
	        	<ul>";
	$sorgu=$dbc->vericek("postarticle","WHERE p_bct='571'");
	$sayi=$sorgu->rowCount();
	$sorgu=$dbc->vericek("postarticle","WHERE p_bct='571' GROUP BY p_arsive_ay ORDER BY p_arsive_ay ASC");
	if($sorgu != null) foreach ($sorgu as $key => $value) {
		$ay_id=$value['p_arsive_ay'];
	   	$yil=$value['p_arsive_yil'];
	   	$ay_name=ayyaz($ay_id);
	  	$r_sidebar.="<li class='cat-item'><a href='?page=arsive/$ay_id' title='title'>$ay_name<span class='post-counter'> ($sayi)</span></a></li>";
	}
	$r_sidebar.="</ul>
			</li>
			<li class='block'><div class='clearfix mar_top4'></div>
				<div class='sidebar_widget'>
    
			    	<div class='sidebar_title'><h4 class='widget-title'>Site <i>Reklamlar</i></h4></div>
			        
						<ul class='adsbanner-list'>  
			            	<li><a href='#'><img src='' alt='' /></a></li>
			                <li class='last'><a href='#'><img src='' alt='' /></a></li>
			            </ul>
			                 
			           	<ul class='adsbanner-list'>  
			            	<li><a href='#'><img src='' alt='' /></a></li>
			            	<li class='last'><a href='#'><img src='' alt='' /></a></li>
           	</ul>
            
	</div><!-- end section -->
	<div class='clearfix mar_top4'></div>
			</li>
			<li class='block'><div class='clearfix mar_top4'></div>
			<div class='sidebar_title'><h4 class='widget-title'>Site <i>ETİKETLERİ</i></h4></div>
				
				  <ul class='tags_'>";
		$sorgu=$dbc->vericek("tags","");
		if($sorgu != null)foreach ($sorgu as $satir) {
			$id=$satir['tag_id'];
			$name=$satir['tag_name'];
			$cid=$satir['tag_sub_name'];
			$sayisorgu=$dbc->vericek("postarticle","WHERE p_tags LIKE '%$id%'");
			$sayi=$sayisorgu->rowCount();
			if($sayisorgu != null)foreach ($sayisorgu as $satir) {
				$pid=$satir['p_id'];
			}
			$r_sidebar.="
			<li><a href='?page=tags/$id'>$name<span>$sayi</span></a></li>";
		}
		$r_sidebar.="
					</ul>
				<div class='clearfix mar_top4'></div>
			</li>
		</ul>
    </aside>
	<!-- ENDS sidebar -->
	</div>
	<!-- ENDS WRAPPER -->
</div>
<!-- ENDS MAIN -->";

print $r_sidebar;
?>