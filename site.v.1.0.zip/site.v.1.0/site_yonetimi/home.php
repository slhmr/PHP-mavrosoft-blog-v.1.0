<?php
	require_once("inc/session.php");
	require_once("inc/class.user.php");
	include("inc/function.php");
	require_once("inc/default.php");
	$dbc = new user();
	
	$user_id = $_SESSION['user_session'];
	
	$stmt = $dbc->runQuery("SELECT * FROM users WHERE user_id=:user_id");
	$stmt->execute(array(":user_id"=>$user_id));
	$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
	$kullaniciadisoyadi= $userRow['user_real_name']; 
	$kullaniciyetki= $userRow['user_status'];
	$kullaniciadi=$userRow['user_name'];
	$kullanilogoid= $userRow['user_profile_pic'];
	$tarih = date("d.m.Y");
	$saat = date("H:i:s");
	$son_gorunme=$tarih."-".$saat;
	if(empty($kullanilogoid)){$kullanilogo="Style/img/default.png";}
	else{
		$sorgu=$dbc->vericek("images","WHERE im_id='$kullanilogoid'");
		if($sorgu != null) foreach( $sorgu as $satir ) {
			$imname=$satir['im_name'];
			$impath=$satir['im_path'];
			$id=$satir['im_gallery'];
			$sorgu=$dbc->vericek("gallery","WHERE g_id='$id'");
			if($sorgu != null) foreach( $sorgu as $satir ) {
				$gname=$satir['g_name'];
			}
		}
		$kullanilogo="../Galeriler/$gname/$imname";
	}
$sayfa = isset($_GET["pg"]) ? $_GET["pg"] : "pg";
$sayfa_args = explode("/",$sayfa);

switch($sayfa_args[0]) {
    case "nws" : include "post.php"; break;
    case "gplv" : include "media.php"; break;
    case "sttg" : include "site_settings.php"; break;
    case "sr" : include "user_s.php"; break;
    
    default :
    	$sorgu=$dbc->vericek("postarticle","WHERE p_bct='114'");
		$postcount = $sorgu->rowCount();
		$comment=$dbc->vericek("comments","WHERE com_status='0'");
		$commentcount = $comment->rowCount();
    			$content.="<div class='row'>
	                    		<div class='col-md-12'>
			                     	<h2>$kullaniciadi</h2>   
			                        <h5>Hoş Geldiniz $kullaniciadisoyadi</h5>
                    			</div>
                			</div>
                			<hr />
			                <div class='row'>
			                	<div class='col-md-3 col-sm-6 col-xs-6'>           
									<div class='panel panel-back noti-box'>
			                			<span class='icon-box bg-color-red set-icon'>
			                    			<i class='fa fa-envelope-o'></i>
			                			</span>
			                			<div class='text-box' >
			                    			<p class='main-text'>$postcount Yeni</p>
			                    			<p class='text-muted'>Makale</p>
			                			</div>
			             			</div>
					     		</div>
			                    <div class='col-md-3 col-sm-6 col-xs-6'>           
									<div class='panel panel-back noti-box'>
			                			<span class='icon-box bg-color-green set-icon'>
			                    			<i class='fa fa-bars'></i>
			                			</span>
			                			<div class='text-box' >
						                    <p class='main-text'>$commentcount Yorum</p>
						                    <p class='text-muted'>Onaylanmamış</p>
			                			</div>
			             			</div>
					     		</div>
			                    <div class='col-md-3 col-sm-6 col-xs-6'>           
									<div class='panel panel-back noti-box'>
			                			<span class='icon-box bg-color-blue set-icon'>
						                    <i class='fa fa-bell-o'></i>
						                </span>
			                			<div class='text-box' >
						                    <p class='main-text'>,,,</p>
						                    <p class='text-muted'>,,,</p>
						                </div>
						            </div>
					     		</div>
			                    <div class='col-md-3 col-sm-6 col-xs-6'>           
									<div class='panel panel-back noti-box'>
						                <span class='icon-box bg-color-brown set-icon'>
						                    <i class='fa fa-rocket'></i>
						                </span>
			                			<div class='text-box' >
						                    <p class='main-text'>....</p>
						                    <p class='text-muted'>....</p>
						                </div>
			             			</div>
					     		</div>
							</div>";                                 
    }
include "header.php";
include "sidebar.php";
include "content.php"; 
?>
