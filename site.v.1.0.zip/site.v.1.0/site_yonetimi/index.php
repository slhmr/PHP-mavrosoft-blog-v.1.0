<?php
session_start();
require_once("inc/class.user.php");

$login = new USER();



if($login->is_loggedin()!="")
{
	$login->redirect('home.php');
}

if(isset($_POST['btn-login']))
{
	$uname = strip_tags($_POST['txt_uname_email']);
	$umail = strip_tags($_POST['txt_uname_email']);
	$upass = strip_tags($_POST['txt_password']);
		
	if($login->doLogin($uname,$umail,$upass))
	{
		$login->redirect('home.php');
	}
	else
	{
		$error = "Giriş işlemi Başarısız...!!!!!!!";
	}	
}


?>


<!DOCTYPE html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Dark Login Form</title>
  <link rel="stylesheet" href="Style/css/login_style.css">
     <script src="Style/js/fonksiyon.js"></script>
</head>
<body> 
<div id="error">
        <?php
            if(isset($error)){
                ?>
                <div class="alert alert-danger">
                   <i class="glyphicon glyphicon-warning-sign"></i> &nbsp; <?php echo $error; ?> !
                </div>
                <?php
            }
        ?>
        </div>
  <form method="post" action="" class="login" >
   
    <p>
      <label for="login">Email:</label>
       <input type="text" class="form-control" name="txt_uname_email" placeholder="Ukullanıcı adı yada email" required />
    </p>

    <p>
      <label for="password">Şifre:</label>
      <input type="password" class="form-control" name="txt_password" placeholder="şifreniz" />
    </p>

    <p class="login-submit">
       <button type="submit" name="btn-login" class="login-button">
                    <i class="glyphicon glyphicon-log-in"></i> &nbsp; SIGN IN
            </button>
    </p>

    <p class="forgot-password"><a href="index.html">Şifremi Unuttum?</a></p>
   
  </form>

</body>
</html>

       