<?php

/**
 * @author MavRoAySa
 * @copyright 2016
 */
if(isset($sayfa_args[0]) && $sayfa_args[0] == "sr") {
	if(!empty($kullaniciyetki=="admin")) {
		if(isset($sayfa_args[1]) && $sayfa_args[1] == "srdd") {
			$content.="<div class='panel panel-default'>
                        <div class='panel-heading'>
                            <h3>Kullanıcı Ekleme Formu</h3>
                        </div>
                        <form id='kullanicieklemformu' method='' action='' onsubmit='return false'> 
                            <div class='panel-body'>
                            <div id='sonuc'></div><button class='btn btn-default' onclick= 'geridon()'><i class='fa fa-backward'></i>  Geri Dön</button>
                            <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Email<span class='text-danger'>*</span></label>
					          <div class='col-md-8 col-sm-9'>
					              <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-envelope'></i></span>
					              <input type='email' class='form-control' name='emailid' id='emailid' placeholder='Email Adresinizi Giriniz' value=''>
					            </div>
					            <small class='mail'> E-posta , hesabınızın, yetkilendirmenin ve erişim kurtarmanın güvenliğini sağlamak için kullanılıyor. </small> 
					            </div>
					        </div>
					        
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Şifre<span class='text-danger'>*</span></label>
					          <div class='col-md-5 col-sm-8'>
					            <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-lock'></i></span>
					              <input type='password' class='form-control' name='password' id='password' placeholder='Şifre Giriniz' value='' onkeyup='passwordStrength(this.value)'><span class='sifre'></span>
					           </div> 
					           <small class='password'> Şifrede En Az 1 Büyük Harf, 1 Küçük Harf ve Rakam Olmalıdır....!</small>   
					          </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Şifre Tekrar <span class='text-danger'>*</span></label>
					          <div class='col-md-5 col-sm-8'>
					            <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-lock'></i></span>
					              <input type='password' class='form-control' name='cpassword' id='cpassword' placeholder='Şifrenizi Tekrar Giriniz' value=''><span class='sifre'></span>
					            </div>  
					             <small class='cpassword'> Şifrede En Az 1 Büyük Harf, 1 Küçük Harf ve Rakam Olmalıdır....!</small>  
					          </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Adınız<span class='text-danger'>*</span></label>
					          <div class='col-md-8 col-sm-9'>
					           <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
					            <input type='text' class='form-control' name='mem_name' id='mem_name' placeholder='Kullanıcı Adı Giriniz...' value=''>
					          </div>
					           <small class='mem_name'>Max 50 - Min 5</small>
					        </div>
					        </div>
					         <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Adı Soyadı</label>
					          <div class='col-md-8 col-sm-9'>
					           <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
					            <input type='text' class='form-control' name='adisoyadi' id='adisoyadi' placeholder='Adınızı ve Soyadınızı giriniz....' value=''>
					          </div>
					           <small class='adisoyadi'></small>
					        </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Doğum Tarihiniz<span class='text-danger'>*</span></label>
					          <div class='col-xs-8'>
					            <div class='form-inline'>
					              <div class='form-group'>
					              <input type='date' class='form-control' name='bday' id='d_date'>
					              </div>
					            </div>
					            <small class='d_tarih'>Chrome,Safari ve Opera da tam çalışmaktadır. </small>
					          </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Cinsiyet<span class='text-danger'>*</span></label>
					          <div class='col-md-8 col-sm-9'>
					            <label>
					            <input name='gender' type='radio' value='bay' checked>
					            Bay </label>
					               
					            <label>
					            <input name='gender' type='radio' value='bayan' >
					            Bayan </label>
					          </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Cep Tel.<span class='text-danger'>*</span></label>
					          <div class='col-md-5 col-sm-8'>
					          	<div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-phone'></i></span>
					            <input type='text' class='form-control' name='contactnum' id='contactnum' value='' >
					            </div>
					            <small id='num'>Telefon numaranızı 5340515874 şeklinde giriniz.!</small>
					          </div>
					        </div>
					         <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Bölümü<span class='text-danger'>*</span></label><div class='col-md-8 col-sm-9'>  ";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$catid=$satir['cat_id'];
               							$content.="<div class='checkbox-inline' ><label><input type='checkbox' value='$catid' name='bolumu[]'/>".$satir['cat_name']."&nbsp;&nbsp;&nbsp;</label></div>";
                         				 }
                         				 
            				 $content.="</div></div>
					       <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Alanı<span class='text-danger'>*</span></label><div class='col-md-8 col-xs-12'> ";
                                    $sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$subid=$satir['sub_id'];
               							$content.="<div class='checkbox-inline' style='padding-left:3%;'><label><input type='checkbox' value='$subid' name='alani[]'/>".$satir['sub_name']."&nbsp;&nbsp;&nbsp;</label></div>";
                         				 }
                         				 
            				 $content.="  </div></div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Avatar <br>
					          <small>(Opsiyonel)</small></label>
					          <div class='col-md-5 col-sm-8'>
					            <div class='input-group'> <span class='input-group-addon' id='file_upload'><i class='glyphicon glyphicon-upload'></i></span>
					              <select class='form-control' id='logo' name='logo'> 
                                        	option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("images","WHERE im_gallery='5' ORDER BY im_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
               							 $content.="<option value = ".$satir['im_id'].">".$satir['im_name']."</option>";
							          }
 
            				 $content.="</select>
					            </div>
					          </div>
					        </div>
                            </div>
                            <div class='panel-footer'>
                                <button type='submit' class='btn btn-primary' onclick='yeniyazarekle()'>Kaydet</button>
                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle</button>
                                  
                            </div
                        </form>
                    </div>";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "srdt") {
			$gelen_id=$sayfa_args[2];
			$sorgu = $dbc->vericek("users","WHERE user_id='$gelen_id'");
    		if($sorgu != null) foreach( $sorgu as $satir ) {
    			$cinsiyet=$satir['user_gender'];
    			$kadi=$satir['user_name'];
    			$adsoyadi=$satir['user_real_name'];
    			$email=$satir['user_email'];
    			$tel=$satir['user_phone'];
    			$dtarih=$satir['user_dtarih'];
    			$kategori=$satir['user_cat'];
    			$altkategori=$satir['user_sub'];
    			$logo=$satir['user_profile_pic'];
    			$kayittarihi=$satir['user_join_date'];
    			
    		}
    		$gelenbolumdizisi=array();
			$gelenbolumdizisi = explode (',',$kategori);
			$gelenalandizisi=array();
			$gelenalandizisi = explode (',',$altkategori);

			 $content.="<div class='panel panel-default'>
                        <div class='panel-heading'>
                            <h3>Kullanıcı Düzenleme Formu</h3>
                        </div>
                        <form id='kullanicigncellemeformu' method='' action='' onsubmit='return false'> 
                            <div class='panel-body'>
                            <div id='sonuc'></div><button class='btn btn-default' onclick= 'geridon()'><i class='fa fa-backward'></i>  Geri Dön</button>
                            <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Email<span class='text-danger'>*</span></label>
					          <div class='col-md-8 col-sm-9'>
					              <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-envelope'></i></span>
					              <input type='email' class='form-control' name='emailid' id='emailid' placeholder='Email Adresinizi Giriniz' value='$email'>
					            </div>
					            <small class='mail'> E-posta , hesabınızın, yetkilendirmenin ve erişim kurtarmanın güvenliğini sağlamak için kullanılıyor. </small> 
					            </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Adınız<span class='text-danger'>*</span></label>
					          <div class='col-md-8 col-sm-9'>
					           <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
					            <input type='text' class='form-control' name='mem_name' id='mem_name' placeholder='Kullanıcı Adı Giriniz...' value='$kadi'>
					          </div>
					           <small class='mem_name'>Max 50 - Min 5</small>
					        </div>
					        </div>
					         <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Adı Soyadı</label>
					          <div class='col-md-8 col-sm-9'>
					           <div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-user'></i></span>
					            <input type='text' class='form-control' name='adisoyadi' id='adisoyadi' placeholder='Adınızı ve Soyadınızı giriniz....' value='$adsoyadi'>
					          </div>
					           <small class='adisoyadi'></small>
					        </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Doğum Tarihiniz<span class='text-danger'>*</span></label>
					          <div class='col-xs-8'>
					            <div class='form-inline'>
					              <div class='form-group'>
					              <input type='date' class='form-control' name='bday' id='d_date' value='$dtarih'>
					              </div>
					            </div>
					            <small class='d_tarih'>Chrome,Safari ve Opera da tam çalışmaktadır. </small>
					          </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Cinsiyet<span class='text-danger'>*</span></label>
					          <div class='col-md-8 col-sm-9'>";
								if($cinsiyet=="bay"){$sec="checked";}elseif($cinsiyet=="bayan"){$sec="checked";}else{$sec="";}

					$content.="<label>
					            <input name='gender' type='radio' value='bay' $sec>
					            Bay </label>
					               
					            <label><input name='gender' type='radio' value='bayan' $sec>
					            Bayan </label>
					          </div>
					        </div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Cep Tel.<span class='text-danger'>*</span></label>
					          <div class='col-md-5 col-sm-8'>
					          	<div class='input-group'>
					              <span class='input-group-addon'><i class='glyphicon glyphicon-phone'></i></span>
					            <input type='text' class='form-control' name='contactnum' id='contactnum' value='$tel' >
					            </div>
					            <small id='num'>Telefon numaranızı 5340515874 şeklinde giriniz.!</small>
					          </div>
					        </div>
					         <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Bölümü<span class='text-danger'>*</span></label><div class='col-md-8 col-sm-9'>  ";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$catid=$satir['cat_id'];
										if(in_array($catid,$gelenbolumdizisi)){$sec="checked";}else{$sec="";}
               							$content.="<div class='checkbox-inline' ><label><input type='checkbox' value='$catid' name='bolumu[]' $sec/>".$satir['cat_name']."&nbsp;&nbsp;&nbsp;</label></div>";
                         				 }		 
            				 $content.="</div></div>
					       <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Alanı<span class='text-danger'>*</span></label><div class='col-md-8 col-xs-12'> ";
                                    $sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$subid=$satir['sub_id'];
										if(in_array($subid,$gelenalandizisi)){$sec="checked";}else{$sec="";}
               							$content.="<div class='checkbox-inline' style='padding-left:3%;'><label><input type='checkbox' value='$subid' name='alani[]' $sec/>".$satir['sub_name']."&nbsp;&nbsp;&nbsp;</label></div>";
                         				 }
                         				 
            				 $content.="  </div></div>
					        <div class='form-group' style='width:90%; float:left;'>
					          <label class='control-label col-sm-1'>Avatar <br>
					          <small>(Opsiyonel)</small></label>
					          <div class='col-md-5 col-sm-8'>
					            <div class='input-group'> <span class='input-group-addon' id='file_upload'><i class='glyphicon glyphicon-upload'></i></span>
					              <select class='form-control' id='logo' name='logo'> 
                                        	option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("images","WHERE im_gallery='5' ORDER BY im_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$im_id=$satir['im_id'];
										 if($im_id==$logo){$sec="selected";}else{$sec="";}
               							 $content.="<option value = '$im_id' $sec>".$satir['im_name']."</option>";
							          }
 
            				 $content.="</select>
					            </div>
					          </div>
					        </div>
                            </div>
                            <div class='panel-footer'>
                           	 <input type='hidden' name='guncellenecekid' value='$gelen_id'/>
                                <button type='submit' class='btn btn-primary' onclick='kullanici_guncellme()'>Güncelle</button>
                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle</button>
                                  
                            </div
                        </form>
                    </div>";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "srsrl") {
			$content.="<div class='panel panel-default'>
	                        <div class='panel-heading'>Tüm Kayıtlar</div>
	                        <div class='panel-body'>
	                        	<div id='sonuc'></div>
	                            <div class='table-responsive'>
	                                <table class='table table-striped table-bordered table-hover' id='dataTables-example'>
	                                    <thead>
	                                        <tr> 
	                                        	<th>İD</th>
	                                            <th>YETKİ</th>
	                                            <th>KULLANICI ADI</th>
	                                            <th>ADI SOYADI</th>
	                                            <th>EMAİL</th>
	                                            <th>TELEFON</th>
	                                            <th>BÖLÜMÜ</th>
	                                            <th>ALANI</th>
	                                            <th>LOGO</th>
	                                            <th>D.TARİH</th>
	                                            <th>E.TARİH</th>
	                                            <th>İŞLEMLER</th>
	                                        </tr>
	                                    </thead>
	                                    <tbody>";
	                                    $sorgu = $dbc->vericek("users","");
	    								if($sorgu != null) foreach( $sorgu as $satir ) {
	    									$id=$satir['user_id'];
	    									$yetki=$satir['user_status'];
	    									$cinsiyet=$satir['user_gender'];
	    									$kadi=$satir['user_name'];
	    									$adsoyadi=$satir['user_real_name'];
	    									$email=$satir['user_email'];
	    									$tel=$satir['user_phone'];
	    									$dtarih=$satir['user_dtarih'];
	    									$kategori=$satir['user_cat'];//ayrıştıracaz
	    									$altkategori=$satir['user_sub'];//ayrıştıracaz
	    									$logo=$satir['user_profile_pic'];
	    									$kayittarihi=$satir['user_join_date'];
	    									$islemler="
	    										<form method='post' action='' onsubmit='return false'>
													<button class='btn btn-primary' onclick= 'kullaniciduzenlemeislemi($id)'><i class='fa fa-pencil-square-o '></i></button>
														<button class='btn btn-danger' onclick= 'kullanicisil($id)'><i class='fa fa-eraser'></i></button>
																</form>";
											$content .= "<tr>
															<td>$id</td>
					                                        <td><img src='Style/img/$yetki$cinsiyet.png'/></td>
					                                        <td><a href='?pg=sr/prfl/$id'>$kadi</td>
					                                        <td>$adsoyadi</td>
					                                        <td>$email</td>
					                                        <td>$tel</td>
					                                        <td>$kategori</td>
					                                        <td>$altkategori</td>
					                                        <td>$logo</td>
					                                        <td>$dtarih</td>
					                                        <td>$kayittarihi</td>
					                            			<td>$islemler</td>
	                           							</tr>";
	                                       				}

	                   						 $content .= "</tbody>
	                                    </tbody>
	                                </table>
	                            </div>
	                        </div>
	                   </div>";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "prfl") {
			$sifre="123456";
			$we=sha1(md5($sifre));
				echo $we;
			$gelen_id=$sayfa_args[2];
			$sorgu=$dbc->vericek("users","WHERE user_id='$gelen_id'");
			if($sorgu != null) foreach( $sorgu as $satir ) {
				$kadi=$satir['user_name'];
				$adisoyadi=$satir['user_real_name'];
				$email=$satir['user_email'];
				$bday=$satir['user_dtarih'];
				$bolumu=explode(",",$satir['user_cat']);
				$alani=explode(",",$satir['user_sub']);
				$profilpic=$satir['user_profile_pic'];
            }
            if(empty($profilpic)){
            	$kullanilogo="Style/img/default.png";
            }
			else{
				$sorgu=$dbc->vericek("images","WHERE im_id='$profilpic'");
				if($sorgu != null) foreach( $sorgu as $satir ) {
					$imname=$satir['im_name'];
					$impath=$satir['im_path'];
					$id=$satir['im_gallery'];
					$sorgu=$dbc->vericek("gallery","WHERE g_id='$id'");
					if($sorgu != null) foreach( $sorgu as $satir ) {
						$gname=$satir['g_name'];
					}
				}
				$kullanilogo="../Galeriler/$gname/$imname";
			}
     		$content.="	<div class='col-md-3 col-sm-3'>
                    	<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	<img src='$kullanilogo'/>
                            	<h4 class='text-white'>$adisoyadi</h4>
                        		<h5 class='text-white'>$email</h5>
                        	</div>
                    	</div>
                	</div>
                <div class='col-md-9 col-sm-9'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>Bölümü : ";
            foreach($bolumu as $deger) {
             $sorgu=$dbc->vericek("category","WHERE cat_id='$deger'");
				if($sorgu != null) foreach( $sorgu as $satir ) {
					$catname=$satir['cat_name'];
				}
             $content.="<a href='?sayfa= alan/$deger'>$catname</a>&nbsp;&nbsp;";
                                    }
             $content.=" </div>
                    </div>
                </div> <div class='col-md-9 col-sm-9'>
                    <div class='panel panel-default'>
                        <div class='panel-heading'>Uzmanlık Alanı : ";
            foreach($alani as $deger) {
             $sorgu=$dbc->vericek("subcategory","WHERE sub_id='$deger'");
				if($sorgu != null) foreach( $sorgu as $satir ) {
					$subname=$satir['sub_name'];
				}
             $content.="<a href='?sayfa= alan/$deger'>$subname</a>&nbsp;&nbsp;";
                                    }
             $content.=" </div>
                    </div>
                </div> 
                <div class='col-md-12 col-sm-12'>
                    <div class='panel panel-default'>
                        <div class='panel-body'>
                            <ul class='nav nav-tabs'>
                                <li class='active'><a href='#bd' data-toggle='tab'>Bilgi Düzeyi</a>
                                </li>
                                <li class=''><a href='#p' data-toggle='tab'>Paylaşımları</a>
                                </li>
                                <li class=''><a href='#c' data-toggle='tab'>Yorumları</a>
                                </li>
                                <li class=''><a href='#s' data-toggle='tab'>Ayarlar</a>
                                </li>
                            </ul>

                            <div class='tab-content'>
                                <div class='tab-pane fade active in' id='bd'>
                          		<h5>Wordpress <span class='pull-right'>80%</span></h5>
                                    <div class='progress'>
                                        <div class='progress-bar progress-bar-success' role='progressbar' aria-valuenow='80' aria-valuemin='0' aria-valuemax='100' style='width:80%;'> <span class='sr-only'>50% Complete</span> </div>
                                    </div>
                                    <h5>HTML 5 <span class='pull-right'>90%</span></h5>
                                    <div class='progress'>
                                        <div class='progress-bar progress-bar-custom' role='progressbar' aria-valuenow='90' aria-valuemin='0' aria-valuemax='100' style='width:90%;'> <span class='sr-only'>50% Complete</span> </div>
                                    </div>
                                    <h5>jQuery <span class='pull-right'>50%</span></h5>
                                    <div class='progress'>
                                        <div class='progress-bar progress-bar-primary' role='progressbar' aria-valuenow='50' aria-valuemin='0' aria-valuemax='100' style='width:50%;'> <span class='sr-only'>50% Complete</span> </div>
                                    </div>
                                    <h5>Photoshop <span class='pull-right'>70%</span></h5>
                                    <div class='progress'>
                                        <div class='progress-bar progress-bar-danger' role='progressbar' aria-valuenow='70' aria-valuemin='0' aria-valuemax='100' style='width:70%;'> <span class='sr-only'>50% Complete</span> </div>
                                    </div>
                                </div>
                                <div class='tab-pane fade' id='p'>
                                	<div class='panel panel-default'>
				                        <div class='panel-body'>
				                        	<div id='sonuc'></div>
				                            <div class='table-responsive'>
				                                <table class='table table-striped table-bordered table-hover' id='dataTables-example'>
				                                    <thead>
				                                        <tr> 
				                                        	<th>İD</th>
				                                            <th>DURUM</th>
				                                            <th>BAŞLIK</th>
				                                            <th>KATEGORİ</th>
				                                            <th>ALTKATEGORİ</th>
				                                            <th>ETİKETLER</th>
				                                            <th>İŞLEM</th>
				                                        </tr>
				                                    </thead>
				                                    <tbody>";
				                                    $sorgu = $dbc->vericek("postarticle","WHERE p_add='$gelen_id'");
				    								if($sorgu != null) foreach( $sorgu as $satir ) {
				    									$durum=$satir['p_bct'];
				    									$kategori=$satir['p_cat'];
				    									$altkategori=$satir['p_sub'];
				    									if($durum =='114'){
				    										$durum = "<img style='margin-left:10px;' src='Style/img/taslak.png'/>";
				    									}
				    									else{
				    										$durum="<img style='margin-left:10px;' src='Style/img/yayında.png'/>";
				    									}
				    									$baslik=$satir['p_head'];
				    									$id=$satir['p_id'];
				    									$uzunluk = strlen($baslik);
				    									if($uzunluk >= 20){$baslik=metni_sinirla($baslik,10);}
				    									$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
				    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
				    										$kategori=$satir2['cat_name'];
				    									}
				    									$sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
				    									if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
				    										$altkategori=$satir3['sub_name'];
				    									}
				    									
														$content .= "<tr>
																		<td>$id </td>
								                                        <td>$durum</td>
								                                        <td><a href='?pg=nws/nwpr/$id'>$baslik</a></td>
								                                        <td>$kategori</td>
								                                        <td>$altkategori</td>
								                                        <td>".$satir['p_tags']."</td>
								                            			<td>
																			<form method='post' action='' onsubmit='return false'>
																				<button class='btn btn-primary' onclick= 'makaleduzenle(".$satir['p_id'].")'><i class='fa fa-pencil-square-o '></i></button>
																				<button class='btn btn-danger' onclick= 'makalesil(".$satir['p_id'].")'><i class='fa fa-eraser'></i></button>
																			</form>
				                                       					 </td>
				                           							</tr>";
				                                       				}

				                   						 $content .= "</tbody>
				                                    </tbody>
				                                </table>
				                            </div>
				                            
				                        </div>
				                    </div>
                                </div>
                                <div class='tab-pane fade' id='c'>
                                    <h4></h4>
                                    <p></p>
                                </div>
                                <div class='tab-pane fade' id='s'>
                                    <h4></h4>
                                    <p></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>";

			
			}
		}
		
	
	else{  
		 header('HTTP/1.0 401 Not Found');
			echo "  <link href='Style/css/custom.css' rel='stylesheet' />
					<div class='wrap'>
				   		<div class='logo'>
				   			<h1>401</h1>
				    		<p>Sayfayı Görüntüleme Yetkiniz Bulunmamaktadır!!!!!!</p>
			  	      		<div class='sub'>
				        		<p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
				     	 	</div>
			        	</div>
					</div>";
		    exit();
		}
	}	
	else{ 
		if (strstr($_SERVER['REQUEST_URI'],'user_s.php')){
	    header('HTTP/1.0 404 Not Found');
		echo "  <link href='Style/css/custom.css' rel='stylesheet' />
				<div class='wrap'>
			   		<div class='logo'>
			   			<h1>404</h1>
			    		<p>Aradığınız Sayfayı Yapmyı Unuttuk Galiba!!!!!!</p>
		  	      		<div class='sub'>
			        		<p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
			     	 	</div>
		        	</div>
				</div>";
	    exit();
		}
	
	}
?>