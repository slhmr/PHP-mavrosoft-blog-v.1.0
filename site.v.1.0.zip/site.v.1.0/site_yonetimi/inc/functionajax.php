<?php

/**
 * @author MavRoAySa
 * @copyright 2016
 */
require_once("session.php");
require_once("function.php");
$date = new DateTime();
$par = $_GET["is"];
$user_id = $_SESSION['user_session'];
$dbc = new user();
/*----------Kategori İşlemleri--------------*/
if($par == "kategoriekle"){
    $kategoriadi = stripslashes($_POST['girilenkategori']);
    $eklenme_tarihi = $date->format('Y-m-d H:i:s');  
   
    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
    $ktgr = array();
    if($sorgu != null) foreach( $sorgu as $satir ) { $ktgr[] = $satir["cat_name"];}
    $kategoriadi = mb_convert_case($kategoriadi, MB_CASE_TITLE, "UTF-8");
    if($kategoriadi==""){
          echo "<h4 class='alert_error'>Kategori Adı Girmelisiniz....</h4>"; 
    }
    elseif (in_array($kategoriadi,$ktgr)) {  
        echo "<h4 class='alert_error'>Girilen Kategori Daha Önce Girilmiş Farklı Bir isim Giriniz....</h4>"; 
            
    } 
    else{
        $sonuc = $dbc->ekle("category",array("cat_name"=>$kategoriadi,"cat_add"=>$user_id,"cat_addtime"=>$eklenme_tarihi));
        
    if (isset($sonuc)){
        
        echo "<script>parent.window.location.reload(true);</script>";
	 }
     else {
		echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
	 }
    }
}
if($par == "kategoriduzenle"){
    $kategoriadi = stripslashes($_POST['girilenkategori']);
    $id=$_POST['girilenkategoriid'];
    $guncellenme_tarihi = $date->format('Y-m-d H:i:s');  
   
    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
    $ktgr = array();
    if($sorgu != null) foreach( $sorgu as $satir ) { $ktgr[] = $satir["cat_name"];}
    $kategoriadi = mb_convert_case($kategoriadi, MB_CASE_TITLE, "UTF-8"); 
   if($kategoriadi==""){
          echo "<h4 class='alert_error'>Kategori Adı Girmelisiniz....</h4>"; 
    }
    elseif (in_array($kategoriadi,$ktgr)) {  
        echo "<h4 class='alert_error'>Girilen Kategori Daha Önce Girilmiş Farklı Bir isim Giriniz....</h4>"; 
            
    } 
    else{
        $sonuc = $dbc->guncelle("category",array("cat_name"=>$kategoriadi,"cat_add"=>$user_id,"cat_addtime"=>$guncellenme_tarihi),"cat_id=$id");        
        if (isset($sonuc)){
            
            echo "<script>parent.document.location.href = '?pg=nws/ctdd';</script>";
         }
         else {
            echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
         }
    }
}
if($par == "kategorisil"){
    
    $id=$_POST['silinecekid']; 
   echo  $id;
    $sonuc = $dbc->sil("category","cat_id=$id");
    if (isset($sonuc)){
        echo "<script>parent.document.location.href = '?pg=nws/ctdd';</script>";
    }else {
        echo "<h4 class='alert_error'>Silme İşlemi Başarısız........</h4>";
    }
}
/*----------Kategori İşlemleri sonu---------*/
/*==========================================*/
/*----ALt kategori Ekleme İşlemi------------*/
if($par == "altkategoriekle"){
    $gelenaltkategori = stripslashes($_POST['girilenaltkategori']);
    $gelenkategori = $_POST['secilenkategori'];
    $eklenme_tarihi = $date->format('Y-m-d H:i:s'); 
    
    $sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
    $ktgr = array();
    if($sorgu != null) foreach( $sorgu as $satir ) { $ktgr[] = $satir["sub_name"];}
    
    $gelenaltkategori = mb_convert_case($gelenaltkategori, MB_CASE_TITLE, "UTF-8");
    if($gelenaltkategori==""){
          echo "<h4 class='alert_error'>Alt Kategori Adı Girmelisiniz....</h4>"; 
    }
    elseif($gelenkategori=="0"){
        echo "<h4 class='alert_error'>Kategori Şeçimi Yapmadınız......</h4>"; 
    }
    elseif (in_array($gelenaltkategori,$ktgr)) {  
        echo "<h4 class='alert_error'>Girilen Alt Kategori Daha Önce Girilmiş Farklı Bir isim Giriniz....</h4>"; 
            
    } 
    else{
        $sonuc = $dbc->ekle("subcategory",array("sub_name"=>$gelenaltkategori,"sub_cat_name"=>$gelenkategori,"sub_add"=>$user_id,"sub_addtime"=>$eklenme_tarihi));
    if (isset($sonuc)){
       echo "<script>parent.window.location.reload(true);</script>";
     }
     else {
        echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
     }
    }
}
if($par == "altkategoriguncelle"){
    $altkategoriadi = stripslashes($_POST['girilenaltkategori']);
    $id=$_POST['girilenaltkategoriid'];
    $gelenkategori = $_POST['secilenkategori'];
    $guncellenme_tarihi = $date->format('Y-m-d H:i:s');  
   
    $sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
    $altkategoriadi = mb_convert_case($altkategoriadi, MB_CASE_TITLE, "UTF-8"); 
   if($altkategoriadi==""){
          echo "<h4 class='alert_error'>Kategori Adı Girmelisiniz....</h4>"; 
    }
   
    elseif($gelenkategori=="0"){
        echo "<h4 class='alert_error'>Kategori Şeçimi Yapmadınız......</h4>"; 
    }
    else{
        $sonuc = $dbc->guncelle("subcategory",array("sub_name"=>$altkategoriadi,"sub_cat_name"=>$gelenkategori,"sub_add"=>$user_id,"sub_addtime"=>$guncellenme_tarihi),"sub_id=$id");        
        if (isset($sonuc)){
            
            echo "<script>parent.document.location.href = '?pg=nws/sctdd';</script>";
         }
         else {
            echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
         }
    }
}
if($par == "altkategorisil"){
    
    $id=$_POST['silinecekid']; 
   echo  $id;
    $sonuc = $dbc->sil("subcategory","sub_id=$id");
    if (isset($sonuc)){
        echo "<script>parent.document.location.href = '?pg=nws/sctdd';</script>";
    }else {
        echo "<h4 class='alert_error'>Silme İşlemi Başarısız........</h4>";
    }
}
/*-----ALt kategori Ekleme İşlemi Sonu------*/
/*==========================================*/
/*-----Etiket Ekleme İşlemi-----------------*/
if($par == "etiketekle"){
    $etiketadi = stripslashes($_POST['girilenetiket']);
    $gelenkategori = $_POST['secilenkategori'];
    $gelenkaltategori = $_POST['secilenaltkategori'];
    $eklenme_tarihi = $date->format('Y-m-d H:i:s');  
   
    $sorgu = $dbc->vericek("tags","ORDER BY tag_id DESC");
    $ktgr = array();
    if($sorgu != null) foreach( $sorgu as $satir ) { $ktgr[] = $satir["tag_name"];}
    $etiketadi = mb_convert_case($etiketadi, MB_CASE_TITLE, "UTF-8");
    if($etiketadi==""){
          echo "<h4 class='alert_error'>Etiket Adı Girmelisiniz....</h4>"; 
    }
    elseif (in_array($etiketadi,$ktgr)) {  
        echo "<h4 class='alert_error'>Girilen Etiket Daha Önce Girilmiş Farklı Bir isim Giriniz....</h4>"; 
            
    } 
     elseif($gelenkategori=="0"){
        echo "<h4 class='alert_error'>Kategori Şeçimi Yapmadınız......</h4>"; 
    }
     elseif(empty($gelenkaltategori)){
        echo "<h4 class='alert_error'>Alt Kategori Şeçimi Yapmadınız......</h4>"; 
    }
    else{
        $sonuc = $dbc->ekle("tags",array("tag_name"=>$etiketadi,"tag_cat_name"=>$gelenkategori,"tag_sub_name"=>$gelenkaltategori,"tag_add"=>$user_id,"tag_addtime"=>$eklenme_tarihi));
        
    if (isset($sonuc)){
        
        echo "<script>parent.window.location.reload(true);</script>";
     }
     else {
        echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
     }
    }
}
if($par == "etiketguncelle"){
    $etiketadi = stripslashes($_POST['girilenetiket']);
    $id=$_POST['girilenetiketid'];
    $gelenkategori = $_POST['secilenkategori'];
    $gelenkaltategori = $_POST['secilenaltkategori'];
    $guncellenme_tarihi = $date->format('Y-m-d H:i:s');  
   
    $sorgu = $dbc->vericek("tags","ORDER BY tag_id DESC");
    $ktgr = array();
    if($sorgu != null) foreach( $sorgu as $satir ) { $ktgr[] = $satir["tag_name"];}
    $etiketadi = mb_convert_case($etiketadi, MB_CASE_TITLE, "UTF-8"); 
   if($etiketadi==""){
          echo "<h4 class='alert_error'>Etiket Adı Girmelisiniz....</h4>"; 
    }
    elseif (in_array($etiketadi,$ktgr)) {  
        echo "<h4 class='alert_error'>Girilen Etiket Daha Önce Girilmiş Farklı Bir isim Giriniz....</h4>"; 
            
    } 
    elseif($gelenkategori=="0"){
        echo "<h4 class='alert_error'>Kategori Şeçimi Yapmadınız......</h4>"; 
    }
     elseif(empty($gelenkaltategori)){
        echo "<h4 class='alert_error'>Alt Kategori Şeçimi Yapmadınız......</h4>"; 
    } 
    else{
        $sonuc = $dbc->guncelle("tags",array("tag_name"=>$etiketadi,"tag_cat_name"=>$gelenkategori,"tag_sub_name"=>$gelenkaltategori,"tag_add"=>$user_id,"tag_addtime"=>$guncellenme_tarihi),"tag_id=$id");        
        if (isset($sonuc)){
            
            echo "<script>parent.document.location.href = '?pg=nws/tgs';</script>";
         }
         else {
            echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
         }
    }
}
if($par == "etiketsil"){
    
    $id=$_POST['silinecekid']; 
   echo  $id;
    $sonuc = $dbc->sil("tags","tag_id=$id");
    if (isset($sonuc)){
        echo "<script>parent.document.location.href = '?pg=nws/tgs';</script>";
    }else {
        echo "<h4 class='alert_error'>Silme İşlemi Başarısız........</h4>";
    }
}
if($par == "etiket_yukle"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $cat_id=$_POST['gonderilenid']; 
        $dizi=array();
        $scat="";       
        $sonuc = $dbc->vericek("tags","WHERE tag_sub_name='$cat_id'");
        if($sonuc != null) foreach( $sonuc as $satir ) {
            $scat.='<option value ="'.$satir['tag_id'].'">'.$satir["tag_name"].'</option>';
                     }
        $dizi["veri"]=$scat;
        
        echo json_encode($dizi);
    }
}
/*------Etiket Ekleme İşlemi Sonu-----------*/
/*==========================================*/
/*--Yeni Konu Ekleme İşlemleri--------------*/
if($par == "selectaltkat_yukle"){
    $cat_id=$_POST['gonderilenid']; 
    $dizi=array();
    $scat="";       
    $sonuc = $dbc->vericek("subcategory","WHERE sub_cat_name='$cat_id'");
    if($sonuc != null) foreach( $sonuc as $satir ) {
        $scat.='<option value ="'.$satir['sub_id'].'">'.$satir["sub_name"].'</option>';
                 }
    $dizi["veri"]=$scat;
    
    echo json_encode($dizi);
}
if($par == "etiketlerigetir"){
    $cat_id=$_POST['gonderilenid']; 
    $dizi=array();
    $scat="";       
    $sonuc = $dbc->vericek("tags","WHERE tag_cat_name='$cat_id'");
    if($sonuc != null) foreach( $sonuc as $satir ) {
        $scat.='<option value ="'.$satir['tag_id'].'">'.$satir["tag_name"].'</option>';
                 }
    $dizi["veri"]=$scat;
    
    echo json_encode($dizi);
}
if($par == "logogetir"){
    $cat_id=$_POST['gonderilenid']; 
    $dizi=array();
    $scat="";       
    $sonuc = $dbc->vericek("images,gallery","WHERE gallery.g_id=images.im_gallery and gallery.g_category='$cat_id'");
    if($sonuc != null) foreach( $sonuc as $satir ) {
        $scat.='<option value ="'.$satir['im_id'].'">'.$satir["im_name"].'</option>';
                 }
    $dizi["veri"]=$scat;
    
    echo json_encode($dizi);
}
if($par == "yenikonu"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $gelenetiketler =array();
        $gelenekonubasligi = $_POST['baslik'];
        $gelenicerik  = $_POST['icerik'];
        $gelenkategori = $_POST['kategorisec'];
        $gelenaltkategori = $_POST['altkategorisec'];
        $gelenlogo = $_POST['logo'];
        $turu=$_POST['pturu'];
        $gelenyayinturu = $_POST['yayinturu'];
        $eklenme_tarihi = $date->format('Y-m-d H:i:s'); 
        $arsivay=date("m");
        $arsivyil=date("Y");
        $hit=0;
        

        if(empty($gelenekonubasligi)){
             echo "<h4 class='alert_error'>Konu Başlığı Boş Bırakılamaz.....</h4>";
        }
        elseif(empty($gelenicerik)){
             echo "<h4 class='alert_error'>İçerik Eklemediniz.....</h4>";
        }
        elseif(empty($gelenkategori)){
             echo "<h4 class='alert_error'>Kategori Seçimi Yapmadınız.....</h4>";
        }
        else{
            foreach ($_POST['etiket'] as $id){
                $sonuc = $dbc->vericek("tags","WHERE tag_id='$id'");
                if($sonuc != null) foreach( $sonuc as $satir){$gelenetiketler[] =  $satir['tag_id'];}
            }
            $str = implode(',', $gelenetiketler);

            $sonuc = $dbc->ekle("postarticle",array("p_head"=>$gelenekonubasligi,"p_content"=>$gelenicerik,"p_cat"=>$gelenkategori,"p_sub"=>$gelenaltkategori,"p_tur"=>$turu,"p_logo"=> $gelenlogo,"p_tags"=> $str,"p_bct"=> $gelenyayinturu,"p_hit"=> $hit,"p_add"=>$user_id,"p_addtime"=>$eklenme_tarihi,"p_arsive_ay"=>$arsivay,"p_arsive_yil"=>$arsivyil));
            if (isset($sonuc)){
                echo "<script>parent.window.location.reload(true);</script>";
                }
             else {
                 echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
                }
        }
    }
}
if($par == "makale_sil"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id=$_POST['silinecekid']; 
        $sonuc = $dbc->sil("postarticle","p_id=$id");
        if (isset($sonuc)){
            echo "<script>parent.document.location.href = '?pg=nws/nwl';</script>";
        }else {
            echo "<h4 class='alert_error'>Silme İşlemi Başarısız........</h4>";
        }
    }
}
if($par == "p_yayinla"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id = $_POST['yayinlanacakid']; 
        $str="571";
        $sonuc = $dbc->guncelle("postarticle",array('p_bct' => $str),"p_id=$id");
        if (isset($sonuc)){
            echo "<script>parent.window.location.reload(true);</script>";
        }else {
            echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
} 
if($par == "p_yayindankaldir"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id = $_POST['yayinlanacakid']; 
        $str="114";
        $sonuc = $dbc->guncelle("postarticle",array('p_bct' => $str),"p_id=$id");
        if (isset($sonuc)){
            echo "<script>parent.window.location.reload(true);</script>";
        }else {
            echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
} 
if($par == "guncelleme_islemi"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $gelenetiketler =array();
        $gelenid=$_POST['id'];
        $gelenekonubasligi = $_POST['baslik'];
        $gelenicerik  = $_POST['icerik'];
        $gelenkategori = $_POST['kategorisec'];
        $gelenaltkategori = $_POST['altkategorisec'];
        $gelenlogo = $_POST['logo'];
        $gelenyayinturu = $_POST['yayinturu'];
        $eklenme_tarihi = $date->format('Y-m-d H:i:s'); 

        if(empty($gelenekonubasligi)){
             echo "<h4 class='alert_error'>Konu Başlığı Boş Bırakılamaz.....</h4>";
        }
        elseif(empty($gelenicerik)){
             echo "<h4 class='alert_error'>İçerik Eklemediniz.....</h4>";
        }
        elseif(empty($gelenkategori)){
             echo "<h4 class='alert_error'>Kategori Seçimi Yapmadınız.....</h4>";
        }
        else{
            foreach ($_POST['etiket'] as $id){
                $sonuc = $dbc->vericek("tags","WHERE tag_id='$id'");
                if($sonuc != null) foreach( $sonuc as $satir){$gelenetiketler[] =  $satir['tag_id'];}
            }
            $str = implode(',', $gelenetiketler);

            $sonuc = $dbc->guncelle("postarticle",array("p_head"=>$gelenekonubasligi,"p_content"=>$gelenicerik,"p_cat"=>$gelenkategori,"p_sub"=>$gelenaltkategori,"p_logo"=> $gelenlogo,"p_tags"=> $str,"p_bct"=> $gelenyayinturu,"p_add"=>$user_id,"p_update"=>$eklenme_tarihi),"p_id=$gelenid");
            if (isset($sonuc)){
                echo "<script>parent.document.location.href = '?pg=nws/nwl';</script>";
                }
             else {
                 echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
                }
        }
    }
}
/*-Yeni Konu Ekleme İşlemleri Sonu----------*/
/*==========================================*/
/*----------Galeri İşlemleri----------------*/

if($par == "galeriekle"){
    $galeriadi = stripslashes($_POST['girilengaleri']);
    $galerikategori = stripslashes($_POST['kategorisec']);
    $eklenme_tarihi = $date->format('Y-m-d H:i:s');  
   
    $sorgu = $dbc->vericek("gallery","ORDER BY g_id DESC");
    $dizi = array();
    if($sorgu != null) foreach( $sorgu as $satir ) { $dizi[] = $satir["g_name"];}
    $galeriadi = mb_convert_case($galeriadi, MB_CASE_TITLE, "UTF-8");
    if($galeriadi==""){
          echo "<h4 class='alert_error'>Galeri Adı Girmelisiniz....</h4>"; 
    }
    elseif (in_array($galeriadi,$dizi)) {  
        echo "<h4 class='alert_error'>Girilen Galeri Daha Önce Girilmiş Farklı Bir isim Giriniz....</h4>"; 
            
    } 
    elseif(empty($galerikategori)){
        echo "<h4 class='alert_error'>Kategori Seçimi Yapmadınız......</h4>"; 
    }
    else{
        $sonuc = $dbc->ekle("gallery",array("g_name"=>$galeriadi,"g_category"=>$galerikategori,"g_add"=>$user_id,"g_addtime"=>$eklenme_tarihi));
        @mkdir("../../Galeriler/".$galeriadi,"777");
    if (isset($sonuc)){
        
        echo "<script>parent.window.location.reload(true);</script>";
     }
     else {
        echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
     }
    }
}
if($par == "galeriduzenle"){
    $galeriadi = stripslashes($_POST['girilengaleri']);
    $id=$_POST['girilengaleriid'];
    $guncellenme_tarihi = $date->format('Y-m-d H:i:s');  
   
    $sorgu = $dbc->vericek("gallery","ORDER BY g_id DESC");
    $ktgr = array();
    if($sorgu != null) foreach( $sorgu as $satir ) { $ktgr[] = $satir["g_name"];$alinangaleriadi=$satir["g_name"];}
    $galeriadi = mb_convert_case($galeriadi, MB_CASE_TITLE, "UTF-8"); 
   if($galeriadi==""){
          echo "<h4 class='alert_error'>Galeri Adı Girmelisiniz....</h4>"; 
    }
    elseif (in_array($galeriadi,$ktgr)) {  
        echo "<h4 class='alert_error'>Girilen Galeri Adı Daha Önce Girilmiş Farklı Bir isim Giriniz....</h4>"; 
            
    } 
    else{
        $sonuc = $dbc->guncelle("gallery",array("g_name"=>$galeriadi,"g_add"=>$user_id,"g_addtime"=>$guncellenme_tarihi),"g_id=$id"); 
             @rename("../../Galeriler/$alinangaleriadi", "../../Galeriler/$galeriadi");
        if (isset($sonuc)){
            
            echo "<script>parent.document.location.href = '?pg=gplv/gllry';</script>";
         }
         else {
            echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
         }
    }
}

if($par == "galerisil"){
    
    $id=$_POST['silinecekid']; 
    $sorgu = $dbc->vericek("gallery","WHERE g_id=$id");
    if($sorgu != null) foreach( $sorgu as $satir ) { $foldername = $satir["g_name"];}
    if (klasor_bosmu("../../Galeriler/".$foldername."/") == true){
     @rmdir("../../Galeriler/".$foldername);
      $sonuc = $dbc->sil("gallery","g_id=$id");
        }
        else{
             echo "<h4 class='alert_error'>Klasör Dolu Olduğu İçinSilme İşlemi Başarısız........</h4>";
        }
    
   
    if (isset($sonuc)){
        echo "<script>parent.document.location.href = '?pg=gplv/gllry';</script>";
    }else {
        echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
    }
}
/*-----Galeri  İşlemleri Sonu---------------*/
/*==========================================*/
/*------Resim İşlemleri --------------------*/
if($par == "resimyuklemeislemi"){
	if(!ajaxistegikontrol()){
	    echo 'Ajax İsteği Değil';
	}
	else{
		$galeri=$_POST['galeri'];
		$resimadi=$_POST['image_name'];
		if(empty($galeri)){
		 	echo "<h4 class='alert_error'>Galeri Seçimi Yapmadınız.....</h4>";
		 }
		 else{
	    	if($_FILES['file']['error'] > 0){
	        	echo "Hata: " . $_FILES['file']['error'] . "<br>";
	    	} 
	    	else{

	    		$resimdosyasi = $_FILES['file']['name'];
			 	$boyut = $_FILES['file']['size'];
			 	$tip = $_FILES['file']['type'];
			 	
			 	$eklenme_tarihi = $date->format('Y-m-d H:i:s'); 

			 	$sorgu = $dbc->vericek("gallery","WHERE g_id='$galeri'");
    			if($sorgu != null) foreach( $sorgu as $satir ) { $galeriadi = $satir["g_name"];}
	        		
	        	$dosyayolu="../../Galeriler/$galeriadi/";
	        	$uzantikontrol = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");

	        	$ext = pathinfo($resimdosyasi, PATHINFO_EXTENSION);
	        	if(!array_key_exists($ext, $uzantikontrol)) die("Hata: Geçerli Bir Resim Dosyası Seçiniz.");
	       			
	       		$maxboyut = 2 * 1024 * 1024;
	        	if($boyut > $maxboyut) die("Hata: 2 Mb İzin Verilen Dosya Boyutu.");
	        	$uzanti=substr($resimdosyasi,-4,4);
	        	if(!empty($resimadi)){
	        		$yeni_ad=$resimadi."".$uzanti;
	        	}
	        	else{
	        		$sayi_tut=rand(1,10000);
				$yeni_ad=$galeriadi."_".$sayi_tut.$uzanti;
	        	}
				$boyutucevir=Size($boyut);
	        	if(in_array($tip, $uzantikontrol)){
	            	$sonuc = $dbc->ekle("images",array("im_name"=>$yeni_ad,"im_type"=>$tip,"im_size"=>$boyutucevir,"im_gallery"=>$galeri,"im_path"=>$dosyayolu,"im_add"=>$user_id,"im_addtime"=>$eklenme_tarihi));

	            	if (isset($sonuc)){
	            		move_uploaded_file($_FILES['file']['tmp_name'], $dosyayolu . $yeni_ad);
            			echo "<script>parent.document.location.href = '?pg=gplv/lg';</script>";
         			}
         			else {
            			echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
        			}
            	}
            }
		}
	}
}
if($par == "resim_sil"){
    
    $id=$_POST['silinecekid']; 
    $sorgu = $dbc->vericek("images","WHERE im_id=$id");
    if($sorgu != null) foreach( $sorgu as $satir ) { $imagename = $satir["im_name"];$foldername = $satir["im_gallery"];}

    if(!file_exists("../../Galeriler/$foldername/".$imagename)){
    	echo "<h4 class='alert_error'>Silinecek Resim Dosyası Mevcut Değil. Dosya veri Tabanından Siliniyor.......</h4>";
    	$sonuc = $dbc->sil("images","im_id=$id");
    	 if (isset($sonuc)){
        	echo "<script>parent.window.location.reload(true);</script>";
    	}
    	else {
        	echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
    else{
    	$sonuc = $dbc->sil("images","im_id=$id");
    	if (isset($sonuc)){
    		@unlink("../../Galeriler/$foldername/".$imagename);
        	echo "<script>parent.window.location.reload(true);</script>";
    	}
    	else {
        	echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
}
/*--Resim İşlemleri Sonu--------------------*/
/*==========================================*/
/*---------Kullanıcı İşlemleri -------------*/
if($par == "kullanicieklemeislemi"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{

        $bolumu="";
        $alani="";
        $email=$_POST['emailid'];
        $pass=$_POST['password'];
        $cpass=$_POST['cpassword'];
        $kadi=$_POST['mem_name'];
        $adisoyadi=$_POST['adisoyadi'];
        $bday=$_POST['bday'];
        $cinsiyet=$_POST['gender'];
        $tel=$_POST['contactnum'];
        if(!empty($_POST['bolumu'])){
            $bolumu=implode(",",$_POST['bolumu']);
        }
        if(!empty($_POST['alani'])){
            $alani=implode(",",$_POST['alani']);
        }
        $logo=$_POST['logo'];
        $eklenme_tarihi = $date->format('Y-m-d H:i:s');
        $status="yazar";

        if(empty($kadi)||empty($bday)||empty($tel)||empty($email)||empty($pass)||empty($cinsiyet)||empty($bolumu)||empty($alani)||empty($cpass)||empty($adisoyadi)){
            echo "Form da * ile belirtilen alanlar doldurulmak zorundadır";
        }
        elseif (strlen($pass) < '6') {
            echo "Şifreniz 6 Karakterden Az Olamaz.....!";
        }
        elseif(!preg_match("#[0-9]+#",$pass)) {
            echo "Şifreniz En Az Bir Rakam İçermelidir.....!";
        }
        elseif(!preg_match("#[A-Z]+#",$pass)) {
            echo "Şifreniz En Az Bir Büyük Harf İçermelidir....!";
        }
        elseif(!preg_match("#[a-z]+#",$pass)) {
             echo "Şifreniz En Az Bir Küçük Harf İçermelidir.....!";
        }
        elseif(!($pass === $cpass)){
                echo "Girilen Şifreler Birbiri İle Uyuşmuyor.....!";
        }
        elseif(!preg_match("#[0-9]+#", $tel) && preg_match("#[a-z]+#", $tel) && preg_match("#[A-Z]+#", $tel)){
                echo "Geçerli Bir Telefon Numarası Giriniz.....!";
        }
        else{
           $yenisifre= sifreuret($pass);
           $sonuc = $dbc->ekle("users",array("user_name"=>$kadi,"user_pass"=> $yenisifre,"user_email"=>$email,"user_real_name"=>$adisoyadi,"user_phone"=> $tel,"user_cat"=>$bolumu,"user_sub"=>$alani,"user_gender"=>$cinsiyet,"user_dtarih"=>$bday,"user_profile_pic"=>$logo,"user_status"=>$status,"user_join_date"=>$eklenme_tarihi));
                if (isset($sonuc)){
                    echo "<script>parent.window.location.reload(true);</script>";
                }
                else {
                    echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
                }
        }
    }

}
if($par == "kullanici_sil"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id=$_POST['silinecekid']; 
        if($id=="1"){
            echo "<h4 class='alert_error'>Bu Kullanıcı Silinemez....!!!!</h4>";
        }
        else{
            $sonuc = $dbc->sil("users","user_id=$id");
            if (isset($sonuc)){
                echo "<script>parent.document.location.href = '?pg=sr/srsrl';</script>";
            }
            else {
                echo "<h4 class='alert_error'>Silme İşlemi Başarısız........</h4>";
            }
        }
        
    }
}
if($par == "kullanici_duzenleme_islemi"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id=$_POST['guncellenecekid'];
        $bolumu="";
        $alani="";
        $email=$_POST['emailid'];
        $kadi=$_POST['mem_name'];
        $adisoyadi=$_POST['adisoyadi'];
        $bday=$_POST['bday'];
        $cinsiyet=$_POST['gender'];
        $tel=$_POST['contactnum'];
        if(!empty($_POST['bolumu'])){
            $bolumu=implode(",",$_POST['bolumu']);
        }
        if(!empty($_POST['alani'])){
            $alani=implode(",",$_POST['alani']);
        }
        $logo=$_POST['logo'];
        $eklenme_tarihi = $date->format('Y-m-d H:i:s');
        

        if(empty($kadi)||empty($bday)||empty($tel)||empty($email)||empty($cinsiyet)||empty($bolumu)||empty($alani)||empty($adisoyadi)){
            echo "Form da * ile belirtilen alanlar doldurulmak zorundadır";
        }
        elseif(!preg_match("#[0-9]+#", $tel) && preg_match("#[a-z]+#", $tel) && preg_match("#[A-Z]+#", $tel)){
                echo "Geçerli Bir Telefon Numarası Giriniz.....!";
        }
        else{
           $sonuc = $dbc->guncelle("users",array("user_name"=>$kadi,"user_email"=>$email,"user_real_name"=>$adisoyadi,"user_phone"=> $tel,"user_cat"=>$bolumu,"user_sub"=>$alani,"user_gender"=>$cinsiyet,"user_dtarih"=>$bday,"user_profile_pic"=>$logo,"user_update_date"=>$eklenme_tarihi),"user_id=$id");
                if (isset($sonuc)){
                    echo "<script>parent.document.location.href = '?pg=sr/prfl/$id';</script>";
                }
                else {
                    echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
                }
        }
    }

}
if($par == "yetkiartir"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id = $_POST['yayinlanacakid']; 
        $str="114";
        $sonuc = $dbc->guncelle("postarticle",array('p_bct' => $str),"p_id=$id");
        if (isset($sonuc)){
            echo "<script>parent.window.location.reload(true);</script>";
        }else {
            echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
} 
if($par == "yetkiazalt"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id = $_POST['yayinlanacakid']; 
        $str="114";
        $sonuc = $dbc->guncelle("postarticle",array('p_bct' => $str),"p_id=$id");
        if (isset($sonuc)){
            echo "<script>parent.window.location.reload(true);</script>";
        }else {
            echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
} 
/*-----Kullanıcı İşlemleri Sonu-------------*/
/*==========================================*/
/*Yorum İşlemleri*/
if($par == "yorum_yayinla"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id = $_POST['yayinlanacakid']; 
        $str=1;
        $sonuc = $dbc->guncelle("comments",array('com_status' => $str),"com_id=$id");
        if (isset($sonuc)){
            echo "<script>parent.window.location.reload(true);</script>";
        }else {
            echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
} 
if($par == "yorum_yayindankaldir"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id = $_POST['yayinlanacakid']; 
        $str=0;
        $sonuc = $dbc->guncelle("comments",array('com_status' => $str),"com_id=$id");
        if (isset($sonuc)){
            echo "<script>parent.window.location.reload(true);</script>";
        }else {
            echo "<h4 class='alert_error'>İşlem Başarısız........</h4>";
        }
    }
} 
if($par == "yorum_sil"){
    if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
        $id=$_POST['silinecekid']; 
        
            
       
            $sonuc = $dbc->sil("comments","com_id=$id");
            if (isset($sonuc)){
                echo "<script>parent.document.location.href = '?pg=nws/cmmntl';</script>";
            }
            else {
                echo "<h4 class='alert_error'>Silme İşlemi Başarısız........</h4>";
            }
    }
}
?>
