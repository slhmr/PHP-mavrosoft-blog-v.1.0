<?php

require_once('dbconfig.php');

class USER
{	

	private $conn;
	
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
    public function baglantiKapat() {
        $this->conn = null;
    } 	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function doLogin($uname,$umail,$upass){
		try{
			
			$stmt = $this->conn->prepare("SELECT user_id, user_name, user_email, user_pass FROM users WHERE user_name=:uname OR user_email=:umail");
			$stmt->execute(array(':uname'=>$uname, ':umail'=>$umail));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);

			if($stmt->rowCount() == 1){
				if(password_verify($upass, $userRow['user_pass'])){
					$_SESSION['user_session'] = $userRow['user_id'];
					return true;
				}
				else{
					return false;
				}
			}
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}
	
	public function is_loggedin()
	{
		if(isset($_SESSION['user_session']))
		{
			return true;
		}
	}
	
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function doLogout()
	{
		session_destroy();
		unset($_SESSION['user_session']);
		return true;
	}
function ekle($tablo, $veriler) {
        $sonuc = 0;
        $alan1 = "";
        $alan2 = "";
        foreach ($veriler as $anahtar => $deger) {
            $alan1 .= $anahtar . ",";
            $alan2 .= ":".$anahtar.",";
        }
        $alan1 = substr($alan1,0,strlen($alan1)-1);
        $alan2 = substr($alan2,0,strlen($alan2)-1);
        $query = $this->conn->prepare("INSERT INTO ".$tablo." (".$alan1.") VALUES (".$alan2.")");
        $query->execute($veriler);
        if ( $query ) $sonuc = $this->conn->lastInsertId(); else $sonuc = 0;
        return $sonuc;
    }  
function guncelle($tablo, $veriler, $where="") {
        $sonuc = "";
        $alan = "";
        foreach ($veriler as $anahtar => $deger) $alan .= $anahtar . "= :".$anahtar.",";
        $alan = substr($alan,0,strlen($alan)-1);
        if($where!="") $where = " WHERE ".$where;
        $query = $this->conn->prepare("UPDATE ".$tablo." SET ".$alan.$where);
        $update = $query->execute($veriler);
        if ( $update ) $sonuc = $query->rowCount(); else $sonuc = 0;
        return $sonuc;
    }
function sil($tablo,$where) {                    
        $delete = $this->conn->exec("DELETE FROM ".$tablo." WHERE ".$where); 
        return $delete;
    } 
function vericek($tablo,$diger="") {
        $sonuc = null;
        $query = $this->conn->query("SELECT * FROM ".$tablo." ".$diger, PDO::FETCH_ASSOC);
        if ( $query ) $sonuc = $query; else $sonuc = null;
        return $sonuc;
    }


}
?>