<?php
/**
 * @author MavRoAySa
 * @copyright 2016
 */

function sifreuret($password) {
    if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH) {
        $salt = '$2y$11$' . substr(md5(uniqid(rand(), true)), 0, 32);
        return crypt($password, $salt);
    }
}
function Size($bytes){		/*B KB MB GB donüştürme */
    if ($bytes > 0)
    {
        $unit = intval(log($bytes, 1024));
        $units = array('B', 'KB', 'MB', 'GB');
        if (array_key_exists($unit, $units) === true)
        {
            return sprintf('%d %s', $bytes / pow(1024, $unit), $units[$unit]);
        }
    }

    return $bytes;
}
function klasor_bosmu($klasor) {		/*klasör dolu mu  boşmu kontrol*/
	if ($handle = opendir($klasor)) {
		$durum = 'boş';
		while (false !== ($file = readdir($handle))) {
			if ($file != '.' && $file != '..') {
				$durum = 'dolu';
			}
		}
		if ($durum != 'dolu') {
 			return true;
		}
		else{
			return false;
		}
		closedir($handle);
	}
}
function klasor_boyutu($klasor){  		/*klasör boyutunu hesaplama*/
	$dizin="../Galeriler/".$klasor."/*";
	$size = 0;		 
	foreach(glob($dizin) as $dosya){
	  if(is_file($dosya)){
		$size = $size + filesize($dosya);
	  } 
	}
	
	$size = Size($size);
	return $size;
}
function sayibul($klasor_adi) {			/*kalsör içindeki toplam dosya sayısını bulma*/
	$klasor="../Galeriler/$klasor_adi";
    $dizi = array(); 
    $open = opendir($klasor); 
        while($q=readdir($open)) {
            if ($q != "." && $q != "..") {
                $dizi[] = $q;
            }
        }
  	$sayi = count($dizi); 
    closedir($open);
    return $sayi; 
    }
function ajaxistegikontrol(){
    $header = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? $_SERVER['HTTP_X_REQUESTED_WITH'] : null;
    return ($header === 'XMLHttpRequest');
	}
function metni_sinirla($metin,$sinir){
 	$uzunluk = strlen($metin);
 	if ($uzunluk > $sinir) {
 		$icerik = substr($metin,0,$sinir) . "&nbsp;&nbsp;&nbsp;" . "&raquo;&raquo;";
 	}
 return $icerik;
}	

?>