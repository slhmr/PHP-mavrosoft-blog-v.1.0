
<?php

/**
 * @author MavRoAySa
 * @copyright 2016
 */
$headermenu="";
$sidebarmenu="";
$contentmenu="";
$content="";
$kullaniciyetki="";
$r="12345566";
$sitename="MavRoSofT";
$ay_array = array( "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık");
?>