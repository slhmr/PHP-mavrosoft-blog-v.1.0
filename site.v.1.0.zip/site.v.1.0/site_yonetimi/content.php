
<?php

/**
 * @author MavRoAySa
 * @copyright 2016
 */

$contentmenu="<div id='page-wrapper' >
	            <div id='page-inner'>
	                <div class='row'>
	                    <div class='col-md-12'>
	                     $content
	                    </div>
	                </div>
	                <hr />
               
    			</div>
            </div>
        </div>
    
    <script src='Style/js/jquery-1.11.3-jquery.min.js'></script>
    <script src='Style/js/bootstrap.min.js'></script>
    <script src='Style/js/jquery.metisMenu.js'></script>
    <script src='Style/js/dataTables/jquery.dataTables.js'></script>
    <script src='Style/js/dataTables/dataTables.bootstrap.js'></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <script src='Style/js/custom.js'></script>
    <script src='Style/js/fonksiyon.js'></script>
    <script src='Style/js/morris/raphael-2.1.0.min.js'></script>

    <script src='Style/js/morris/morris.js'></script>
    <script src='../plugins/bower_components/jquery/dist/jquery.min.js'></script>
    <script src='bootstrap/dist/js/bootstrap.min.js'></script>
    <script src='../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js'></script>
    <script src='js/jquery.slimscroll.js'></script>
    <script src='js/waves.js'></script>
    <script src='js/custom.min.js'></script>
<script src='../plugins/bower_components/styleswitcher/jQuery.style.switcher.js'></script>
    
   
</body>
</html>
";
print $contentmenu;


?>