<?php

/**
 * @author MavRoAySa
 * @copyright 2016
 */

$sidebarmenu ="<nav class='navbar-default navbar-side' role='navigation'>
            <div class='sidebar-collapse'>
                <ul class='nav' id='main-menu'>
                <li class='text-center'>
                    <img src='$kullanilogo' class='user-image img-responsive'/>
                    </li>
                
                    
                    <li>
                        <a class='active-menu'  href='home.php'><i class='fa fa-dashboard fa-3x'></i> Anasayfa</a>
                    </li>
                     <li>
                        <a  href='#'><i class='fa fa-file fa-3x'></i> Makale <span class='fa arrow'></span></a>
                        <ul class='nav nav-second-level'>
                            <li>
                                <a href='?pg=nws/nwp'>Yeni Makale</a>
                            </li>
                            <li>
                                <a href='?pg=nws/nwl'>Makaleleri Listele</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                    <a  href='#'><i class='fa fa-bars fa-3x'></i>Kategorileri Düzenle <span class='fa arrow'></span></a>
                    
                           <ul class='nav nav-second-level'>
                            <li>
                                <a href='?pg=nws/ctdd'>Kategori Formu</a>
                            </li>
                            <li>
                                <a href='?pg=nws/sctdd'>Alt Kategori Formu</a>
                            </li>
                            <li>
                                <a href='?pg=nws/tgs'>Etiket Düzenleme Formu</a>
                            </li>
                        </ul>
                        </li>
                     
                     <li>
                    <a  href='#'><i class='fa fa-camera  fa-3x'></i>Media İşlemleri <span class='fa arrow'></span></a>
                    
                           <ul class='nav nav-second-level'>
                            <li>
                                <a href='?pg=gplv/lg'>Logo İşlemleri</a>
                            </li>
                            <li>
                                <a href='?pg=gplv/gllry'>Galeri İşlemleri</a>
                            </li>
                            <li>
                                <a href='?pg=gplv/wd'>Video İşlemleri</a>
                            </li>
                        </ul>
                        </li>                 
                      <li>
                    <a  href='#'><i class='fa fa-comment  fa-3x'></i>Yorum Sistemi<span class='fa arrow'></span></a>
                    
                           <ul class='nav nav-second-level'>
                            <li>
                                <a href='?pg=nws/cmmntl'>Yorumları Listele</a>
                            </li>
                            
                        </ul>
                        </li>  
                    <li>
                        <a  href='#'><i class='fa fa-user fa-3x'></i>Kullanıcı Ayarları  <span class='fa arrow'></span></a>
                    
                           <ul class='nav nav-second-level'>
                            <li>
                                <a href='?pg=sr/srdd'>Kullanıcı Ekle</a>
                            </li>
                            <li>
                                <a href='?pg=sr/srsrl'>Kullanıcıları Listele</a>
                            </li>
                        </ul>
                        </li>
                        <li>
                        <a  href='?pg=sttg/nwsttng'><i class='fa fa-cog fa-3x'></i>Site Ayarları </a>
                        </li>
                    </li>   
                </ul>
            </div>
        </nav>";
print $sidebarmenu;
?>