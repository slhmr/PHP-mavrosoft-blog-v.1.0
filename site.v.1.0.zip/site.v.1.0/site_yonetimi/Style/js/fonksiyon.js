function sayfayiyenile(){
    
                    location.reload();
                    }
function geridon(){
          history.back();
        }  			
/*------kategori fonksiyonları---------*/
function kategoriekle(){

            var formData = {
                    'girilenkategori'       :$("input[name=girilenkategori]").val(),
                    
                };
            $.ajax({
                    type: "post", 
                    url: "inc/functionajax.php?is=kategoriekle", 
                    data: formData,
                    success: function(cevap){
                    $("#mesaj")
                    .show()
                    .html(cevap)
                    }
            });
         
        }
function kategoriduzenle(gelenid){
          window.parent.window.location.href = '?pg=nws/ce/'+gelenid;
        } 
function kategoriguncelle(){
     var formData = {
                    'girilenkategori'       :$("input[name=girilenkategori]").val(),
                    'girilenkategoriid'     :$("input[name=girilenkategoriid]").val(),
                    
                };
            $.ajax({
                    type: "post", 
                    url: "inc/functionajax.php?is=kategoriduzenle", 
                    data: formData,
                    success: function(cevap){
                    $("#mesaj")
                    .show()
                    .html(cevap)
                    }
            });
}
function kategorisil(gelenid){
             $.ajax({
                       type: "post", 
                       url: "inc/functionajax.php?is=kategorisil",
                       data: 'silinecekid=' + gelenid,                  
                       success: function(cevap){
                            $("#mesaj")
                            .show()
                            .html(cevap)
                           }
            });
         
        } 		 
/*------kategori fonksiyonları Son ---------*/
/*------Alt kategori fonksiyonları ---------*/
function altkategoriekle(){
           var formData = {
            'girilenaltkategori'  : $("input[name=girilenaltkategori]").val(),
            'secilenkategori'     : $("#kategorisec").val(),
            
        };
           $.ajax({
                    type: "post", 
                    url: "inc/functionajax.php?is=altkategoriekle", 
                    data: formData,
                    success: function(cevap){
                    $("#mesaj")
                    .show()
                    .html(cevap)
                    }
            });
         
         
        }
function altkategoriduzenle(gelenid){
          window.parent.window.location.href = '?pg=nws/scte/'+gelenid;
        } 
function altkategoriguncelle(){
     var formData = {
                    'girilenaltkategori'  : $("input[name=girilenaltkategori]").val(),
                    'secilenkategori'     : $("#kategorisec").val(),
                    'girilenaltkategoriid': $("input[name=girilenaltkategoriid]").val(),
                    
                };
            $.ajax({
                    type: "post", 
                    url: "inc/functionajax.php?is=altkategoriguncelle", 
                    data: formData,
                    success: function(cevap){
                    $("#mesaj")
                    .show()
                    .html(cevap)
                    }
            });
}
function altkategorisil(gelenid){
  $.ajax({
    type: "post", 
    url: "inc/functionajax.php?is=altkategorisil",
    data: 'silinecekid=' + gelenid,                  
    success: function(cevap){
      $("#mesaj")
        .show()
        .html(cevap)
    }
  });
} 
/*------Alt kategori fonksiyonları Son ---------*/

/*------Etiket fonksiyonları---------*/
function etiketekle(){
  var formData = {
    'girilenetiket'         : $("input[name=etiketadi]").val(),
    'secilenkategori'       : $("#kategorisec").val(),
    'secilenaltkategori'    : $("#altkategorisec").val(),
            
  };
  $.ajax({
    type: "post", 
    url: "inc/functionajax.php?is=etiketekle", 
    data: formData,
    success: function(cevap){
      $("#mesaj")
      .show()
      .html(cevap)
    }
  });
}
function etiketduzenle(gelenid){
  window.parent.window.location.href = '?pg=nws/tgse/'+gelenid;
} 
function etiketguncelle(){
  var formData = {
    'girilenetiket'    : $("input[name=etiketadi]").val(),
    'girilenetiketid'  : $("input[name=girilenetiketid]").val(),
    'secilenkategori'       : $("#kategorisec").val(),
    'secilenaltkategori'    : $("#altkategorisec").val(),
  };
  $.ajax({
    type: "post", 
    url: "inc/functionajax.php?is=etiketguncelle", 
    data: formData,
    success: function(cevap){
      $("#mesaj")
      .show()
      .html(cevap)
    }
  });
}
function etiketsil(gelenid){
             $.ajax({
                       type: "post", 
                       url: "inc/functionajax.php?is=etiketsil",
                       data: 'silinecekid=' + gelenid,                  
                       success: function(cevap){
                            $("#mesaj")
                            .show()
                            .html(cevap)
                           }
            });
         
        } 


/*------Etiket fonksiyonları Son ---------*/
/*------Yeni Gönderi İşlemleri------------*/

function yenigonderi(){
     for(var yenikonueklemeformu in CKEDITOR.instances)
        CKEDITOR.instances[yenikonueklemeformu].updateElement();
        

        $.ajax({
               type: "post",
               url:  "inc/functionajax.php?is=yenikonu",
               cache: false,
               data: $('#yenikonueklemeformu').serialize(),
               success: function(cevap){
              $("#sonuc")
                        .show()
                        .html(cevap)
              }
                });
}
function makalesil(gelenid){
    $.ajax({
      type: "post", 
      url: "inc/functionajax.php?is=makale_sil",
      data: "silinecekid=" + gelenid,                 
      success: function(cevap){
        $("#sonuc")
        .show()
        .html(cevap)
      }
    });       
} 
function yayinla(gelenid){
          $.ajax({
             type: "post", 
             url: "inc/functionajax.php?is=p_yayinla",
             data: 'yayinlanacakid=' + gelenid,         
             success: function(cevap){
                            $("#sonuc")
                            .show()
                            .html(cevap)
                 }
      });
    } 
function yayindankaldir(gelenid){
          $.ajax({
             type: "post", 
             url: "inc/functionajax.php?is=p_yayindankaldir",
             data: 'yayinlanacakid=' + gelenid,         
             success: function(cevap){
                            $("#sonuc")
                            .show()
                            .html(cevap)
                 }
      });
    } 
function makaleduzenle(gelenid){
          window.parent.window.location.href = '?pg=nws/nwe/'+gelenid;
        } 
function guncellemeislemi(){
     for(var yenikonueklemeformu in CKEDITOR.instances)
        CKEDITOR.instances[yenikonueklemeformu].updateElement();
        

        $.ajax({
               type: "post",
               url:  "inc/functionajax.php?is=guncelleme_islemi",
               cache: false,
               data: $('#yenikonueklemeformu').serialize(),
               success: function(cevap){
              $("#sonuc")
                        .show()
                        .html(cevap)
              }
                });
}
/*------Yeni Gönderi İşlemleri Son--------*/
function kategorileri_al(){
        var formData = {
            'gonderilenid'  : $("#kategorisec").val(),
          };
        $.ajax({
             type: "post", 
             url:  "inc/functionajax.php?is=selectaltkat_yukle",
             data: formData,
             dataType:"json",            
             success: function(cevap){
                           $("#altkategorisec").html(cevap.veri);
                 }
            });
}
function etiketlericek(){

        var formData = {
            'gonderilenid'  : $("#kategorisec").val(),
          };
        $.ajax({
             type: "post", 
             url:  "inc/functionajax.php?is=etiketlerigetir",
             data: formData,
             dataType:"json",            
             success: function(cevap){
                           $("#etiket").html(cevap.veri);
                 }
            });
}
function logolarigetir(){
        var formData = {
            'gonderilenid'  : $("#kategorisec").val(),
          };
        $.ajax({
             type: "post", 
             url:  "inc/functionajax.php?is=logogetir",
             data: formData,
             dataType:"json",            
             success: function(cevap){
                           $("#logo").html(cevap.veri);
                 }
            });
}
/*----------------------- Resim Yükleme İşlei-----------------------------*/
function resimyukle(){
  var fd = new FormData();
  var file = $('#file_upload')[0].files[0];
  fd.append('file',file);
  var imagename = $('#logoisim').val();
  fd.append('image_name',imagename)
  var galeri = $("#kategorisec").val();
  fd.append('galeri',galeri);
  
    $.ajax({
        type: "post",  
        url: "inc/functionajax.php?is=resimyuklemeislemi", 
        data:  fd, 
        processData: false,
       contentType: false,           
       success: function(cevap){
              $("#sonuc")
                        .show()
                        .html(cevap)
              }
       
    });

}
function resimsil(gelenid){
    $.ajax({
      type: "post", 
      url: "inc/functionajax.php?is=resim_sil",
      data: "silinecekid=" + gelenid,                 
      success: function(cevap){
        $("#sonuc_2")
        .show()
        .html(cevap)
      }
    });       
} 
/*----------------------- Resim Yükleme İşlemi Sonu----------------------*/
/*------Galeri fonksiyonları---------*/
function galeriekle(){

            var formData = {
                    'girilengaleri'   :$("input[name=girilengaleri]").val(),
                    'kategorisec'     :$("#kategorisec").val(),
                };
            $.ajax({
                    type: "post", 
                    url: "inc/functionajax.php?is=galeriekle", 
                    data: formData,
                    success: function(cevap){
                    $("#mesaj")
                    .show()
                    .html(cevap)
                    }
            });
         
        }
function galeriduzenle(gelenid){
          window.parent.window.location.href = '?pg=gplv/gllrye/'+gelenid;
        } 
function galeriguncelle(){
     var formData = {
                    'girilengaleri'       :$("input[name=girilengaleri]").val(),
                    'girilengaleriid'     :$("input[name=girilengaleriid]").val(),
                    
                };
            $.ajax({
                    type: "post", 
                    url: "inc/functionajax.php?is=galeriduzenle", 
                    data: formData,
                    success: function(cevap){
                    $("#mesaj")
                    .show()
                    .html(cevap)
                    }
            });
}
function galerisil(gelenid){

             $.ajax({
                       type: "post", 
                       url: "inc/functionajax.php?is=galerisil",
                       data: 'silinecekid=' + gelenid,                 
                       success: function(cevap){
                            $("#mesaj")
                            .show()
                            .html(cevap)
                           }
            });
         
        }      
/*------Galeri fonksiyonları Son ---------*/
/*================================================================/*==*/
/*__*/                                                            /*__*/ 
/*__*/               /*Yazar İşlemleri*/                          /*__*/   
/*__*/                                                            /*__*/ 
/*================================================================/*==*/
function emailtest(email) {
  var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return reg.test(email);
}
$("#emailid").on("keyup", function(event){     
  mail_kontrolu();
});
$("#password").on("keyup", function(event){     
  sifre_kontrolu();
});
$("#cpassword").on("keyup", function(event){
  sifre_kontrolu2();
});
$("#mem_name").on("keyup", function(event){
  adikontrolu();
});
$("#contactnum").keypress(function(e) {
    var telnou = this.value.length;
    var telno = $(this).val();
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
       $("#num").html("Sadece Rakam").show().fadeOut("slow");
       return false;
    }
    else{
      if (telnou == 3) {
      $("#contactnum").val(" +90 " + telno + "" + "-");
    } else if (telnou == 9) {
      $("#contactnum").val(telno + "-");
    }
    }
    
  });
var mail_kontrolu = function(){
    var email = $("#emailid").val();
     if (!emailtest(email)) {
          $("#emailid").text(email);$("#emailid").css("color", "red");
          $('.mail').html("Geçerli Mail Giriniz.....").css("color", "red");
        }
        else {
           $("#emailid").text(email);$("#emailid").css("color", "green");
           $('.mail').html("Geçerli").css("color", "green");
        }
    return false;
}

var sifre_kontrolu = function(){
    var sifre1 = $("#password").val();
    var sifreboyut = $("#password").val().length;
    var nameReg = /^[A-Za-z]+$/;
    var numberReg =  /^[0-9]+$/;
        if( (!sifre1.match(/[A-z]/)) || (!sifre1.match(/[A-Z]/) )|| (!sifre1.match(/\d/))){
           $('.password').html("Şifreniz büyük küçük harf ve rakamdan oluşmalıdır").css("color", "red");
        
        } 
        else if(sifreboyut < 6){
          $('.password').html("Şifreniz 6 karakterden az olamaz...").css("color", "red");
          if(sifreboyut >= 6){

          }
        }
        else {
            $("#password").text(sifre1);$("#password").css("color", "green");
            $('.password').html("Geçerli").css("color", "green");
        }
    return false;
}
var sifre_kontrolu2= function(){
    var sifre1 = $("#password").val();
    var sifre2 = $("#cpassword").val();
        if(!(sifre1 === sifre2) ){
           $('.cpassword').html("Girilen Şifreler Eşleşmiyor....!").css("color", "red");
        } 
        else {
            $("#cpassword").text(sifre2);$("#cpassword").css("color", "green");
            $('.cpassword').html("Geçerli").css("color", "green");
        }
    return false;
}
var adikontrolu = function(){
    var kadi = $("#mem_name").val();
    if ( kadi==null || kadi=="" ){
           $('.mem_name').html("Adınız Alanı Boş Bırakılamaz...!").css("color", "red");
    }
    else if(kadi.length < 6 || kadi.length > 50){
          $("#mem_name").text(kadi);$("#mem_name").css("color", "red");
          $('.mem_name').html("5-50 karakter aralığında olmalıdır....").css("color", "red");
    }
    else{
          $("#mem_name").text(kadi);$("#mem_name").css("color", "green");
          $('.mem_name').html("Geçerli").css("color", "green");
    }
    return false;
}
function yeniyazarekle(){
var bolumu = new Array();
$( "input[name='bolumu[]']:checked" ).each( function() {
          bolumu.push( $( this ).val() );
      } );
var alani = new Array();
$( "input[name='alani[]']:checked" ).each( function() {
          alani.push( $( this ).val() );
      } );
 $.ajax({
        type: "post",
        url:  "inc/functionajax.php?is=kullanicieklemeislemi",
        cache: false,
        data: $('#kullanicieklemformu').serialize(),
        success: function(cevap){
          $("#sonuc")
          .show()
          .html(cevap)

        }
  });
         
}
function kullanicisil(gelenid){
  $.ajax({
    type: "post", 
    url: "inc/functionajax.php?is=kullanici_sil",
    data: 'silinecekid=' + gelenid,                 
    success: function(cevap){
      $("#sonuc")
      .show()
      .html(cevap)
    }
  });
}  
function kullaniciduzenlemeislemi(gelenid){
  window.parent.window.location.href = '?pg=sr/srdt/'+gelenid;
} 
function kullanici_guncellme(){
  var bolumu = new Array();
  $( "input[name='bolumu[]']:checked" ).each( function() {
    bolumu.push( $( this ).val() );
  });
  var alani = new Array();
  $( "input[name='alani[]']:checked" ).each( function() {
    alani.push( $( this ).val() );
  });
  $.ajax({
    type: "post",
    url:  "inc/functionajax.php?is=kullanici_duzenleme_islemi",
    cache: false,
    data: $('#kullanicigncellemeformu').serialize(),
    success: function(cevap){
      $("#sonuc")
      .show()
      .html(cevap)
    }
  });
}
/*------Yazar İşlemleri Son ---------*/
/*yorum işlemleri*/
function yorumyayinla(gelenid){
  $.ajax({
    type: "post", 
    url: "inc/functionajax.php?is=yorum_yayinla",
    data: 'yayinlanacakid=' + gelenid,         
    success: function(cevap){
      $("#sonuc")
      .show()
      .html(cevap)
    }
  });
} 
function yorumyayindankaldir(gelenid){
          $.ajax({
             type: "post", 
             url: "inc/functionajax.php?is=yorum_yayindankaldir",
             data: 'yayinlanacakid=' + gelenid,         
             success: function(cevap){
                            $("#sonuc")
                            .show()
                            .html(cevap)
                 }
      });
    } 
function yorumsil(gelenid){
  $.ajax({
    type: "post", 
    url: "inc/functionajax.php?is=yorum_sil",
    data: 'silinecekid=' + gelenid,                 
    success: function(cevap){
      $("#sonuc")
      .show()
      .html(cevap)
    }
  });
} 