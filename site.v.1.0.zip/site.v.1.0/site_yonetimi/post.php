<?php

/**
 * @author MavRoAySa
 * @copyright 2016
 */
if(isset($sayfa_args[0]) && $sayfa_args[0] == "nws") {
	if(!empty($kullaniciyetki=="admin" || $kullaniciyetki=="yazar")) {
		if(isset($sayfa_args[1]) && $sayfa_args[1] == "nwp") {
			$content.="
    <div class='panel panel-default'>
		<div class='panel-heading'>
			<h3>Yeni Makale Formu</h3>
		</div>
		<div class='panel-body'>
			<div id='sonuc'></div>
			<form id='yenikonueklemeformu' method='post' action='' onsubmit='return false'> 
				<div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
	               <label>Başlık</label>
	               <input type='text' class='form-control' name='baslik'/>
	           </div>
				<div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                    <label>Kategori Seçiniz</label>
                    <select class='form-control' id='kategorisec' name='kategorisec' onchange='etiketlericek();kategorileri_al();logolarigetir()'>
                            <option value=''>Seçiniz</option>";
    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");        
	if($sorgu != null) foreach( $sorgu as $satir ) {
		$catid=$satir['cat_id'];
        $content.="
               				<option value = '$catid'>".$satir['cat_name']."</option>";
    }
    $content.="     </select>
                </div>
				<div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                    <label>Alt Kategori Seçiniz</label>
                    <select class='form-control' id='altkategorisec' name='altkategorisec'>
                        <option value=''>Seçiniz</option>
                    </select>
                </div>
                <div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                    <label>Logo</label>
                    <select class='form-control' id='logo' name='logo'> 
                        <option value=''>Seçiniz</option>
                    </select>
                </div>
                <div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                    <label>Etiketler</label>
                    <select multiple class='form-control' id='etiket' name='etiket[]'> 
                        <option value=''>Seçiniz</option>
                    </select>
                </div>
                <div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                    <label>Yayın Türü</label>
                    <select class='form-control' id='pturu' name='pturu'> 
                        <option value='standard'>Standard</option>
                        <option value='audio'>Audio</option>
                        <option value='video'>Video</option>
                        <option value='link'>Link</option>
                        <option value='quote'>Quote</option>
                        <option value='image'>Image</option>
                    </select>
                </div>
                <div class='form-group' style='width:100%; float:left;'>
                    <script type='text/javascript'>
		                CKEDITOR.replace( 'icerik' );
		            </script>
		            <textarea name='icerik' class='ckeditor'></textarea>
		        </div> 
			</div>
			<div class='panel-footer'>
				<div style='width:10%; float:left; margin-right: 2%;'>
                    <select class='form-control' name='yayinturu' > 
                        <option value='114'>Taslak</option>
                        <option value='571'>Yayınla</option>
                    </select>
                </div>	
	            <button type='submit' class='btn btn-primary' onclick= 'yenigonderi()'>Kaydet</button>
	            <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle</button>
                                  
            </form>		  
        </div
	</div>";
        }
        elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "nwl") {
		  $content.="<!-- Advanced Tables -->
                    <div class='panel panel-default'>
                        <div class='panel-heading'>Tüm Kayıtlar</div>
                        <div class='panel-body'>
                        <div id='sonuc'></div>
                            <div class='table-responsive'>
                                <table class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                    <thead>
                                        <tr> 
                                        	<th>İD</th>
                                            <th>DURUM</th>
                                            <th>BAŞLIK</th>
                                            <th>KATEGORİ</th>
                                            <th>ALTKATEGORİ</th>
                                            <th>ETİKETLER</th>
                                            <th>LOGO</th>
                                            <th>EKLEYEN</th>
                                            <th>EKLENME</th>
                                            <th>GÜNCELLENME</th>
                                            <th>İŞLEM</th>
                                        </tr>
                                    </thead>
                                    <tbody>";
                                    $sorgu = $dbc->vericek("postarticle","");
    								if($sorgu != null) foreach( $sorgu as $satir ) {
    									$durum=$satir['p_bct'];
    									$kategori=$satir['p_cat'];
    									$altkategori=$satir['p_sub'];
    									$logo=$satir['p_logo'];
    									$userid=$satir['p_add'];
    									$guncelleme=$satir['p_update'];
    									if($durum =='114'){
    										$durum = "<img style='margin-left:10px;' src='Style/img/taslak.png'/>";
    									}
    									else{
    										$durum="<img style='margin-left:10px;' src='Style/img/yayında.png'/>";
    									}
    									$baslik=$satir['p_head'];
    									$id=$satir['p_id'];
    									$uzunluk = strlen($baslik);
    									if($uzunluk >= 20){$baslik=metni_sinirla($baslik,10);}
    									$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    										$kategori=$satir2['cat_name'];
    									}
    									$sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
    									if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
    										$altkategori=$satir3['sub_name'];
    									}
    									$sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
    									if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
    										$logo=$satir4['im_name'];
    									}
    									$sorgu5 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
    											$ekleyen=$satir5['user_name'];
    									}
										$content .= "<tr>
														<td>$id </td>
				                                        <td>$durum</td>
				                                        <td><a href='?pg=nws/nwpr/$id'>$baslik</a></td>
				                                        <td>$kategori</td>
				                                        <td>$altkategori</td>
				                                        <td>".$satir['p_tags']."</td>
				                                        <td>$logo</td>
				                                        <td>$ekleyen</td>
				                                        <td>".$satir['p_addtime']."</td>
				                                        <td>$guncelleme</td>
				                            			<td>
															<form method='post' action='' onsubmit='return false'>
																<button class='btn btn-primary' onclick= 'makaleduzenle(".$satir['p_id'].")'><i class='fa fa-pencil-square-o '></i> Düzenle</button>
																<button class='btn btn-danger' onclick= 'makalesil(".$satir['p_id'].")'><i class='fa fa-eraser'></i>Sil</button>
															</form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "nwpr") {
			$gelen_id=$sayfa_args[2];
			$sorgu = $dbc->vericek("postarticle","WHERE p_id='$gelen_id'");
    		if($sorgu != null) foreach( $sorgu as $satir ) {
        		$durum=$satir['p_bct'];
        		$baslik=$satir['p_head'];
        		$icerik=$satir['p_content'];
        		$kategori=$satir['p_cat'];
        		$altkategori=$satir['p_sub'];
        		$logo=$satir['p_logo'];
        		$userid=$satir['p_add'];
        		$guncelleme=$satir['p_update'];
        		$eklenmetarihi=$satir['p_addtime'];
    		}
    		$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
    		if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    			$kategori=$satir2['cat_name'];
    		}
    		$sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
    		if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
    			$altkategori=$satir3['sub_name'];
    		}
    		$sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
    		if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
    			$logo=$satir4['im_name'];
    		}
    		$sorgu5 = $dbc->vericek("users","WHERE user_id=$userid");
    		if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
    			$ekleyen=$satir5['user_name'];
    		}
    		if($durum =='114'){
    			$durum = "<button class='btn btn-danger' onclick= 'yayinla($gelen_id)'><i class='fa fa-share'></i>  Yayınla</button>";
    		}
    		else{
    			$durum="<button class='btn btn-success' onclick='yayindankaldir($gelen_id)'><i class='fa fa-share '></i>  Yayında</button>";
    		}
			$content .= "<div class='panel panel-default'>
							<div class='panel-heading'>
								<div id='sonuc'></div>
									$durum
								<button class='btn btn-default' onclick= 'geridon()'><i class='fa fa-backward'></i>  Geri Dön</button>
                                <h2>$baslik</h2>
								<h5>Ekleyen : $ekleyen &nbsp;&nbsp; Kategori : $kategori &nbsp;&nbsp; Tarih : $eklenmetarihi  </h5>
								</div>
							<div class='panel-body'>
							    <p>$icerik</p>
							</div>
							<div class='panel-footer'>
							    Etiketler : ".$satir['p_tags']."
							</div>
						</div>
					</div>
            <div class='col-sm-12'>
                <div class='panel panel-white post panel-shadow'>
                    <div class='post-heading'>
                        <div class='pull-left image'>
                            <img src='http://bootdey.com/img/Content/user_1.jpg' class='img-circle avatar' alt='user profile image'>
                        </div>
                        <div class='pull-left meta'>
                            <div class='title h5'>
                                <a href='#'><b>Ryan Haywood</b></a>
                                made a post.
                            </div>
                            <h6 class='text-muted time'>1 minute ago</h6>
                        </div>
                    </div> 
                    <div class='post-description'> 
                        <p>Bootdey is a gallery of free snippets resources templates and utilities for bootstrap css hmtl js framework. Codes for developers and web designers</p>
                        <div class='stats'>
                            <a href='#' class='btn btn-default stat-item'>
                                <i class='fa fa-thumbs-up icon'></i>2
                            </a>
                            <a href='#' class='btn btn-default stat-item'>
                                <i class='fa fa-share icon'></i>12
                            </a>
                        </div>
                    </div>
                    <div class='post-footer'>
                        <div class='input-group'> 
                            <input class='form-control' placeholder='Add a comment' type='text'>
                            <span class='input-group-addon'>
                                <a href='#'><i class='fa fa-edit'></i></a>  
                            </span>
                        </div>
                        <ul class='comments-list'>
                            <li class='comment'>
                                <a class='pull-left' href='#'>
                                    <img class='avatar' src='http://bootdey.com/img/Content/user_1.jpg' alt='avatar'>
                                </a>
                                <div class='comment-body'>
                                    <div class='comment-heading'>
                                        <h4 class='user'>Gavino Free</h4>
                                        <h5 class='time'>5 minutes ago</h5>
                                    </div>
                                    <p>Sure, oooooooooooooooohhhhhhhhhhhhhhhh</p>
                                </div>
                                <ul class='comments-list'>
                                    <li class='comment'>
                                        <a class='pull-left' href='#'>
                                            <img class='avatar' src='http://bootdey.com/img/Content/user_3.jpg' alt='avatar'>
                                        </a>
                                        <div class='comment-body'>
                                            <div class='comment-heading'>
                                                <h4 class='user'>Ryan Haywood</h4>
                                                <h5 class='time'>3 minutes ago</h5>
                                            </div>
                                            <p>Relax my friend</p>
                                        </div>
                                    </li> 
                                    <li class='comment'>
                                        <a class='pull-left' href='#'>
                                            <img class='avatar' src='http://bootdey.com/img/Content/user_2.jpg' alt='avatar'>
                                        </a>
                                        <div class='comment-body'>
                                            <div class='comment-heading'>
                                                <h4 class='user'>Gavino Free</h4>
                                                <h5 class='time'>3 minutes ago</h5>
                                            </div>
                                            <p>Ok, cool.</p>
                                        </div>
                                    </li> 
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>";
	    }
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "nwe") {
			$gelen_id=$sayfa_args[2];
        	$sorgu = $dbc->vericek("postarticle","WHERE p_id='$gelen_id'");
			if($sorgu != null) foreach( $sorgu as $satir ) {
				$gelenbaslik=$satir['p_head'];
				$gelenicerik=$satir['p_content'];
				$gelenkategori=$satir['p_cat'];
				$gelenaltkategori=$satir['p_sub'];
				$gelenlogo=$satir['p_logo'];
				$gelenetiketler=$satir['p_tags'];
				$geleneyayindurumu=$satir['p_bct'];
			}
			$gelenetiketlerdizisi=array();
			$gelenetiketlerdizisi = explode (',',$gelenetiketler);
			$content.="<div class='panel panel-default'>
						    <div class='panel-heading'>
						       <h3>Yeni Makale Formu</h3>
						    </div>
						    <div class='panel-body'>
						    	<div id='sonuc'></div>
						    	<form id='yenikonueklemeformu' method='post' action='' onsubmit='return false'> 
							    	<div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
	                                    <label>Başlık</label>
	                                    <input type='text' class='form-control' name='baslik' value='$gelenbaslik'/>
	                                      <input type='hidden' name='id' value='$gelen_id'/>
	                                </div>
									<div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                                        <label>Kategori Seçiniz</label>
                                        <select class='form-control' id='kategorisec' name='kategorisec' onchange='etiketlericek();kategorileri_al();logolarigetir()'>
                                            <option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$k_id=$satir['cat_id'];
										 if($k_id==$gelenkategori){$sec="selected";}else{$sec="";}
               							 $content.="<option value = '$k_id' $sec>".$satir['cat_name']."</option>";
							          }
 
            				 $content.="</select>
                                    </div>
									<div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                                        <label>Alt Kategori Seçiniz</label>
                                      	<select class='form-control' id='altkategorisec' name='altkategorisec'>
                                           <option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$ak_id=$satir['sub_id'];
										 if($ak_id==$gelenaltkategori){$sec="selected";}else{$sec="";}
               							 $content.="<option value = '$ak_id' $sec>".$satir['sub_name']."</option>";
							          }
 
            				 $content.="</select>
                                    </div>
                                    <div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                                        <label>Logo</label>
                                        <select class='form-control' id='logo' name='logo'> 
                                        	option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("images","ORDER BY im_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$im_id=$satir['im_id'];
										 if($im_id==$gelenlogo){$sec="selected";}else{$sec="";}
               							 $content.="<option value = '$im_id' $sec>".$satir['im_name']."</option>";
							          }
 
            				 $content.="</select>
                                    </div>
                                    <div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                                        <label>Etiketler</label>
                                        <select multiple class='form-control' id='etiket' name='etiket[]'> 
                                        	<option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("tags","WHERE tag_cat_name='$gelenkategori'");           
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$k_id=$satir['tag_id'];
										 if(in_array($k_id,$gelenetiketlerdizisi)){$sec="selected";}else{$sec="";}
               							 $content.="<option value = '$k_id' $sec>".$satir['tag_name']."</option>";
							          }
 
            				 $content.="</select>
                                    </div>
                                    <div class='form-group' style='width:100%; float:left;'>
                                        <script type='text/javascript'>
		                  				CKEDITOR.replace( 'icerik' );
		                  				</script>
		                  				<textarea name='icerik' class='ckeditor'>$gelenicerik</textarea>
		                			
                                    </div> 
						    </div>
						    <div class='panel-footer'>
						    	<div style='width:10%; float:left; margin-right: 2%;'>
                                    <select class='form-control' name='yayinturu' > 
                                       	<option value='114'>Taslak</option>
                                        <option value='571'>Yayınla</option>
                                    </select>
                                </div>	
	                                <button type='submit' class='btn btn-primary' onclick= 'guncellemeislemi()'>Güncelle</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle</button>
                                  
                            </form>		  
                        </div
					</div>";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "ctdd") {
			$content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Kategori Ekleme Menüsü</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	<div class='form-group'>
		                                <label>Kategori Adı</label>
		                                <input type='text' class='form-control' name='girilenkategori' value=''/>
		                            </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'kategoriekle()'>Kaydet</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Kategoriler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                            <th>Kategori ID</th>
	                                            <th>Kategori Adı</th>
	                                            <th>Kategori Ekleyen</th>
	                                            <th>Kategori Eklenme Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['cat_id'];
    									$userid=$satir['cat_add'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
										$content .= "<tr>
				                                        <td>".$satir['cat_id']." </td>
				                                        <td>".$satir['cat_name']."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['cat_addtime']."</td>
				                            			<td>
                    <form method='post' action='' onsubmit='return false'>
                    	<button class='btn btn-primary' onclick= 'kategoriduzenle($w)'><i class='fa fa-edit '></i> Düzenle</button>&nbsp;&nbsp;
                    	<button class='btn btn-danger' onclick= 'kategorisil($w)'><i class='fa fa-pencil'></i>Sil</button>
                    </form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "ce"){
            $gelengonid=$sayfa_args[2];
            $sorgu = $dbc->vericek("category","WHERE cat_id='$gelengonid'");
    		if($sorgu != null) foreach( $sorgu as $satir ) {$gelenkategori=$satir['cat_name'];$gelenkategoriid=$satir['cat_id'];}
              
              $content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Kategori Ekleme Menüsü</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	<div class='form-group'>
		                                <label>Kategori Adı</label>
		                                <input type='text' class='form-control' name='girilenkategori' value='$gelenkategori'/>
		                                <input type='hidden' name='girilenkategoriid' value='$gelenkategoriid'/>
		                            </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'kategoriguncelle()'>Güncelle</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Kategoriler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                            <th>Kategori ID</th>
	                                            <th>Kategori Adı</th>
	                                            <th>Kategori Ekleyen</th>
	                                            <th>Kategori Eklenme Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['cat_id'];
    									$userid=$satir['cat_add'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
										$content .= "<tr>
				                                        <td>".$satir['cat_id']." </td>
				                                        <td>".$satir['cat_name']."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['cat_addtime']."</td>
				                            			<td>
            <form method='post' action='' onsubmit='return false'>
            	<button class='btn btn-primary' onclick= 'kategoriduzenle($w)'><i class='fa fa-edit '></i> Düzenle</button>&nbsp;&nbsp;
            	<button class='btn btn-danger' onclick= 'kategorisil($w)'><i class='fa fa-pencil'></i>Sil</button>
            </form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";    
        }
        elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "sctdd") {
			$content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Alt Kategori Ekleme Menüsü</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	<div class='form-group' >
                                        <label>Kategori Seçiniz</label>
                                        <select class='form-control' id='kategorisec'>
                                            <option value='0'>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
               							$content.="
               									<option value = '{$satir['cat_id']}'>".$satir['cat_name']."</option>";
                         				 }
            				 $content.="</select>
                                    </div>
							    	<div class='form-group'>
		                                <label>Alt Kategori Adı</label>
		                                <input type='text' class='form-control' name='girilenaltkategori' value=''/>
		                            </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'altkategoriekle()'>Kaydet</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Alt Kategoriler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                            <th>Alt Kategori ID</th>
	                                            <th>Alt Kategori Adı</th>
	                                            <th>Kategori Adı</th>
	                                            <th>Alt Kategori Ekleyen</th>
	                                            <th>Alt Kategori Eklenme Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['sub_id'];
    									$userid=$satir['sub_add'];
    									$r=$satir['sub_cat_name'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
    									$sorgu3 = $dbc->vericek("category","WHERE cat_id=$r");
    									if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
    											$cat=$satir3['cat_name'];
    									}
										$content .= "<tr>
				                                        <td>".$satir['sub_id']." </td>
				                                        <td>".$satir['sub_name']."</td>
				                                        <td>".$cat."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['sub_addtime']."</td>
				                            			<td>
            <form method='post' action='' onsubmit='return false'>
            	<button class='btn btn-primary' onclick= 'altkategoriduzenle($w)'><i class='fa fa-edit '></i> Düzenle</button>&nbsp;&nbsp;
            	<button class='btn btn-danger' onclick= 'altkategorisil($w)'><i class='fa fa-pencil'></i>Sil</button>
            </form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";
		}
        elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "scte") {
    		$gelengonid=$sayfa_args[2];
            $sorgu = $dbc->vericek("subcategory","WHERE sub_id='$gelengonid'");
    		if($sorgu != null) foreach( $sorgu as $satir ) {
    						$gelenaltkategori=$satir['sub_name'];
    						$gelenaltkategoriid=$satir['sub_id'];
    						$gelenkategori=$satir['sub_cat_name'];
    					}
    			$content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Alt Kategori Ekleme Menüsü</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	<div class='form-group' >
                                        <label>Kategori Seçiniz</label>
                                        <select class='form-control' id='kategorisec'>
                                            <option value='0'>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
                                   if($sorgu != null) foreach( $sorgu as $satir ) {
							               $k_id=$satir['cat_id'];
							               if($k_id==$gelenkategori){$sec="selected";}else{$sec="";}
							                       $content.="<option value = '$k_id' $sec>".$satir['cat_name']."</option>";
							                                    }
                       $content.="</select>
                                    </div>
							    	<div class='form-group'>
		                                <label>Alt Kategori Adı</label>
		                                <input type='text' class='form-control' name='girilenaltkategori' value='$gelenaltkategori'/>
		                                 <input type='hidden' name='girilenaltkategoriid' value='$gelenaltkategoriid'/>
		                            </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'altkategoriguncelle()'>Güncelle</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Alt Kategoriler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                            <th>Alt Kategori ID</th>
	                                            <th>Alt Kategori Adı</th>
	                                            <th>Kategori Adı</th>
	                                            <th>Alt Kategori Ekleyen</th>
	                                            <th>Alt Kategori Eklenme Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['sub_id'];
    									$userid=$satir['sub_add'];
    									$r=$satir['sub_cat_name'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
    									$sorgu3 = $dbc->vericek("category","WHERE cat_id=$r");
    									if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
    											$cat=$satir3['cat_name'];
    									}
										$content .= "<tr>
				                                        <td>".$satir['sub_id']." </td>
				                                        <td>".$satir['sub_name']."</td>
				                                        <td>".$cat."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['sub_addtime']."</td>
				                            			<td>
            <form method='post' action='' onsubmit='return false'>
            	<button class='btn btn-primary' onclick= 'altkategoriduzenle($w)'><i class='fa fa-edit '></i> Düzenle</button>&nbsp;&nbsp;
            	<button class='btn btn-danger' onclick= 'altkategorisil($w)'><i class='fa fa-pencil'></i>Sil</button>
            </form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "tgs") {
			$content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Etiket Düzenleme Formu</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	 <div class='form-group' style='width:48%; float:left; margin-right: 3%;margin-top: 2%;'>
                                        <label>Kategori Seçiniz</label>
                                        <select class='form-control' id='kategorisec' name='kategorisec' onchange='kategorileri_al()'>
                                            <option value='0'>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
               							$content.="
               									<option value = '{$satir['cat_id']}'>".$satir['cat_name']."</option>";
                         				 }
            				 $content.="</select>
                                    </div>
                                    <div class='form-group' style='width:48%; float:right; margin-right: 0%;margin-top: 2%;'>
                                        <label>Alt Kategori Seçiniz</label>
                                        <select class='form-control' id='altkategorisec' name='altkategorisec'>
                                            <option value='0'>Seçiniz</option>
                                   		</select>
                                    </div>
							    	<div class='form-group'>
		                                <label>Etiket Adı Giriniz</label>
		                                <input type='text' class='form-control' name='etiketadi' value=''/>
		                            </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'etiketekle()'>Kaydet</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Etiketler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                            <th>Etiket ID</th>
	                                            <th>Etiket Adı</th>
	                                            <th>Kategorisi</th>
	                                            <th>Alt Kategorisi</th>
												<th>Etiket Ekleyen</th>
	                                            <th>Etiket Eklenme Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("tags","ORDER BY tag_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['tag_id'];
    									$userid=$satir['tag_add'];
    									$ecatid=$satir['tag_cat_name'];
    									$esubid=$satir['tag_sub_name'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
    									$sorgu3 = $dbc->vericek("category","WHERE cat_id=$ecatid");
    									if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
    											$ekategoriadi=$satir3['cat_name'];
    									}
    									$sorgu4 = $dbc->vericek("subcategory","WHERE sub_id=$esubid");
    									if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
    											$ealtkategoriadi=$satir4['sub_name'];
    									}
										$content .= "<tr>
				                                        <td>".$satir['tag_id']." </td>
				                                        <td>".$satir['tag_name']."</td>
				                                        <td>".$ekategoriadi."</td>
				                                        <td>".$ealtkategoriadi."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['tag_addtime']."</td>
				                            			<td>
            <form method='post' onsubmit='return false'>
            	<button class='btn btn-primary' onclick= 'etiketduzenle($w)'><i class='fa fa-edit '></i> Düzenle</button>&nbsp;&nbsp;
            	<button class='btn btn-danger' onclick= 'etiketsil($w)'><i class='fa fa-pencil'></i>Sil</button>
            </form>
                                                   					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";
		}
		elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "tgse") {
			$gelenid=$sayfa_args[2];
	        $sorgu = $dbc->vericek("tags","WHERE tag_id='$gelenid'");
			if($sorgu != null) foreach( $sorgu as $satir ) {
							$gelenetiket=$satir['tag_name'];
							$gelenetiketid=$satir['tag_id'];
							$gelenkategori=$satir['tag_cat_name'];
							$gelenaltkategori=$satir['tag_sub_name'];
						}
			$content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Etiket Düzenleme Formu</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	 <div class='form-group' style='width:48%; float:left; margin-right: 3%;margin-top: 2%;'>
                                        <label>Kategori Seçiniz</label>
                                        <select class='form-control' id='kategorisec' name='kategorisec' onchange='kategorileri_al()'>
                                            <option value='0'>Seçiniz</option>";

                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");
                                   if($sorgu != null) foreach( $sorgu as $satir ) {
							               $k_id=$satir['cat_id'];
							               if($k_id==$gelenkategori){$sec="selected";}else{$sec="";}
							                       $content.="<option value = '$k_id' $sec>".$satir['cat_name']."</option>";
							                                    } 
            				 $content.="</select>
                                    </div>
                                    <div class='form-group' style='width:48%; float:right; margin-right: 0%;margin-top: 2%;'>
                                        <label>Alt Kategori Seçiniz</label>
                                        <select class='form-control' id='altkategorisec' name='altkategorisec'>
                                           <option value='0'>Seçiniz</option>";

                                    $sorgu = $dbc->vericek("subcategory","ORDER BY sub_id DESC");
                                   if($sorgu != null) foreach( $sorgu as $satir ) {
							               $ak_id=$satir['sub_id'];
							               if($ak_id==$gelenaltkategori){$sec="selected";}else{$sec="";}
							                       $content.="<option value = '$ak_id' $sec>".$satir['sub_name']."</option>";
							                                    } 
            				 $content.="</select>
                                    </div>
							    	<div class='form-group'>
		                                <label>Etiket Adı</label>
		                                <input type='text' class='form-control' name='etiketadi' value='$gelenetiket'/>
		                                <input type='hidden' name='girilenetiketid' value='$gelenetiketid'/>
		                                <input type='hidden' name='gelenaltkategori' value='$gelenaltkategori'/>
		                            </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'etiketguncelle()'>Güncelle</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Etiketler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                            <th>Etiket ID</th>
	                                            <th>Etiket Adı</th>
	                                            <th>Kategorisi</th>
	                                            <th>Alt Kategorisi</th>
												<th>Etiket Ekleyen</th>
	                                            <th>Etiket Eklenme Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("tags","ORDER BY tag_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['tag_id'];
    									$userid=$satir['tag_add'];
    									$ecatid=$satir['tag_cat_name'];
    									$esubid=$satir['tag_sub_name'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
    									$sorgu3 = $dbc->vericek("category","WHERE cat_id=$ecatid");
    									if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
    											$ekategoriadi=$satir3['cat_name'];
    									}
    									$sorgu4 = $dbc->vericek("subcategory","WHERE sub_id=$esubid");
    									if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
    											$ealtkategoriadi=$satir4['sub_name'];
    									}
										$content .= "<tr>
				                                        <td>".$satir['tag_id']." </td>
				                                        <td>".$satir['tag_name']."</td>
				                                        <td>".$ekategoriadi."</td>
				                                        <td>".$ealtkategoriadi."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['tag_addtime']."</td>
				                            			<td>
            <form method='post' onsubmit='return false'>
            	<button class='btn btn-primary' onclick= 'etiketduzenle($w)'><i class='fa fa-edit '></i> Düzenle</button>&nbsp;&nbsp;
            	<button class='btn btn-danger' onclick= 'etiketsil($w)'><i class='fa fa-pencil'></i>Sil</button>
            </form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";
		}
        elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "cmmntl") {
            $content.="
            <div class='panel panel-default'>
                <div class='panel-heading'>Tüm Kayıtlar</div>
                <div class='panel-body'>
                    <div id='sonuc'></div>
                    <div class='table-responsive'>
                        <table class='table table-striped table-bordered table-hover' id='dataTables-example'>
                            <thead>
                                <tr> 
                                    <th>ID</th>
                                    <th>DURUM</th>
                                    <th>ADI</th>
                                    <th>POST_ID</th>
                                    <th>YORUM</th>
                                    <th>YORUM_ID</th>
                                    <th>EKLENME</th>
                                    <th>İŞLEM</th>
                                </tr>
                            </thead>
                        <tbody>";
            $sorgu = $dbc->vericek("comments","");
            if($sorgu != null) foreach( $sorgu as $satir ) {
                $id=$satir['com_id'];
                $durum=$satir['com_status'];
                $name=$satir['com_name'];
                $article_id=$satir['com_article'];
                $userid=$satir['com_user'];
                $eklenme=$satir['com_addtime'];
                $comment=$satir['com_comment'];
                $comment_tam=$satir['com_comment'];
                $uzunluk = strlen($comment);
                if($uzunluk >= 50){$comment=metni_sinirla($comment,50);}
                if($durum =='0'){
                    $durum = "<img style='margin-left:10px;' src='Style/img/taslak.png'/>";
                    $yayin="yorumyayinla";
                    $buton="Yayınla";
                }
                else{
                    $durum="<img style='margin-left:10px;' src='Style/img/yayında.png'/>";
                    $yayin="yorumyayindankaldir";
                     $buton="Yayından Kaldır";

                }
                $content .= "<tr>
                                <td>$id</td>
                                <td>$durum</td>
                                <td>$name</td>
                                <td>$article_id</td>
                                <td>
                                    <div id='mesaj'>
                                        <p>
                                           <a class='aciklama' href='#' data-title=' $comment_tam'>$comment</a>
                                            
                                        </p>
                                    </div>
                                </td>
                                <td>$userid</td>
                                <td>$eklenme</td>
                                <td>
                                    <form method='post' action='' onsubmit='return false'>
                                        <button class='btn btn-primary' onclick= '$yayin(".$id.")'><i></i> $buton</button>
                                        <button class='btn btn-danger' onclick= 'yorumsil(".$id.")'><i class='fa fa-eraser'></i>Sil</button>
                                    </form>
                                </td>
                            </tr>";
            }
               $content.="</tbody>
                        </table>
                    </div>
                 </div>
            </div>";    
        }
		else{
    		$content.="  
    		<div class='wrap'>
    			<div class='logo'>
    				<h1>204</h1>
    				<p>İçerik Görüntülenemiyor!!!!!!!!!</p>
    			</div>
    		</div>";
		   
		}		
	}
	else{  
		 header('HTTP/1.0 401 Not Found');
			echo "  <link href='Style/css/custom.css' rel='stylesheet' />
					<div class='wrap'>
				   		<div class='logo'>
				   			<h1>401</h1>
				    		<p>Sayfayı Görüntüleme Yetkiniz Bulunmamaktadır!!!!!!</p>
			  	      		<div class='sub'>
				        		<p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
				     	 	</div>
			        	</div>
					</div>";
		    exit();
	}

}
else{ 
	if (strstr($_SERVER['REQUEST_URI'],'post.php')){
    header('HTTP/1.0 404 Not Found');
	echo "  <link href='Style/css/custom.css' rel='stylesheet' />
			<div class='wrap'>
		   		<div class='logo'>
		   			<h1>404</h1>
		    		<p>Aradığınız Sayfayı Yapmyı Unuttuk Galiba!!!!!!</p>
	  	      		<div class='sub'>
		        		<p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
		     	 	</div>
	        	</div>
			</div>";
    exit();
    }
	
}


?>