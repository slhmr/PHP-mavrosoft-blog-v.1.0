<?php
/**
 * @author MavRoAySa
 * @copyright 2016
 */

if(isset($sayfa_args[0]) && $sayfa_args[0] == "gplv") {
	if(!empty($kullaniciyetki=="admin" || $kullaniciyetki=="yazar")) {
		if(isset($sayfa_args[1]) && $sayfa_args[1] == "lg") {
			$content.="	
			<form action='' method='' onsubmit='return false' >
				<div class='panel panel-default'>
					<div class='panel-heading'>
						<h3>Logo İşlemleri Formu</h3>
					</div>
					<div class='panel-body'>
			            <div class='form-group' style='width:30%;margin-right:1%;float:left;'>
                            <legend>Galeri Seç</legend>
                            <select style='width:95%;' id='kategorisec'  class='form-control' aria-required='true'>
                                <option value=''>Seçiniz</option>";
            $sorgu=$dbc->vericek("gallery","ORDER BY g_id DESC");
            if($sorgu != null) foreach( $sorgu as $satir ) {
            	$content.="
            					<option value = '{$satir['g_id']}'>".$satir['g_name']."</option>";
                                                    }
                $content.="
                            </select>
						</div>
						<div class='form-group' style='width:30%;margin-right:1%;float:left;'>
                            <legend>İsim Gir</legend>
                            <input type='text' class='form-control' name='logoisim' id='logoisim'/>
						</div> 
                        <div class='form-group' style='width:30%;margin-right:1%;float:left;'>
                            <legend>Dosya Seç</legend>
                            <input id='file_upload' type='file' name='file_upload'>
						</div> 
						<div class='form-group' style='margin-right:1%;width:90%; float:left;'>
				            <div id='sonuc'></div>
						</div>                                         
					</div>
					<div class='panel-footer'>
			            <button type='submit' class='btn btn-primary' onclick= 'resimyukle()'>Yükle</button>
			            <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle</button>
		            </div>
		        </div>
			</form>";
		$content.="
			<div class='panel panel-default'>
                <div class='panel-heading'>Kayıtlı Resim Dosyaları</div>
                    <div class='panel-body'>
                        <div class='table-responsive'><div id='sonuc_2'></div>
                            <table class='table table-striped table-bordered table-hover' id='dataTables-example'>
                                <thead>
	                                <tr>
	                                    <th>Resim ID</th>
	                                    <th>Resim Adı</th>
	                                    <th>Resim Tipi</th>
	                                    <th>Resim Boyutu</th>
	                                    <th>Resim Galeri</th>
	                                    <th>Resim Path</th>
	                                    <th>Resim Ekleyen</th>
	                                    <th>Resim Tarihi</th>
	                                    <th>İşlemler</th>
	                                </tr>
	                            </thead>
                                <tbody>";
		$sorgu = $dbc->vericek("images","ORDER BY im_id DESC");
		if($sorgu != null) foreach( $sorgu as $satir ) {
    		$w=$satir['im_id'];
    		$userid=$satir['im_add'];
    		$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    		if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    			$ekleyen=$satir2['user_name'];
    		}
    		$galeri=$satir['im_name'];
		$content .= "
									<tr>
				                        <td>".$satir['im_id']." </td>
				                        <td>".$satir['im_name']."</td>
				                        <td>".$satir['im_type']."</td>
				                        <td>".$satir['im_size']."</td>
				                        <td>".$satir['im_gallery']."</td>                    
				                        <td>".$satir['im_path']."</td>
				                        <td>".$ekleyen."</td>
				                        <td>".$satir['im_addtime']."</td>
				                        <td>
											<form method='' action='' onsubmit='return false'>
												<button class='btn btn-danger' onclick= 'resimsil($w)'><i class='fa fa-pencil'></i>Sil</button>
											</form>
                                       	</td>
                           			</tr>";
        }
		$content .= "
								</tbody>
	                        </table>
		              	</div>
                    </div>";
	}
	if(isset($sayfa_args[1]) && $sayfa_args[1] == "gllry") {	
		$content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Galeri İşlemleri Formu</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	<div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
		                                <label>Galeri Adı Giriniz</label>
		                                <input type='text' class='form-control' name='girilengaleri' value=''/>
		                            </div>
		                            <div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                                        <label>Kategori Seçiniz</label>
                                        <select class='form-control' id='kategorisec' name='kategorisec' onchange='kategorileri_al()'>
                                            <option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$catid=$satir['cat_id'];
               							$content.="
               									<option value = '$catid'>".$satir['cat_name']."</option>";
                         				 }
            				 $content.="</select>
                                    </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'galeriekle()'>Kaydet</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Galeriler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                           <th>ID</th>
	                                            <th>Adı</th>
	                                            <th>Kategori</th>
	                                            <th>Kayıt Sayısı</th>
	                                            <th>Toplam Kayıt Sayısı</th>
	                                            <th>Dosya Boyutu</th>
	                                            <th>Ekleyen</th>
	                                            <th>Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("gallery","ORDER BY g_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['g_id'];
    									$userid=$satir['g_add'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
    									$galeri=$satir['g_name'];
    									$galery_boyut=klasor_boyutu($galeri);
    									$klasor_dosya_say=sayibul($galeri);
										$content .= "<tr>
				                                        <td>".$satir['g_id']." </td>
				                                        <td>".$satir['g_name']."</td>
				                                        <td>".$satir['g_category']."</td>
				                                        <th></th>
				                                        <td>".$klasor_dosya_say."</td>                    
				                                        <td>".$galery_boyut."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['g_addtime']."</td>
				                            			<td>
			<form method='post' action='' onsubmit='return false'>
				<button class='btn btn-primary' onclick= 'galeriduzenle($w)'><i class='fa fa-edit '></i> Düzenle</button>
				<button class='btn btn-danger' onclick= 'galerisil($w)'><i class='fa fa-pencil'></i>Sil</button>
			</form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";
        
		}
elseif(isset($sayfa_args[1]) && $sayfa_args[1] == "gllrye") {
		$gelengaid=$sayfa_args[2];
        $sorgu = $dbc->vericek("gallery","WHERE g_id='$gelengaid'");
		if($sorgu != null) foreach( $sorgu as $satir ) {
						$gelengaleriadi=$satir['g_name'];
						$gelengaleriid=$satir['g_id'];
					}
			$content.="<form method='post' action='' onsubmit='return false'>
							<div class='panel panel-default'>
						    	<div class='panel-heading'>
						       		<h3>Galeri İşlemleri Formu</h3>
						    	</div>
						    	<div class='panel-body'>
							    	<div id='mesaj'></div>
							    	<div class='form-group'  style='width:30%; float:left; margin-right: 3%;'>
		                                <label>Galeri Adı Giriniz</label>
		                                <input type='text' class='form-control' name='girilengaleri' value='$gelengaleriadi'/>
		                                 <input type='hidden' name='girilengaleriid' value='$gelengaleriid'/>
		                            </div>
		                            <div class='form-group' style='width:30%; float:left; margin-right: 3%;'>
                                        <label>Kategori Seçiniz</label>
                                        <select class='form-control' id='kategorisec' name='kategorisec' onchange='kategorileri_al()'>
                                            <option value=''>Seçiniz</option>";
                                    $sorgu = $dbc->vericek("category","ORDER BY cat_id DESC");        
									if($sorgu != null) foreach( $sorgu as $satir ) {
										$catid=$satir['cat_id'];
               							$content.="
               									<option value = '$catid'>".$satir['cat_name']."</option>";
                         				 }
            				 $content.="</select>
                                    </div>
	                        	</div>
						    	<div class='panel-footer'>
	                            	<button type='submit' class='btn btn-primary' onclick= 'galeriguncelle()'>Güncelle</button>
	                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle </button>
                        		</div
							</div>
						</form><br></div>";
			$content.="<div class='panel panel-default'>
                        	<div class='panel-heading'>
                            	Kayıtlı Galeriler
                        	</div>
                        	<div class='panel-body'>
                            	<div class='table-responsive'>
                                	<table class='table table-striped table-bordered table-hover'>
                                    	<thead>
	                                        <tr>
	                                            <th>ID</th>
	                                            <th>Adı</th>
	                                            <th>Kayıt Sayısı</th>
	                                            <th>Toplam Kayıt Sayısı</th>
	                                            <th>Dosya Boyutu</th>
	                                            <th>Ekleyen</th>
	                                            <th>Tarihi</th>
	                                            <th>İşlemler</th>
	                                        </tr>
	                                    </thead>
                                		<tbody>";
										$sorgu = $dbc->vericek("gallery","ORDER BY g_id DESC");
										if($sorgu != null) foreach( $sorgu as $satir ) {
    									$w=$satir['g_id'];
    									$userid=$satir['g_add'];
    									$sorgu2 = $dbc->vericek("users","WHERE user_id=$userid");
    									if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
    											$ekleyen=$satir2['user_name'];
    									}
    									$galeri=$satir['g_name'];
    									$galery_boyut=klasor_boyutu($galeri);
    									$klasor_dosya_say=sayibul($galeri);
										$content .= "<tr>
				                                        <td>".$satir['g_id']." </td>
				                                        <td>".$satir['g_name']."</td>
				                                        <th>Galeri Kayıt Sayısı</th>
				                                        <td>".$klasor_dosya_say."</td>
				                                        <td>".$galery_boyut."</td>
				                            			<td>".$ekleyen."</td>
				                            			<td>".$satir['g_addtime']."</td>
				                            			<td>
<form method='post' action='' onsubmit='return false'>
	<button class='btn btn-primary' onclick= 'galeriduzenle($w)' disabled><i class='fa fa-edit '></i> Düzenle</button>
	<button class='btn btn-danger' onclick= 'galerisil($w)'><i class='fa fa-pencil'></i>Sil</button>
</form>
                                       					 </td>
                           							</tr>";
                                       				}

                   						 $content .= "</tbody>
	                        			</table>
		              				</div>
                        		</div>
                    		";
		}
	}
	else{  
		 header('HTTP/1.0 401 Not Found');
			echo "  <link href='Style/css/custom.css' rel='stylesheet' />
					<div class='wrap'>
				   		<div class='logo'>
				   			<h1>401</h1>
				    		<p>Sayfayı Görüntüleme Yetkiniz Bulunmamaktadır!!!!!!</p>
			  	      		<div class='sub'>
				        		<p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
				     	 	</div>
			        	</div>
					</div>";
		    exit();
	}

}
else{ 
	if (strstr($_SERVER['REQUEST_URI'],'media.php')){
    header('HTTP/1.0 404 Not Found');
	echo "  <link href='Style/css/custom.css' rel='stylesheet' />
			<div class='wrap'>
		   		<div class='logo'>
		   			<h1>404</h1>
		    		<p>Aradığınız Sayfayı Yapmyı Unuttuk Galiba!!!!!!</p>
	  	      		<div class='sub'>
		        		<p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
		     	 	</div>
	        	</div>
			</div>";
    exit();
}
	
}


?>
