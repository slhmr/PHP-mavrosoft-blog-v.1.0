<?php

/**
 * @author MavRoAySa
 * @copyright 2016
 */
if(isset($sayfa_args[0]) && $sayfa_args[0] == "sttg") {
    if(!empty($kullaniciyetki=="admin")) {
        if(isset($sayfa_args[1]) && $sayfa_args[1] == "nwsttng") {
            $content.="<div class='panel panel-default'>
                        <div class='panel-heading'>
                            <h3>Site Ayarları Formu</h3>
                        </div>
                        <form id='siteayarlariformu' method='post' action='' onsubmit='return false'> 
                            <div class='panel-body'>
                            <div id='sonuc'></div>
                            
                                <div class='form-group' style='width:100%; float:left; margin-right: 3%;'>
                                    <label>Site Adı</label>
                                    <input type='text' class='form-control' name='site_adi'/>
                                </div>
                                <div class='form-group' style='width:100%; float:left; margin-right: 3%;'>
                                    <label>Site Adı</label>
                                    <input type='text' class='form-control' name='site_adi'/>
                                </div>
                            </div>
                            <div class='panel-footer'>
                                <button type='submit' class='btn btn-primary' onclick= 'yenigonderi()'>Kaydet</button>
                                <button type='reset' class='btn btn-primary' onclick= 'sayfayiyenile()'>Temizle</button>
                                  
                            </div
                        </form>
                    </div>";
        }
    }
    else{  
         header('HTTP/1.0 401 Not Found');
            echo "  <link href='Style/css/custom.css' rel='stylesheet' />
                    <div class='wrap'>
                        <div class='logo'>
                            <h1>401</h1>
                            <p>Sayfayı Görüntüleme Yetkiniz Bulunmamaktadır!!!!!!</p>
                            <div class='sub'>
                                <p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
                            </div>
                        </div>
                    </div>";
            exit();
    }

}
else{ 
    if (strstr($_SERVER['REQUEST_URI'],'site_ayar.php')){
    header('HTTP/1.0 404 Not Found');
    echo "<link href='Style/css/custom.css' rel='stylesheet' />
            <div class='wrap'>
                <div class='logo'>
                    <h1>404</h1>
                    <p>Aradığınız Sayfayı Yapmyı Unuttuk Galiba!!!!!!</p>
                    <div class='sub'>
                        <p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
                    </div>
                </div>
            </div>";
    exit();
    }
    
}
?>
