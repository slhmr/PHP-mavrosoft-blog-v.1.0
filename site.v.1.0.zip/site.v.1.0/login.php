<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */

if(isset($_SESSION['user_session']) ==''){
	if(isset($sayfa_args[0]) && $sayfa_args[0] == "sign_in") {	
		$class="home";
		//$top_pagination="<a href='index.php'>AnaSayfa</a><a href='#' class='active'>Giriş Yap</a>";
		$content.="
				<div id='log_in'>
				  <h1>MavRoSoft</h1>
				  <p>Kullanıcı Giriş Formu</p>  
				  <form class='form-signin' id='login-form' method='' action='' role='form' onsubmit='return false'>
				  <div id='sonuc'></div>
				    <div id='form-login-username' class='input-group'>
				      <input id='username' class='input-field' name='user_email' type='text' size='18' alt='Kullanıcı adı yada email' placeholder='Kullanıcı adı yada email' required />
				    </div>
				    <div id='form-login-password' class='input-group'>
				      <input id='passwd' class='input-field' name='password' type='password' size='18' alt='Şifre' placeholder='Şifre' required>
				    </div>
				    <div id='form-login-remember' class='input-group'>
				      <input id='remember' class='input-field' name='remember' type='checkbox' value='yes' alt='Beni Hatırla' >
				      <label for='remember'>Beni Hatırla</label>
				    </div>
				    <div id='submit-buton' class='input-group'>
					    <button type='submit' class='btn btn-ok input-field' name='btn-login' id='btn-login' onclick= 'girisyap()'>
		    				<span class='glyphicon glyphicon-log-in'></span> &nbsp; Giriş Yap
						</button> 
						
					</div>
				  </form>
				</div>";
	}
	else{
		if (strstr($_SERVER['REQUEST_URI'],'login.php')){
		    header('HTTP/1.0 404 Not Found');
			$content.="  <link href='Style/css/custom.css' rel='stylesheet' />
					<div class='wrap'>
				   		<div class='logo'>
				   			<h1>404</h1>
				    		<p>Aradığınız Sayfayı Yapmyı Unuttuk Galiba!!!!!!</p>
			  	      		<div class='sub'>
				        		<p><a class='btn btn-default' href='index.php'>Siteye Git</a></p>
				     	 	</div>
			        	</div>
					</div>";
	    exit();
		}
	}
}
else{  
	$class="";
		$content.=" <link href='Style/css/custom.css' rel='stylesheet' />
			<div id='log_in'>
				  
				<h1>Hata</h1>
				<p>Kullanıcı Giriş Yapmış.....</p>
				<div class='sub'>
					   
				</div>
			</div>";
	
}		
?>