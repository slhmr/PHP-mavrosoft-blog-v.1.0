<?php
/*
 @author MavRoSofT
 @copyright 2017
 */
session_start();
ob_start();
require_once("include/sayfalama_class.php");
require_once("include/default.php");
require_once("include/function.php");
require_once("include/class.user.php");

$dbc = new user();
$dbs = new Database();
$page = isset($_GET["page"]) ? $_GET["page"] : "page";
$sayfa_args = explode("/",$page);

if(isset($_SESSION['user_session'])!=''){
	$id=$_SESSION['user_session'];
	$sorgu=$dbc->vericek("users","Where user_id='$id'");
	if($sorgu != null )foreach ($sorgu as $satir ) {
		$adi=$satir['user_real_name'];
		$kadi=$satir['user_name'];
		$email=$satir['user_email'];
		$resim=$satir['user_profile_pic'];
		$dtarih=$satir['user_dtarih'];
		$yetki=$satir['user_status'];
	}
	
	$kullanici.="
		<div id='dd' class='wrapper-dropdown-5' tabindex='1'>$kadi
			<ul class='dropdown'>
				<li><a href='#'><i class='entypo-user'></i>Profilim</a></li>
				<li><a href='#'><i class='entypo-cog'></i>Ayarlarım</a></li>";
				if($yetki==="admin"){$kullanici.="<li><a href='site_yonetimi/home.php'><i class='entypo-database'></i>Yönetim Paneli</a></li>";}
		$kullanici.="
				<li><a href='include/logout.php'><i class='entypo-cross'></i>Çıkış Yap</a></li>
			</ul>
		</div>
		<script src='Style/js/jquery-1.8.2.min.js'></script>
		<script type='text/javascript'>
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;
					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}
			$(function() {
				var dd = new DropDown( $('#dd') );
				$(document).click(function() {
					$('.wrapper-dropdown-5').removeClass('active');
				});

			});
		</script>";
	
}
else{
	$kullanici.="<a href='?page=sign_in' id='loginform'>Üye Girişi</a>&nbsp;|&nbsp;<a href='#'>Üye Ol</a>";
}

switch($sayfa_args[0]) {
    case "single" : include "post_article.php"; break;
   	case "cat" : include "post_article.php"; break;
   	case "sub" : include "post_article.php"; break;
   	case "search" : include "post_article.php"; break;
   	case "arsive" : include "post_article.php"; break;
   	case "tags" : include "post_article.php"; break;
   	case "sign_in" : include "login.php"; break;

    default :
    	$class="home";
    	$top_pagination="<a href='index.php' class='active'>AnaSayfa</a>";
    	$content.="
		    	<!-- MAIN -->
				<div id='main'>
					<div class='wrapper cf'>
					<!-- featured -->
						<div class='home-featured'>
						
							<ul id='filter-buttons'>
								<li><a href='#' data-filter='*' class='selected'>Tümünü Göster</a></li>";
			$sorgu=$dbc->vericek("category","ORDER BY cat_name ASC");
			if($sorgu != null) foreach( $sorgu as $satir ) {
				$h_menu=$satir['cat_name'];	
				$h_id=$satir['cat_id'];	 
	  	$content.="<li><a href='#' data-filter='.$h_id'>$h_menu</a></li>";
					}
		$content.="</ul>
					<!-- Filter container -->
							<div id='filter-container' class='cf'>";
				
    		$sorgu=$dbc->vericek("postarticle","WHERE p_bct='571' ORDER BY p_id DESC");
    		if($sorgu != null) foreach( $sorgu as $satir ) {
				$id=$satir['p_id'];
				$baslik=$satir['p_head'];
				$icerik=$satir['p_content'];
				$kategori=$satir['p_cat'];
				$altkategori=$satir['p_sub'];
				$logo=$satir['p_logo'];
				$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
	    		if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
	    			$kategori=$satir2['cat_name'];
	    		}
	    		$sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
	    		if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
	    			$altkategori=$satir3['sub_name'];
	    		}
	    		$sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
	    		if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
	    			$logo=$satir4['im_name'];
	    			$gallery_id=$satir4['im_gallery'];
	    			$sorgugallery=$dbc->vericek("gallery","WHERE g_id='$gallery_id '");
	    			if($sorgugallery != null) foreach( $sorgugallery as $satirgallery ) {
	    				$g_name=$satirgallery['g_name'];
	    			}
	    		}
				$uzunluk = strlen($icerik);
    			if($uzunluk >= 200){$icerik=metni_sinirla($icerik,200);}

    	$content.="
    		<figure class='".$satir['p_cat']."'>
				<a href='?page=single/article/$id' class='thumb'>
					<img src='Galeriler/$g_name/$logo'/>
				</a>
				<figcaption>
					<a href='?page=single/article/$id'>
						<h3 class='heading'>$baslik</h3>
					</a>
					$icerik 
				</figcaption>
			</figure>";
		}
		$content.="
				</div><!-- ENDS Filter container -->
				
			</div>
			<!-- ENDS featured -->
			</div><!-- ENDS WRAPPER -->
		</div>
		<!-- ENDS MAIN -->";
				

}
include "header.php";
include "content.php"; 
if($page !="page" && $page !="sign_in"){
include "sidebar.php";	
}
include "footer.php"; 


ob_end_flush();


?>