<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */
$header_menu.="
<html class='no-js'>
	<head>
		<meta charset='utf-8'/>
		<title>mavrosoft</title>
		
		<!--[if lt IE 9]>
			<script src='http://html5shim.googlecode.com/svn/trunk/html5.js'></script>
		<![endif]-->
		<link rel='stylesheet' media='all' href='Style/css/style.css'/>
		<meta name='viewport' content='width=device-width, initial-scale=1'/>
		<!-- Adding 'maximum-scale=1' fixes the Mobile Safari auto-zoom bug: http://filamentgroup.com/examples/iosScaleBug/ -->		
				
		<!-- JS -->
		<script src='Style/js/jquery-1.7.1.min.js'></script>
		<script src='Style/js/custom.js'></script>
		<script src='Style/js/tabs.js'></script>
		<script src='Style/js/css3-mediaqueries.js'></script>
		<script src='Style/js/jquery.columnizer.min.js'></script>
		
		<!-- Isotope -->
		<script src='Style/js/jquery.isotope.min.js'></script>
		
		<!-- Lof slider -->
		<script src='Style/js/jquery.easing.js'></script>
		<script src='Style/js/lof-slider.js'></script>
		<link rel='stylesheet' href='Style/css/lof-slider.css' media='all'  /> 
		<!-- ENDS slider -->
		
		<!-- Tweet -->
		<link rel='stylesheet' href='Style/css/jquery.tweet.css' media='all'  /> 
		<script src='Style/js/tweet/jquery.tweet.js' ></script> 
		<!-- ENDS Tweet -->
		
		<!-- superfish -->
		<link rel='stylesheet' media='screen' href='Style/css/superfish.css' /> 
		<script  src='Style/js/superfish-1.4.8/js/hoverIntent.js'></script>
		<script  src='Style/js/superfish-1.4.8/js/superfish.js'></script>
		<script  src='Style/js/superfish-1.4.8/js/supersubs.js'></script>
		<!-- ENDS superfish -->
		
		<!-- prettyPhoto -->
		<script  src='Style/js/prettyPhoto/js/jquery.prettyPhoto.js'></script>
		<link rel='stylesheet' href='Style/js/prettyPhoto/css/prettyPhoto.css'  media='screen' />
		<!-- ENDS prettyPhoto -->
		
		<!-- poshytip -->
		<link rel='stylesheet' href='Style/js/poshytip-1.1/src/tip-twitter/tip-twitter.css'  />
		<link rel='stylesheet' href='Style/js/poshytip-1.1/src/tip-yellowsimple/tip-yellowsimple.css'  />
		<script  src='Style/js/poshytip-1.1/src/jquery.poshytip.min.js'></script>
		<!-- ENDS poshytip -->
		
		<!-- JCarousel -->
		<script type='text/javascript' src='Style/js/jquery.jcarousel.min.js'></script>
		<link rel='stylesheet' media='screen' href='Style/css/carousel.css' /> 
		<!-- ENDS JCarousel -->
		
		<!-- GOOGLE FONTS -->
		<link href='http://fonts.googleapis.com/css?family=Voltaire' rel='stylesheet' type='text/css'>

		<!-- modernizr -->
		<script src='Style/js/modernizr.js'></script>
		
		<!-- SKIN -->
		<link rel='stylesheet' media='all' href='Style//css/skin.css'/>
		<link rel='stylesheet' media='all' href='Style/css/header-search.css'/>
		
		<!-- Less framework -->
		<link rel='stylesheet' media='all' href='Style/css/lessframework.css'/>
		
		<!-- jplayer -->
		<link href='Style/player-skin/jplayer-black-and-yellow.css' rel='stylesheet' type='text/css' />
		<script type='text/javascript' src='Style/js/jquery.jplayer.min.js'></script>
		
		<!-- flexslider -->
		<link rel='stylesheet' href='Style/css/flexslider.css' >
		<script src='Style/js/jquery.flexslider.js'></script>

		<!-- login -->
		<link rel='stylesheet' href='Style/css/login.css'/>
		<script src='Style/js/login.js'></script>
		<script src='Style/js/validation.min.js'></script>

		<!-- tab widget -->
		<script src='Style/js/tabwidget.js'></script>
		<link rel='stylesheet' type='text/css' href='Style/css/tabwidget.css'/>

		<!-- pagination -->
		<link rel='stylesheet' media='screen' href='Style/css/pagination.css' />
		
		<!--share-->
		<link rel='stylesheet' href='Style/css/font-awesome.min.css'/>
		<script src='Style/js/sharer.min.js'></script>
		<script src='Style/js/bootstrap.min.js'></script>

	</head>
<body class='$class'>
	<!-- HEADER -->
	<div class='top_contact_info'><!-- Top header bar --> 
       <div class='top_container'>
        	<ul class='tci_list cf sb' id='social-bar'>
               <li></li> 
            </ul>
            <ul class='tci_list_right'>
             	<li>
             		<div id='navthing'>$kullanici</div>
				</li>
            </ul>
        </div>
    </div><!-- end top contact info -->
		<header>
			<div class='wrapper cf'>
				<div id='logo'>
					<a href='index.php'><img  src='Style/img/logo.png' alt=''></a>
				</div>
				
				<!-- nav --><div id='nav'>
				<ul id='nav butoncerceve' class='sf-menu'>";				
					$sorgu=$dbc->vericek("category","ORDER BY cat_name ASC");
					if($sorgu != null) foreach( $sorgu as $satir ) {
						$h_menu=$satir['cat_name'];	
						$h_id=$satir['cat_id'];
						if($page =="cat/".$h_id){
							 $class="aktif";
						}	
						else{
							$class="";
						}					 
	   $header_menu.="<li class='buton $class'><a href='?page=cat/$h_id'><span>$h_menu</span></a></li>";
					}
					if($page =="yazarlar/"){
							 $class="aktif";
						}	
						else{
							$class="";
						}
   $header_menu.="
   					<li class='buton $class'><a href='?page=yazarlar'><span>Yazarlarımız</span></a></li>
   				</ul></div>
				<div id='combo-holder'></div>
				<div id='nav'></div>
				
				<!-- ends nav -->
			</div> 
		</header>

		<header class='header-search'>
		<div class='header-navi'>
				<div class='breadcrumb flat'>
					$top_pagination
				</div>
			</div>
			<div class='header-limiter'>
				
				<form class='form-wrapper cf' id='aramaformu' method='post' action='?page=search/#'>
				  	<input type='text' placeholder='Ara...' required name='aranacakkelime'/>
					<button type='submit' onclick= 'ara()'>Ara</button>
				</form>
			</div>
		</header>

		<!-- ENDS HEADER -->";
		if($page != "page" && $page !="sign_in"){
			$header_menu.="
			<!-- MAIN -->
		<div id='main'>
			<div class='wrapper cf'>
				<!-- posts list -->
	        	<div id='posts-list' class='cf'>";
		}
print $header_menu;
?>