<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */


function sifreuret($x) {
    if (defined("CRYPT_BLOWFISH") && CRYPT_BLOWFISH) {
        $salt = '$2y$11$' . substr(md5(uniqid(rand(), true)), 0, 32);
        return crypt($x, $salt);
    }
}

function ajaxistegikontrol(){
    $header = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? $_SERVER['HTTP_X_REQUESTED_WITH'] : null;
    return ($header === 'XMLHttpRequest');
	}
function metni_sinirla($metin,$sinir){
 	$uzunluk = strlen($metin);
 	if ($uzunluk > $sinir) {
 		$icerik = substr($metin,0,$sinir) . ".....";
 	}
 return $icerik;
}	
function ayyaz($x){
	$donustur = array(  
        '00' => '0',  
        '01' => '1',  
        '02' => '2',  
        '03' => '3',  
        '04' => '4',  
        '05' => '5',  
        '06' => '6',  
        '07' => '7',  
        '08' => '8',  
        '09' => '9',  
        '10' => '10',  
        '11' => '11', 
    );  
    $y=$donustur[$x];
 	$aylar =array("Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül"			,"Ekim","Kasım","Aralık"); 
 	
 return $aylar[$y];
}
function gecensure($date){

        $today = date('Y-m-d H:i:s');
        $today_seconds = strtotime($today); 
        $date_seconds = strtotime($date);
        $diff = $today_seconds - $date_seconds; 

        if($diff > 0 && $diff < 60){
            $passed_time = $diff." Saniye Önce";
        }else if($diff >= 60 && $diff < 60*60){
            $minute = floor($diff / 60);
            $passed_time = $minute." Dakika Önce";
        }else if($diff >= 60*60 && $diff < 60*60*24 ){
            $hour = floor($diff/60/60);
            $passed_time = $hour." Ssaat Önce";
        }else if($diff >= 60*60*24 && $diff < 60*60*24*7){
            $day = floor($diff/60/60/24);
            $passed_time = $day." Gün Önce";
        }else if($diff >= 60*60*24*7 && $diff < 60*60*24*30 ){
            $week = floor($diff/60/60/24/7);
            $passed_time = $week." Hafta Önce";
        }else if($diff >= 60*60*24*30 && $diff < 60*60*24*30*12 ){
            $month = floor($diff/60/60/24/30);
            $passed_time = $month." Ay Önce";
        }else if($diff >= 60*60*24*30*12){
            $year = floor($year/60/60/24/30/12);
            $passed_time = $year." Yıl Önce";
        }else{
            $passed_time = "Geçersiz Zaman Dilimi";
        }

        return $passed_time;

    }
function resize($newWidth, $targetFile, $originalFile) {

    $info = getimagesize($originalFile);
    $mime = $info['mime'];

    switch ($mime) {
            case 'image/jpeg':
                    $image_create_func = 'imagecreatefromjpeg';
                    $image_save_func = 'imagejpeg';
                    $new_image_ext = 'jpg';
                    break;

            case 'image/png':
                    $image_create_func = 'imagecreatefrompng';
                    $image_save_func = 'imagepng';
                    $new_image_ext = 'png';
                    break;

            case 'image/gif':
                    $image_create_func = 'imagecreatefromgif';
                    $image_save_func = 'imagegif';
                    $new_image_ext = 'gif';
                    break;

            default: 
                    throw new Exception('Unknown image type.');
    }

    $img = $image_create_func($originalFile);
    list($width, $height) = getimagesize($originalFile);

    $newHeight = ($height / $width) * $newWidth;
    $tmp = imagecreatetruecolor($newWidth, $newHeight);
    imagecopyresampled($tmp, $img, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

    if (file_exists($targetFile)) {
            unlink($targetFile);
    }
    $image_save_func($tmp, "$targetFile.$new_image_ext");
}
?>