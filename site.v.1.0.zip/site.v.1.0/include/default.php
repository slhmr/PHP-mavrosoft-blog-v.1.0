<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */
$header_menu="";
$content="";
$r_sidebar="";
$footer="";
$content_menu="";
$kat_menu="";
$currentmenuitem="";
$top_pagination="";
$kullanici="";
$s_category=""
?>