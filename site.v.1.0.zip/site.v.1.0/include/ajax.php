<?php

/**
 * @author MavRoAySa
 * @copyright 2017
 */
session_start();
require_once("class.user.php");
require_once("function.php");
$date = new DateTime();
$par = $_GET["gorev"];
$user_id =0;
if(!empty($_SESSION['user_session'])){
$user_id = $_SESSION['user_session'];	
}

$dbc = new user();

if($par=="yorum_gonder"){
	if(!ajaxistegikontrol()){
        echo 'Ajax İsteği Değil';
    }
    else{
    	$gelenid=$_POST['comment_post_ID'];
        $yazar = $_POST['author'];
        $yorum = $_POST['comment'];
        $yorumacevap = $_POST['comment_parent'];
        $eklenme_tarihi = $date->format('Y-m-d H:i:s'); 
        $durum=0;
        $parent=$_POST['comment_parent'];
       
        
        if(empty($yazar)){
        	echo "<div class='error-1'>
					    <span>Yorum Yapmak İçin Adınızı Giriniz......</span>
				   </div>";
        }
        elseif(empty($yorum)){
        	echo "<div class='error-1'>
					    <span>Yorumunuzu Yazmadınız...</span>
				   </div>";
        }
        else{
        	$sonuc = $dbc->ekle("comments",array("com_name"=>$yazar,"com_comment"=>$yorum,"com_article"=>$gelenid,"com_status"=> $durum,"com_user"=>$user_id,"com_cp"=>$parent,"com_addtime"=>$eklenme_tarihi));
        	if (isset($sonuc)){
        
        		echo "<div class='success'>
					    <span>Yorumunuz Onaylandıktan Sonra Yayınlanacaktır....</span>
				   </div>
				   <script>setTimeout(function() { window.location=window.location;},1000);</script>";
	 		}
     		else {
				echo "<h4 class='alert_error'>Kaydetme İşlemi Başarısız........</h4>";
	 		}
        }
    }
}

?>