<?php
session_start();
require_once("class.user.php");

$login = new USER();

if(isset($_POST['btn-login'])){

	$uname = strip_tags($_POST['user_email']);
	$umail = strip_tags($_POST['user_email']);
	$upass = strip_tags($_POST['password']);

	if($login->doLogin($uname,$umail,$upass)){

		 echo "Başarılı";
	}
	else{

		echo"<span>Giriş işlemi Başarısız...!!!!!!!</span>";
	}	
}

?>