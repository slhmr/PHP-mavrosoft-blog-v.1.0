<?php
class PDO_Pagination {
    private $_connection;
    private $_paginator = 'pg';
    private $_sql;
    private $_limit_per_page = 5;
    private $_range = 5;
    protected $return;
    public function __construct( $connection ) {
        $this->setConnection( $connection );
        $this->getPager();
    }
    public function getTotalOfResults() {
        $result = $this->_connection->query(
            str_replace( '*', 'COUNT(*)', $this->_sql )
        );
        return (int) $result->fetchColumn();
    }
    private function setConnection( $connection ) {
        if ( $connection instanceof PDO ) {
            $this->_connection = $connection;
        } else {
            throw new Exception('<<THIS DEPENDENCY NEEDS A PDO OBJECT>>');
        }
    }
   
    public function printNavigationBar($link,$link2){ 
        $current_page = $this->getCurrentPage();
        $total_of_pages = $this->getTotalOfPages();
        $paginator = $this->getPaginator();
        $query_string = $this->rebuildQueryString( $paginator );
        $range = $this->getRange();
        if($this->getTotalOfResults() > 0) {         
             $this->return .="<div class='pagination'><ul>"; 
            if ( $current_page > 1 ) { 
                    $this->return .= "<li><a href='?page$link$link2&$paginator=1'></a></li>"; 
                $previous = $current_page - 1; 
                    $this->return .= "<li><a href='?page$link$link2&$paginator=$previous'></li>"; 
            } 
            
            if ( $current_page != $total_of_pages ) { 
                $next = $current_page + 1; 
                   $this->return .= "<li><a href='?page$link$link2&$paginator=$next'></a></li>"; 
                  $this->return .= "<li><a  href='?page$link$link2&$paginator=$total_of_pages'></a></li>"; 
            } 
             
                $this->return .= "</div>";             
        } 
    return $this->return;
    } 
    public function getTotalOfPages() 
    {        
        
        return ceil( $this->getTotalOfResults() / $this->getLimitPerPage() );
        
    }
    public function getCurrentPage() 
    { 
        $total_of_pages = $this->getTotalOfPages();
        $pager = $this->getPager();
        
        if ( isset( $pager ) && is_numeric( $pager ) ) {          
            $currentPage = $pager; 
        } else { 
            $currentPage = 1; 
        } 

        if ( $currentPage > $total_of_pages ) { 
            $currentPage = $total_of_pages; 
        } 

        if ($currentPage < 1) { 
            $currentPage = 1; 
        } 

        return (int) $currentPage; 
         
    } 
    private function getOffset() 
    {       
       
        return  ( $this->getCurrentPage() - 1 ) * $this->getLimitPerPage();  
        
    } 
    public function setSQL( $string ) 
    {
        
        if ( strlen( $string ) < 0 ) {
            throw new Exception( "<<THE QUERY NEEDS A SQL STRING>>" );
        } 
        
        $this->_sql = $string;
        
    }
    public function getSQL() 
    {
        $limit_per_page = $this->getLimitPerPage();
        $offset = $this->getOffset();
        
        return $this->_sql .  " LIMIT {$limit_per_page} OFFSET {$offset} "; 
        
    }
    public function setPaginator( $paginator ) 
    {
        
        if( !is_string( $paginator ) ) {
            throw new Exception("<<PAGINATOR MUST BE OF TYPE STRING>>");
        } 
        
        $this->_paginator = $paginator;
        
    }
    private function getPaginator()
    {
        return $this->_paginator;
    }
    public function getPager() 
    {
        
         return ( isset ( $_REQUEST["{$this->_paginator}"] ) )  
                ? (int) $_REQUEST["{$this->_paginator}"]  
                : 0 
        ;  
        
    }
    public function setLimitPerPage( $limit ) 
    {
        
        if( !is_int( $limit ) ) {
            throw new Execption( "<<THE LIMIT MUST BE AN INTEGER>>" );
        }
        
        $this->_limit_per_page = $limit;
        
        
    }
    public function getLimitPerPage() 
    {
        
        return $this->_limit_per_page;
        
    }
    public function setRange( $range ) 
    {
        
        if( !is_int( $range ) ) {
            throw new Execption( "<<THE RANGE MUST BE AN INTEGER>>" );
        }
        
        $this->_range = $range;
        
    }
    public function getRange() 
    {
        
        return $this->_range;
        
    }
    public function rebuildQueryString ( $query_string ) 
    { 
        $old_query_string = $_SERVER['QUERY_STRING'];
        
        if ( strlen( $old_query_string ) > 0 ) { 
            
            $parts = explode("-", $old_query_string ); 
            $new_array = array();
            
            foreach ($parts as $val) { 
                if ( stristr( $val, $query_string ) == false)  { 
                    array_push( $new_array , $val ); 
                } 
            } 
            
            if ( count( $new_array ) != 0 ) { 
                $new_query_string = "-".implode( "-", $new_array ); 
            } else { 
                return false; 
            }
            
            return $new_query_string;
            
        } else { 
            return false; 
        } 
        
    }     

}