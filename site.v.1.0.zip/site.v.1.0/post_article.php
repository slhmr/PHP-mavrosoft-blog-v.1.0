<?php
/**
 * @author MavRoSofT
 * @copyright 2017
 */
$connection=$dbs->dbConnection();
$pagination = new PDO_Pagination( $connection );

if(isset($sayfa_args[0]) && $sayfa_args[0] == "cat") {
	$id=$sayfa_args[1];
	$class="home";
	$sorgutoppagination = $dbc->vericek("category","WHERE cat_id='$id'");
	if($sorgutoppagination != null) foreach( $sorgutoppagination as $toppagination ) {
		$top_cat_name=$toppagination['cat_name'];
	}
	$top_pagination="<a href='index.php'>AnaSayfa</a><a href='#' class='active'>$top_cat_name</a>";

	
    $pagination->setSQL( "SELECT * FROM postarticle  WHERE p_bct='571' and p_cat='$id' ORDER BY p_id DESC" );
    $pagination->setPaginator( "pg" );
    $results = $connection->query( $pagination->getSQL() );
	$rows = $results->rowCount();
	if(!empty($rows)){
	    if($results != null) foreach($results as $satir) {
			$id=$satir['p_id'];
			$baslik=$satir['p_head'];
			$icerik=$satir['p_content'];
			$kategori=$satir['p_cat'];
			$altkategori=$satir['p_sub'];
			$eriket=$satir['p_tags'];
			$etiketler=array();
			$etiketler = explode (',',$eriket);
			$logo=$satir['p_logo'];
			$ekleyen=$satir['p_add'];
			$eklenmetarihi=$satir['p_addtime'];
			$guncellenmetarihi=$satir['p_update'];
			$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
		    if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
		    	$kategori=$satir2['cat_name'];
		    }

		    $sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
		    if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
		    	$altkategori=$satir3['sub_name'];
		    }
		    $sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
		    if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
		    	$logo=$satir4['im_name'];
		    }
		    $sorgu5 = $dbc->vericek("users","WHERE user_id=$ekleyen");
		    if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
		    	$ekleyen=$satir5['user_name'];
	    	}
			if(!empty($eklenmetarihi)){
				$tarih_saat=array();
				$tarih_saat = explode (' ',$eklenmetarihi);
				$tarih=array();
				$tarih = explode ('-',$tarih_saat[0]);
				$yil=$tarih[0];
				$ay=$tarih[1];
				$gun=$tarih[2];
			}
			$ay=ayyaz($ay);
			$uzunluk = strlen($icerik);
	    	if($uzunluk >= 200){$icerik=metni_sinirla($icerik,200);}
	    	$sorgu=$dbc->vericek("comments","WHERE com_article='$id' and com_status='1'");
	    	$count = $sorgu->rowCount();
	    		
	    	$content.="<!-- Standard -->
				<article class='format-standard'>
					<div class='box cf'>
						<div class='entry-date'>
							<div class='number'>$gun</div>
							<div class='month'>$ay</div>
						</div>							
						<div class='excerpt'>
							<a href='?page=single/article/$id' class='post-heading' >$baslik</a>
							<p>$icerik</p>				
							<p><a href='?page=single/article/$id' class='learnmore'>Devamını Oku</a></p>
						</div>	
						<div class='meta'>
							<span class='format'>$altkategori</span>
							<span class='user'><a href='#'>By $ekleyen </a></span>
							<span class='comments'>$count Yorum</span>
							<span class='tags'>";
							foreach ($etiketler as $key => $value) {
							$sorgu = $dbc->vericek("tags","WHERE tag_id=$value");
						   	if($sorgu!= null) foreach( $sorgu as $satir ) {
						   		$etiketadi=$satir['tag_name'];
						   		$etiketid=$satir['tag_id'];
						   	}
						    $content.="<a href='#'>&nbsp;$etiketadi</a>";
							}
							$content.="</span>
						</div>		
					</div>
				</article>
				<!-- ENDS  Standard -->";
			}
			
			$content.="<!-- page-navigation -->
					<div class='container small'>";
			$content.=$pagination->printNavigationBar("=cat/",$sayfa_args[1]);
			$content.="</div>
					<!--ENDS page-navigation -->";
		}
		else{
		$content.="<div class='info'>
					    <span>Kayıtlı İçerik Bulunmamaktadır......</span>
				   </div>";
		}	
}
elseif(isset($sayfa_args[0]) && $sayfa_args[0] == "sub") {
	$id=$sayfa_args[1];
	$class="home";
	$sorgutoppagination = $dbc->vericek("subcategory","WHERE sub_id='$id'");
	if($sorgutoppagination != null) foreach( $sorgutoppagination as $toppagination ) {
		$top_sub_name=$toppagination['sub_name'];
		$cat=$toppagination['sub_cat_name'];
	}
	$sorgutoppagination = $dbc->vericek("category","WHERE cat_id='$cat'");
	if($sorgutoppagination != null) foreach( $sorgutoppagination as $toppagination ) {
		$top_cat_name=$toppagination['cat_name'];
	}

	$top_pagination="<a href='index.php'>AnaSayfa</a><a href='?page=cat/$cat'>$top_cat_name</a><a href='?page=sub/$id' class='active'>$top_sub_name</a>";

		$pagination->setSQL( "SELECT * FROM postarticle  WHERE p_bct='571' and p_cat='$cat' and p_sub='$id' ORDER BY p_id DESC" );
    $pagination->setPaginator( "pg" );
    $results = $connection->query( $pagination->getSQL() );
	$rows = $results->rowCount();
	if(!empty($rows)){
	    if($results != null) foreach( $results as $satir ) {
			$id=$satir['p_id'];
			$baslik=$satir['p_head'];
			$icerik=$satir['p_content'];
			$kategori=$satir['p_cat'];
			$altkategori=$satir['p_sub'];
			$eriket=$satir['p_tags'];
			$etiketler=array();
			$etiketler = explode (',',$eriket);
			$logo=$satir['p_logo'];
			$ekleyen=$satir['p_add'];
			$eklenmetarihi=$satir['p_addtime'];
			$guncellenmetarihi=$satir['p_update'];
			$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
		    if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
		    	$kategori=$satir2['cat_name'];
		    }
		    $sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
		    if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
		    	$altkategori=$satir3['sub_name'];
		    }
		    $sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
		    if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
		    	$logo=$satir4['im_name'];
		    }
		    $sorgu5 = $dbc->vericek("users","WHERE user_id=$ekleyen");
		    if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
		    	$ekleyen=$satir5['user_name'];
	    	}
			if(!empty($eklenmetarihi)){
				$tarih_saat=array();
				$tarih_saat = explode (' ',$eklenmetarihi);
				$tarih=array();
				$tarih = explode ('-',$tarih_saat[0]);
				$yil=$tarih[0];
				$ay=$tarih[1];
				$gun=$tarih[2];
			}
			$ay=ayyaz($ay);
			$uzunluk = strlen($icerik);
	    	if($uzunluk >= 200){$icerik=metni_sinirla($icerik,200);}
	    	$sorgu=$dbc->vericek("comments","WHERE com_article='$id' and com_status='1'");
	    	$count = $sorgu->rowCount();
	    		
	    	$content.="<!-- Standard -->
				<article class='format-standard'>
					<div class='box cf'>
						<div class='entry-date'>
							<div class='number'>$gun</div>
							<div class='month'>$ay</div>
						</div>							
						<div class='excerpt'>
							<a href='?page=single/article/$id' class='post-heading' >$baslik</a>
							<p>$icerik</p>				
							<p><a href='?page=single/article/$id' class='learnmore'>Devamını Oku</a></p>
						</div>	
						<div class='meta'>
							<span class='format'>$altkategori</span>
							<span class='user'><a href='#'>By $ekleyen </a></span>
							<span class='comments'>$count Yorum</span>
							<span class='tags'>";
							foreach ($etiketler as $key => $value) {
								$sorgu = $dbc->vericek("tags","WHERE tag_id=$value");
								if($sorgu!= null) foreach( $sorgu as $satir ) {
							   		$etiketadi=$satir['tag_name'];
							   		$etiketid=$satir['tag_id'];
							   	}
						    $content.="<a href='#'>&nbsp;$etiketadi</a>";
							}
							$content.="</span>
							</div>		
						</div>
					</article>
					<!-- ENDS  Standard -->";
			}
			
			$content.="<!-- page-navigation -->
					<div class='container small'>";
			$content.=$pagination->printNavigationBar("=sub/",$sayfa_args[1]);
			$content.="</div>
					<!--ENDS page-navigation -->";
		}
		else{
		$content.="<div class='info'>
					    <span>Kayıtlı İçerik Bulunmamaktadır......</span>
				   </div>";
		}
}
elseif(isset($sayfa_args[0]) && $sayfa_args[0] == "single") {
	if(isset($sayfa_args[1]) && $sayfa_args[1] == "article") {		
		$id=$sayfa_args[2];
		$class="single";
		$sorgu=$dbc->vericek("postarticle","WHERE p_id='$id'");
	    if($sorgu != null) foreach( $sorgu as $satir ) {
			$baslik=$satir['p_head'];
			$icerik=$satir['p_content'];
			$kategori=$satir['p_cat'];
			$altkategori=$satir['p_sub'];
			$eriket=$satir['p_tags'];
			$etiketler=array();
			$etiketler = explode (',',$eriket);
			$logo=$satir['p_logo'];
			$ekleyen=$satir['p_add'];
			$eklenmetarihi=$satir['p_addtime'];
			$guncellenmetarihi=$satir['p_update'];
			$hit=$satir['p_hit'];
			if (empty($_SESSION['p_hit']) || $_SESSION['p_hit'] != $id) {
			$hit = $hit + 1; 
			$hitguncelle=$dbc->guncelle("postarticle",array("p_hit"=>$hit),"p_id=$id");  
			$_SESSION['p_hit'] = $id;
		} 
			$hitguncelle=$dbc->guncelle("postarticle",array("p_hit"=>$hit),"p_id=$id");
			$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
		    if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
		    	$kategori=$satir2['cat_name'];
		    	$kategori_id=$satir2['cat_id'];
		    }
		    $sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
		    if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
		    	$altkategori=$satir3['sub_name'];
		    	$altkategori_id=$satir3['sub_id'];
		    }
		    $top_pagination="
		    <a href='index.php'>AnaSayfa</a>
		    <a href='?page=cat/$kategori_id'>$kategori</a>
		    <a href='?page=sub/$altkategori_id'>$altkategori</a>
		    <a href='#' class='active'>$baslik</a>";
		    $sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
		    if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
		    	$altkategori=$satir3['sub_name'];
		    }
		    $sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
		    if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
		    	$logo=$satir4['im_name'];
		    	$impath=$satir4['im_path'];
		    }
		    $sorgu5 = $dbc->vericek("users","WHERE user_id=$ekleyen");
		    if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
		    	$ekleyen=$satir5['user_name'];
			}
			if(!empty($eklenmetarihi)){
				$tarih_saat=array();
				$tarih_saat = explode (' ',$eklenmetarihi);
				$tarih=array();
				$tarih = explode ('-',$tarih_saat[0]);
				$yil=$tarih[0];
				$ay=$tarih[1];
				$gun=$tarih[2];
			}
			$sorgu = $dbc->vericek("comments","WHERE com_article='$id' and com_status='1'");
			$count = $sorgu->rowCount();
			$ay=ayyaz($ay);					
			$content.="<!-- Standard -->
					<article class='format-standard'>
						<div class='feature-image'>
							
						</div>
						<div class='box cf'>
							<div class='entry-date'><div class='number'>$gun</div><div class='month'>$ay</div></div>
							
							<div class='excerpt'>
								<div class='post-heading' >$baslik</div>
								<div class='entry-content'>
									<p>$icerik</p>
								</div>
							</div>
							
							<div class='meta'>
							<div class='blok'>
								<div class='blok-1'>
								 	<span class='format'>$kategori</span>
									<span class='user'><a href='#'>$ekleyen, </a></span>
									<span class='comments'>$count Yorum</span>
									<span class='tags'>";
			foreach ($etiketler as $key => $value) {
				$sorgu = $dbc->vericek("tags","WHERE tag_id=$value");
				if($sorgu!= null) foreach( $sorgu as $satir ) {
					$etiketadi=$satir['tag_name'];
					$etiketid=$satir['tag_id'];
				}
				$content.="
										<a href='#'>&nbsp;$etiketadi</a>";
			}
			$content.="
									</span>
								</div>
								<div class='blok-2'>
										<div class='social'>
										  <a href='#' id='share-fb' class='sharer button'><i class='fa fa-3x fa-facebook-square'></i></a>
										  <a href='#' id='share-tw' class='sharer button'><i class='fa fa-3x fa-twitter-square'></i></a>
										  <a href='#' id='share-li' class='sharer button'><i class='fa fa-3x fa-linkedin-square'></i></a>
										  <a href='#' id='share-gp' class='sharer button'><i class='fa fa-3x fa-google-plus-square'></i></a>
										  <a href='#' id='share-em' class='sharer button'><i class='fa fa-3x fa-envelope-square'></i></a>
									</div>
								</div>
							</div>
						</div>	
					</div>
				</article>
					<!-- ENDS-->";
			$sorgu = $dbc->vericek("comments","WHERE com_article='$id' and com_status='1'");
			$count = $sorgu->rowCount();

			if($count =="0"){
				$yorumsay="Bu yazıya henüz bir yorum yapılmamış. İlk yorumu yapan siz olun!";
			}
			else{
				$yorumsay="$count Yorum";
			}
			$content.="
			<!-- comments list -->
				<div id='comments-wrap'>
					<h4 class='heading'>$yorumsay</h4>
					<ol class='commentlist'>";
					if($sorgu != null)foreach ($sorgu as $satir) {
						$yazar=$satir['com_name'];
						$yorum=$satir['com_comment'];
						$cid=$satir['com_id'];
						$cp=$satir['com_cp'];
						$tarih=$satir['com_addtime'];
						if(isset($_SESSION['user_session'])!=''){
							$uid=$_SESSION['user_session'];
							$sorgu=$dbc->vericek("users","WHERE user_id='id'");
							if($sorgu != null)foreach ($sorgu as $satir) {
								$yazar=$satir[''];
							}
						}
						$gecen_sure=gecensure($tarih);
						$content.="
						<li class='comment even thread-even depth-1' id='li-comment-$cid'>
							<div id='comment-$cid' class='comment-body cf'>
						     	<img alt='' src='Style/img/no-image.jpg' class='avatar avatar-35 photo' height='35' width='35' />      
						     	<div class='comment-author vcard'>$yazar</div>
						        <div class='comment-meta commentmetadata'>
							  		<span class='comment-date'>$gecen_sure</span>
									
								</div>
						  		<div class='comment-inner'>
							   		<p>$yorum</p>
						 		</div>
					     	</div>";	
					}
					
					
					$content.="	
					</ol>
				</div>
				<!-- ENDS comments list -->
			<!-- Respond -->				
				<div id='respond'>
					<h3 id='reply-title'>Yorum Yap<small><a rel='nofollow' id='cancel-comment-reply-link' href='?page=single/article/$id#respond' style='display:none;'>Yorumu Sil</a></small></h3>
					<div id='sonuc'></div>	
					<form id='commentform' method='post' action='' onsubmit='return false' >
						<p class='comment-form-author'><label for='author'>Adınız<span class='required'>*</span></label> <input id='author' name='author' type='text' value='' size='30' aria-required='true'></p>
					
						<p class='comment-form-comment'><label for='comment'>Yorumunuz</label><textarea id='comment' name='comment' cols='45' rows='8' aria-required='true'></textarea></p>			

						<p class='form-submit'>
							<input name='submit' type='submit' id='submit' value='Yorum Gönder' onclick='yorumgonder()'>
							<input type='hidden' name='comment_post_ID' value='$id' id='comment_post_ID'>
							<input type='hidden' name='comment_parent' id='comment_parent' value='0'>
						</p>
					
					</form>
				</div>
				<!-- ENDS Respond -->";
	    }
	}	
}
elseif(isset($sayfa_args[0]) && $sayfa_args[0] == "arsive") {
	$ay_id=$sayfa_args[1];
	$ay_name=ayyaz($ay_id);
	$class="home";
	$top_pagination="<a href='index.php'>AnaSayfa</a><a href='#'>Arşiv</a><a href='#' class='active'>$ay_name</a>";
	
	$pagination->setSQL( "SELECT * FROM postarticle  WHERE p_bct='571' and p_arsive_ay='$ay_id' ORDER BY p_id DESC" );
    $pagination->setPaginator( "pg" );
    $results = $connection->query( $pagination->getSQL() );
	$rows = $results->rowCount();
	if(!empty($rows)){
	    if($results != null) foreach( $results as $satir ) {
			$id=$satir['p_id'];
			$baslik=$satir['p_head'];
			$icerik=$satir['p_content'];
			$kategori=$satir['p_cat'];
			$altkategori=$satir['p_sub'];
			$eriket=$satir['p_tags'];
			$etiketler=array();
			$etiketler = explode (',',$eriket);
			$logo=$satir['p_logo'];
			$ekleyen=$satir['p_add'];
			$eklenmetarihi=$satir['p_addtime'];
			$guncellenmetarihi=$satir['p_update'];
			$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
		    if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
		    	$kategori=$satir2['cat_name'];
		    }

		    $sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
		    if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
		    	$altkategori=$satir3['sub_name'];
		    }
		    $sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
		    if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
		    	$logo=$satir4['im_name'];
		    }
		    $sorgu5 = $dbc->vericek("users","WHERE user_id=$ekleyen");
		    if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
		    	$ekleyen=$satir5['user_name'];
	    	}
			if(!empty($eklenmetarihi)){
				$tarih_saat=array();
				$tarih_saat = explode (' ',$eklenmetarihi);
				$tarih=array();
				$tarih = explode ('-',$tarih_saat[0]);
				$yil=$tarih[0];
				$ay=$tarih[1];
				$gun=$tarih[2];
			}
			$ay=ayyaz($ay);
			$uzunluk = strlen($icerik);
	    	if($uzunluk >= 200){$icerik=metni_sinirla($icerik,200);}
	    	$sorgu=$dbc->vericek("comments","WHERE com_article='$id' and com_status='1'");
	    	$count = $sorgu->rowCount();
	    		
	    	$content.="<!-- Standard -->
				<article class='format-standard'>
					<div class='box cf'>
						<div class='entry-date'>
							<div class='number'>$gun</div>
							<div class='month'>$ay</div>
						</div>							
						<div class='excerpt'>
							<a href='?page=single/article/$id' class='post-heading' >$baslik</a>
							<p>$icerik</p>				
							<p><a href='?page=single/article/$id' class='learnmore'>Devamını Oku</a></p>
						</div>	
						<div class='meta'>
							<span class='format'>$altkategori</span>
							<span class='user'><a href='#'>By $ekleyen </a></span>
							<span class='comments'>$count Yorum</span>
							<span class='tags'>";
							foreach ($etiketler as $key => $value) {
							$sorgu = $dbc->vericek("tags","WHERE tag_id=$value");
						   	if($sorgu!= null) foreach( $sorgu as $satir ) {
						   		$etiketadi=$satir['tag_name'];
						   		$etiketid=$satir['tag_id'];
						   	}
						    $content.="<a href='#'>&nbsp;$etiketadi</a>";
							}
							$content.="</span>
						</div>		
					</div>
				</article>
				<!-- ENDS  Standard -->";
			}
			
			$content.="<!-- page-navigation -->
					<div class='container small'>";
			$content.=$pagination->printNavigationBar("=arsive/",$ay_id);
			$content.="</div>
					<!--ENDS page-navigation -->";
		}
		else{
		$content.="<div class='info'>
					    <span>Kayıtlı İçerik Bulunmamaktadır......</span>
				   </div>";
		}	
}
elseif(isset($sayfa_args[0]) && $sayfa_args[0] == "search") {
	$kelime=$_POST['aranacakkelime'];
	$class="home";
	$top_pagination="<a href='index.php'>AnaSayfa</a><a href='#'>Ara</a><a href='#' class='active'>\"$kelime\"</a>";
	
	$pagination->setSQL( "SELECT * FROM postarticle  WHERE p_bct='571' and p_head LIKE '%$kelime%' or p_content LIKE '%$kelime%' ORDER BY p_id DESC" );
    $pagination->setPaginator( "pg" );
    $results = $connection->query( $pagination->getSQL() );
	$rows = $results->rowCount();
	if(!empty($rows)){
	    if($results != null) foreach( $results as $satir ) {
			$id=$satir['p_id'];
			$baslik=$satir['p_head'];
			$icerik=$satir['p_content'];
			$kategori=$satir['p_cat'];
			$altkategori=$satir['p_sub'];
			$eriket=$satir['p_tags'];
			$etiketler=array();
			$etiketler = explode (',',$eriket);
			$logo=$satir['p_logo'];
			$ekleyen=$satir['p_add'];
			$eklenmetarihi=$satir['p_addtime'];
			$guncellenmetarihi=$satir['p_update'];
			$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
		    if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
		    	$kategori=$satir2['cat_name'];
		    }

		    $sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
		    if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
		    	$altkategori=$satir3['sub_name'];
		    }
		    $sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
		    if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
		    	$logo=$satir4['im_name'];
		    }
		    $sorgu5 = $dbc->vericek("users","WHERE user_id=$ekleyen");
		    if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
		    	$ekleyen=$satir5['user_name'];
	    	}
			if(!empty($eklenmetarihi)){
				$tarih_saat=array();
				$tarih_saat = explode (' ',$eklenmetarihi);
				$tarih=array();
				$tarih = explode ('-',$tarih_saat[0]);
				$yil=$tarih[0];
				$ay=$tarih[1];
				$gun=$tarih[2];
			}
			$ay=ayyaz($ay);
			$uzunluk = strlen($icerik);
	    	if($uzunluk >= 200){$icerik=metni_sinirla($icerik,200);}
	    	$sorgu=$dbc->vericek("comments","WHERE com_article='$id' and com_status='1'");
	    	$count = $sorgu->rowCount();
	    		
	    	$content.="<!-- Standard -->
				<article class='format-link'>
						<div class='box cf'>
						<div class='entry-date'>
							<div class='number'>$gun</div>
							<div class='month'>$ay</div>
						</div>							
						<div class='excerpt'>
							<a href='?page=single/article/$id' class='post-heading' >$baslik</a>			
							<p><a href='?page=single/article/$id' class='learnmore'>Devamını Oku</a></p>
						</div>	
						<div class='meta'>
							<span class='format'>$altkategori</span>
							<span class='user'><a href='#'>By $ekleyen </a></span>
							<span class='comments'>$count Yorum</span>
							<span class='tags'>";
							foreach ($etiketler as $key => $value) {
							$sorgu = $dbc->vericek("tags","WHERE tag_id=$value");
						   	if($sorgu!= null) foreach( $sorgu as $satir ) {
						   		$etiketadi=$satir['tag_name'];
						   		$etiketid=$satir['tag_id'];
						   	}
						    $content.="<a href='#'>&nbsp;$etiketadi</a>";
							}
							$content.="</span>
						</div>		
					</div>
				</article>
				<!-- ENDS  Standard -->";
			}
			
			$content.="<!-- page-navigation -->
					<div class='container small'>";
			$content.=$pagination->printNavigationBar("=search/sc/",$kelime);
			$content.="</div>
					<!--ENDS page-navigation -->";
		}
		else{
		$content.="<div class='info'>
					    <span>Arama Kriterine Uygun Konu Bulunamadı.....</span>
				   </div>";
		}	
}
elseif(isset($sayfa_args[0]) && $sayfa_args[0] == "tags") {
	$id=$sayfa_args[1];
	$class="home";
	$sorgutoppagination = $dbc->vericek("tags","WHERE tag_id='$id'");
	if($sorgutoppagination != null) foreach( $sorgutoppagination as $toppagination ) {
		$top_tag_name=$toppagination['tag_name'];
		$tag=$toppagination['tag_cat_name'];
		$sub=$toppagination['tag_sub_name'];
	}
	$top_pagination="<a href='index.php'>AnaSayfa</a><a href='#'>Etiketler</a><a href='?page=tags/$id' class='active'>$top_tag_name</a>";

	$pagination->setSQL( "SELECT * FROM postarticle  WHERE p_bct='571' and p_tags LIKE '%$id%' ORDER BY p_id DESC" );
    $pagination->setPaginator( "pg" );
    $results = $connection->query( $pagination->getSQL() );
	$rows = $results->rowCount();
	if(!empty($rows)){
	    if($results != null) foreach( $results as $satir ) {
			$id=$satir['p_id'];
			$baslik=$satir['p_head'];
			$icerik=$satir['p_content'];
			$kategori=$satir['p_cat'];
			$altkategori=$satir['p_sub'];
			$eriket=$satir['p_tags'];
			$etiketler=array();
			$etiketler = explode (',',$eriket);
			$logo=$satir['p_logo'];
			$ekleyen=$satir['p_add'];
			$eklenmetarihi=$satir['p_addtime'];
			$guncellenmetarihi=$satir['p_update'];
			$sorgu2 = $dbc->vericek("category","WHERE cat_id='$kategori'");
		    if($sorgu2 != null) foreach( $sorgu2 as $satir2 ) {
		    	$kategori=$satir2['cat_name'];
		    }
		    $sorgu3 = $dbc->vericek("subcategory","WHERE sub_id='$altkategori'");
		    if($sorgu3 != null) foreach( $sorgu3 as $satir3 ) {
		    	$altkategori=$satir3['sub_name'];
		    }
		    $sorgu4 = $dbc->vericek("images","WHERE im_id='$logo'");
		    if($sorgu4 != null) foreach( $sorgu4 as $satir4 ) {
		    	$logo=$satir4['im_name'];
		    }
		    $sorgu5 = $dbc->vericek("users","WHERE user_id=$ekleyen");
		    if($sorgu5 != null) foreach( $sorgu5 as $satir5 ) {
		    	$ekleyen=$satir5['user_name'];
	    	}
			if(!empty($eklenmetarihi)){
				$tarih_saat=array();
				$tarih_saat = explode (' ',$eklenmetarihi);
				$tarih=array();
				$tarih = explode ('-',$tarih_saat[0]);
				$yil=$tarih[0];
				$ay=$tarih[1];
				$gun=$tarih[2];
			}
			$ay=ayyaz($ay);
			$uzunluk = strlen($icerik);
	    	if($uzunluk >= 200){$icerik=metni_sinirla($icerik,200);}
	    	$sorgu=$dbc->vericek("comments","WHERE com_article='$id' and com_status='1'");
	    	$count = $sorgu->rowCount();
	    		
	    	$content.="<!-- Standard -->
				<article class='format-standard'>
					<div class='box cf'>
						<div class='entry-date'>
							<div class='number'>$gun</div>
							<div class='month'>$ay</div>
						</div>							
						<div class='excerpt'>
							<a href='?page=single/article/$id' class='post-heading' >$baslik</a>
							<p>$icerik</p>				
							<p><a href='?page=single/article/$id' class='learnmore'>Devamını Oku</a></p>
						</div>	
						<div class='meta'>
							<span class='format'>$altkategori</span>
							<span class='user'><a href='#'>By $ekleyen </a></span>
							<span class='comments'>$count Yorum</span>
							<span class='tags'>";
							foreach ($etiketler as $key => $value) {
								$sorgu = $dbc->vericek("tags","WHERE tag_id=$value");
								if($sorgu!= null) foreach( $sorgu as $satir ) {
							   		$etiketadi=$satir['tag_name'];
							   		$etiketid=$satir['tag_id'];
							   	}
						    $content.="<a href='#'>&nbsp;$etiketadi</a>";
							}
							$content.="</span>
							</div>		
						</div>
					</article>
					<!-- ENDS  Standard -->";
			}
			
			$content.="<!-- page-navigation -->
					<div class='container small'>";
			$content.=$pagination->printNavigationBar("=sub/",$sayfa_args[1]);
			$content.="</div>
					<!--ENDS page-navigation -->";
		}
		else{
		$content.="<div class='info'>
					    <span>Kayıtlı İçerik Bulunmamaktadır......</span>
				   </div>";
		}
}
else{
	if (strstr($_SERVER['REQUEST_URI'],'post.php')){
	    header('HTTP/1.0 404 Not Found');
		echo "  <link href='Style/css/custom.css' rel='stylesheet' />
				<div class='wrap'>
			   		<div class='logo'>
			   			<h1>404</h1>
			    		<p>Aradığınız Sayfayı Yapmyı Unuttuk Galiba!!!!!!</p>
		  	      		<div class='sub'>
			        		<p><a class='btn btn-default' href='../index.php'>Siteye Git</a></p>
			     	 	</div>
		        	</div>
				</div>";
    exit();
	}
}
?>